# Bio Alksher — Android Source v2.1 (UI refresh)

## What was updated in this source package
- Refreshed native Android interface with a purple-gradient medical-academic identity and blue/teal accents.
- English MCQ presentation with exactly four answer choices (A–D) per bundled question.
- Immediate feedback after each answer: correct/incorrect status, the student's selected answer, the correct answer, and an explanation.
- Question progress and chapter result/review screens retained.
- Application ID remains `com.biochem.easy`.

## Verified question bank
`app/src/main/assets/question_bank.json` contains 400 questions:
- 200 Carbohydrate Structure
- 200 Enzymes

A data check confirmed all 400 bundled questions have four options, the answer matches one of those options, and an explanation is present. Scientific editorial review is still recommended before formal exam use.

## Important integration status — not a completed production app
This is Android source code, not a compiled APK. The project still contains a mixed backend:
- Student registration and approval checks call the configured Google Apps Script endpoint.
- Results and parts of teacher question management still use Firebase.
- The teacher panel explicitly marks add/edit question and teacher-password migration to Apps Script as incomplete.

Therefore do not treat this package as a fully migrated Apps Script system or a production-ready release. Firebase configuration (`app/google-services.json`), backend rules/deployment, and a successful Android build/test are still required for the Firebase-dependent features. The Apps Script endpoint must also be tested from the installed app.

## Build
Open the project in Android Studio or upload it to the configured Codemagic workflow after supplying the required Firebase configuration. Test registration, approval, chapter exams, results, and teacher functions on a real device before distributing an APK.


## ملاحظة إصدار 2.2-buildfix
تم إيقاف تطبيق إضافة Google Services Gradle في إعدادات البناء لإزالة سبب الخطأ المحدد `processDebugGoogleServices` عند غياب `google-services.json`.

**هذا إصلاح لمرحلة البناء فقط وليس ترحيلاً كاملاً من Firebase إلى Apps Script.** ما زالت بعض وظائف النتائج وإدارة الأسئلة وتغيير PIN تعتمد على Firebase، وتحتاج إلى ترحيل واختبار منفصل قبل اعتبار التطبيق جاهزاً للنشر.
