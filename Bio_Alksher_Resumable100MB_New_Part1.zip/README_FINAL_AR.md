# Bio Alksher — Resumable 100MB Project

هذه النسخة المصدرية الجديدة. اقرأ `INSTALL_FINAL_AR.md` قبل النشر أو البناء.

المجلدات الأساسية: `app/`, `firestore/`، وملفات Apps Script في جذر المشروع.
