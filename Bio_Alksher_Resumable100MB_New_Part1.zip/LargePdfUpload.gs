/** Bio Alksher: teacher-authenticated Google Drive resumable PDF upload (max 100 MiB).
 * Keep the existing LectureFiles.gs. Route this handler before handleLectureFileAction_(data).
 * The Android client uploads bytes DIRECTLY to the returned one-time resumable session URL.
 */
var LARGE_LECTURE_MAX_BYTES_ = 100 * 1024 * 1024;

function handleLargeLectureUploadAction_(data) {
  if (!data || !data.action) return null;
  if (data.action !== 'startLectureUpload' && data.action !== 'finishLectureUpload') return null;
  if (!data.teacherIdToken || !isBioAlksherTeacher_(data.teacherIdToken))
    return json({success:false, message:'غير مصرح. سجّل دخول الأستاذ مجدداً.'});

  if (data.action === 'startLectureUpload') {
    var size = Number(data.fileSize || 0);
    if (!data.title || !data.fileName || size < 1 || size > LARGE_LECTURE_MAX_BYTES_)
      return json({success:false, message:'بيانات الملف غير صحيحة. الحد الأقصى 100 MB.'});
    if (String(data.mimeType || '') !== 'application/pdf')
      return json({success:false, message:'يسمح بملفات PDF فقط.'});
    var metadata = {name:String(data.fileName), mimeType:'application/pdf'};
    var folderId = PropertiesService.getScriptProperties().getProperty('LECTURES_FOLDER_ID');
    if (folderId) metadata.parents = [folderId];
    var response = UrlFetchApp.fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&fields=id,name,mimeType,size,webViewLink', {
      method:'post', contentType:'application/json; charset=utf-8',
      headers:{Authorization:'Bearer ' + ScriptApp.getOAuthToken(), 'X-Upload-Content-Type':'application/pdf', 'X-Upload-Content-Length':String(size)},
      payload:JSON.stringify(metadata), muteHttpExceptions:true
    });
    var code = response.getResponseCode();
    var headers = response.getAllHeaders();
    var sessionUrl = headers.Location || headers.location;
    if (code < 200 || code >= 300 || !sessionUrl)
      return json({success:false, message:'تعذر إنشاء جلسة الرفع في Google Drive: ' + response.getContentText().slice(0,500)});
    return json({success:true, sessionUrl:String(sessionUrl), fileSize:size, message:'تم تجهيز الرفع المباشر.'});
  }

  // Called only after Drive confirms that the complete file has arrived.
  var fileId = String(data.fileId || '');
  if (!fileId || !data.title || !data.fileName)
    return json({success:false, message:'بيانات إكمال الرفع غير مكتملة.'});
  try {
    var file = DriveApp.getFileById(fileId);
    if (file.getMimeType() !== 'application/pdf' || file.getSize() < 1 || file.getSize() > LARGE_LECTURE_MAX_BYTES_)
      return json({success:false, message:'الملف النهائي غير صالح أو يتجاوز 100 MB.'});
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    var ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    var sheet = ss.getSheetByName('Lectures');
    if (!sheet) { sheet = ss.insertSheet('Lectures'); sheet.appendRow(['fileId','title','fileName','url','createdAt','active']); }
    // Preserve the original six-column schema used by Android listLectures/deleteLecture.
    if (data.replaceFileId && sheet.getLastRow() >= 2) {
      var rows = sheet.getDataRange().getValues();
      for (var r=1; r<rows.length; r++) if (String(rows[r][0]) === String(data.replaceFileId) && String(rows[r][5]).toLowerCase() === 'true') {
        sheet.getRange(r+1,6).setValue(false);
        try { DriveApp.getFileById(String(data.replaceFileId)).setTrashed(true); } catch (ignore) {}
        break;
      }
    }
    sheet.appendRow([file.getId(), String(data.title), String(data.fileName), file.getUrl(), new Date(), true]);
    return json({success:true, fileId:file.getId(), title:String(data.title), url:file.getUrl(), message:'تم رفع الفصل كاملاً بنجاح.'});
  } catch (err) {
    return json({success:false, message:'وصل الملف إلى Drive لكن تعذّر تسجيله في قائمة المنهج: ' + err.message, fileId:fileId});
  }
}
