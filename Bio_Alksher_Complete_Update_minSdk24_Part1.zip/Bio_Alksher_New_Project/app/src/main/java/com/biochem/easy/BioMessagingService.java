package com.biochem.easy;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class BioMessagingService extends FirebaseMessagingService {
  private static final String CHANNEL_ID = "bio_alksher_messages";
  @Override public void onMessageReceived(RemoteMessage message) {
    String title = message.getNotification()!=null && message.getNotification().getTitle()!=null
        ? message.getNotification().getTitle() : message.getData().get("title");
    String body = message.getNotification()!=null && message.getNotification().getBody()!=null
        ? message.getNotification().getBody() : message.getData().get("body");
    showNotification(title==null?"Bio-alksher":title, body==null?"لديك إشعار جديد":body);
  }
  @Override public void onNewToken(String token) {
    com.google.firebase.auth.FirebaseAuth auth=com.google.firebase.auth.FirebaseAuth.getInstance();
    com.google.firebase.firestore.FirebaseFirestore db=com.google.firebase.firestore.FirebaseFirestore.getInstance();
    if(auth.getCurrentUser()==null)return;
    String uid=auth.getCurrentUser().getUid();
    java.util.Map<String,Object> data=new java.util.HashMap<>();
    data.put("token",token); data.put("uid",uid);
    data.put("updatedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
    db.collection("notificationTokens").document(uid).set(data,
      com.google.firebase.firestore.SetOptions.merge());
  }
  private void showNotification(String title, String body) {
    NotificationManager manager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
    if (manager==null) return;
    if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.O) {
      NotificationChannel channel=new NotificationChannel(CHANNEL_ID,"رسائل Bio-alksher",NotificationManager.IMPORTANCE_HIGH);
      channel.setDescription("إشعارات ورسائل المدرّس للطلاب"); manager.createNotificationChannel(channel);
    }
    Intent intent=new Intent(this,MainActivity.class); intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
    PendingIntent pending=PendingIntent.getActivity(this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    android.app.Notification notification=new NotificationCompat.Builder(this,CHANNEL_ID)
      .setSmallIcon(android.R.drawable.ic_dialog_info)
      .setContentTitle(title).setContentText(body).setStyle(new NotificationCompat.BigTextStyle().bigText(body))
      .setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).setContentIntent(pending).build();
    manager.notify((int)(System.currentTimeMillis()&0x7fffffff),notification);
  }
}
