package com.biochem.easy;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.widget.*;
import org.json.*;
import java.util.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.*;
import com.google.firebase.auth.FirebaseUser;
import java.security.MessageDigest;
import com.google.firebase.messaging.FirebaseMessaging;
import android.Manifest;
import android.content.pm.PackageManager;

public class MainActivity extends Activity {
  final int NAVY=Color.rgb(35,28,76), BLUE=Color.rgb(65,112,220), PURPLE=Color.rgb(116,68,190),
    DEEP=Color.rgb(54,27,105), TEAL=Color.rgb(25,170,170), BG=Color.rgb(249,247,253),
    PALE=Color.rgb(242,237,251), MUTED=Color.rgb(105,99,128), LILAC=Color.rgb(238,225,252), CYAN=Color.rgb(35,205,211), GREEN=Color.rgb(23,160,72);
  final String[] CHAPTERS={"Introduction","Carbohydrate Structure","Carbohydrate Metabolism","Lipid Structure","Lipid Metabolism","Protein Structure","Protein Metabolism","Enzyme","Vitamin","Integration","Hormone","Heme","Mineral","Genetic","Enzymology","Nucleic Acid Structure","Nucleic Acid Metabolism","Practical"};
  final String[] CHAPTER_ICONS={"✦","◉","◈","●","◉","✧","◈","❋","⚛","⌬","◍","✺","✣","◆"};
  LinearLayout root,panel;
  static class PageState { final LinearLayout root,panel; PageState(LinearLayout r,LinearLayout p){root=r;panel=p;} }
  final ArrayDeque<PageState> pageHistory=new ArrayDeque<>();
  FirebaseAuth auth,studentAuth,teacherAuth; FirebaseFirestore db,studentDb,teacherDb;
  JSONArray bank=new JSONArray(); String studentName="",selectedChapter="",studentId=""; int index=0,correct=0; ArrayList<JSONObject> exam=new ArrayList<>();
  final ArrayList<String> customChapters=new ArrayList<>();
  String[] activeChapters(){ArrayList<String> all=new ArrayList<>(Arrays.asList(CHAPTERS));for(String c:customChapters)if(!c.trim().isEmpty()&&!all.contains(c))all.add(c);return all.toArray(new String[0]);}
  void loadCustomChapters(Runnable done){if(db==null){done.run();return;}db.collection("appConfig").document("chapters").get().addOnSuccessListener(d->{customChapters.clear();List<String> values=(List<String>)d.get("items");if(values!=null)for(String v:values)if(v!=null&&!v.trim().isEmpty()&&!Arrays.asList(CHAPTERS).contains(v))customChapters.add(v.trim());done.run();}).addOnFailureListener(e->{android.util.Log.e("BioAlksher","Chapter list sync failed",e);done.run();});}
  static final int PICK_LECTURE_PDF=8201, PICK_QUESTION_JSON=8202; String pendingLectureTitle=""; String pendingReplaceFileId=""; String pendingReplaceTitle=""; JSONArray pendingImportQuestions=new JSONArray();
  String[] letters={"A","B","C","D"}; boolean teacher=false,answered=false; String teacherPinSession=""; int selectedChoice=-1;
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,WindowManager.LayoutParams.FLAG_SECURE);getWindow().setStatusBarColor(Color.rgb(54,27,105));getWindow().setNavigationBarColor(Color.WHITE);
    try{
      FirebaseApp defaultApp=FirebaseApp.initializeApp(this);
      if(defaultApp==null)defaultApp=FirebaseApp.getInstance();
      studentAuth=FirebaseAuth.getInstance(defaultApp);
      studentDb=FirebaseFirestore.getInstance(defaultApp);
      FirebaseApp teacherApp;
      try{teacherApp=FirebaseApp.getInstance("teacher-session");}
      catch(IllegalStateException missing){teacherApp=FirebaseApp.initializeApp(this,defaultApp.getOptions(),"teacher-session");}
      teacherAuth=FirebaseAuth.getInstance(teacherApp);
      teacherDb=FirebaseFirestore.getInstance(teacherApp);
      auth=studentAuth;db=studentDb;
      if(studentAuth.getCurrentUser()==null)studentAuth.signInAnonymously();
    }catch(Exception e){android.util.Log.e("BioAlksher","Firebase initialization failed",e);}
    try{java.io.InputStream in=getAssets().open("question_bank.json");java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);in.close();bank=new JSONObject(new String(out.toByteArray(),"UTF-8")).getJSONArray("questions");}catch(Exception ignored){}
    studentId=getSharedPreferences("bio_alksher",MODE_PRIVATE).getString("studentId","");
    studentName=getSharedPreferences("bio_alksher",MODE_PRIVATE).getString("studentName","");
    requestNotificationPermission();
    home();
  }
  @Override public void onBackPressed(){
    if(!pageHistory.isEmpty()){
      PageState previous=pageHistory.pop();
      root=previous.root; panel=previous.panel; setContentView(root); return;
    }
    super.onBackPressed();
  }
  GradientDrawable outlineBox(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);d.setStroke(3,stroke);return d;}
  GradientDrawable solid(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
  GradientDrawable grad(int c1,int c2,int radius){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{c1,c2});d.setCornerRadius(radius);return d;}
  TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(9,8,9,8);return t;}
  void page(String title){
    if(root!=null && panel!=null && root.getParent()!=null) pageHistory.push(new PageState(root,panel));
    root=new LinearLayout(this);root.setOrientation(1);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setPadding(14,10,14,12);root.setBackgroundColor(BG);setContentView(root);
    TextView brand=txt("⚗  الكيمياء الحيوية",21,Color.WHITE,true);brand.setGravity(Gravity.CENTER);brand.setPadding(16,8,16,8);brand.setBackground(grad(DEEP,PURPLE,26));brand.setElevation(5);root.addView(brand,new LinearLayout.LayoutParams(-1,58));
    TextView subtitle=txt("بطريقة سهلة معي  •  BIOCHEMISTRY EASY WITH ME",12,TEAL,true);subtitle.setGravity(Gravity.CENTER);subtitle.setPadding(4,8,4,2);root.addView(subtitle);
    TextView heading=txt(title,23,NAVY,true);heading.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);heading.setPadding(5,10,5,8);root.addView(heading);
    ScrollView sc=new ScrollView(this);sc.setFillViewport(false);panel=new LinearLayout(this);panel.setOrientation(1);panel.setPadding(2,2,2,22);sc.addView(panel);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
  }
  void card(String s,int color){TextView v=txt(s,15,color,true);v.setBackground(solid(Color.WHITE,20));v.setElevation(2);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,5,0,8);panel.addView(v,p);}
  Button button(String label,int c1,int c2,Runnable action){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setTextSize(15);b.setTypeface(null,Typeface.BOLD);b.setBackground(grad(c1,c2,22));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,6,0,7);panel.addView(b,p);b.setOnClickListener(v->action.run());return b;}
  EditText field(String hint){EditText e=new EditText(this);e.setSingleLine(false);e.setTextSize(15);e.setHint(hint);e.setPadding(14,10,14,10);e.setBackground(solid(Color.WHITE,16));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,5,0,7);panel.addView(e,p);return e;}
  TextView sectionTitle(String text){TextView t=txt(text,18,NAVY,true);t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);t.setPadding(4,16,4,8);panel.addView(t);return t;}
  void addFeatureGrid(){
    String[] icons={"▣","▤","☷","▥","▱","▧"};String[] labels={"محاضرات الفيديو","الفصول الدراسية","بنك الأسئلة\nوالاختبارات","نتائجي وتقدمي","ملخصات وملاحظات","ملفات PDF"};
    Runnable[] actions={()->{checkFirebaseAccess();videoLibrary();},()->checkFirebaseAccess(),()->checkFirebaseAccess(),()->{checkFirebaseAccess();studentResults();},()->msg("ستضاف الملخصات هنا بعد رفع ملفات المقرر."),()->{checkFirebaseAccess();pdfLibrary();}};
    int[] colors={PURPLE,DEEP,Color.rgb(145,48,190),TEAL,PURPLE,BLUE};
    for(int r=0;r<2;r++){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.setMargins(0,5,0,5);panel.addView(row,rp);
      for(int c=0;c<3;c++){int i=r*3+c;LinearLayout tile=new LinearLayout(this);tile.setOrientation(1);tile.setGravity(Gravity.CENTER);tile.setPadding(5,12,5,12);tile.setBackground(solid(Color.WHITE,22));tile.setElevation(4);TextView ic=txt(icons[i],31,colors[i],true);ic.setGravity(Gravity.CENTER);tile.addView(ic,new LinearLayout.LayoutParams(-1,48));TextView label=txt(labels[i],13,DEEP,true);label.setGravity(Gravity.CENTER);label.setMinHeight(48);tile.addView(label);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,142,1);tp.setMargins(4,2,4,2);row.addView(tile,tp);tile.setOnClickListener(v->actions[i].run());}}
  }
  String deviceKey(){
    try { return DeviceIdentity.getDeviceKey(); }
    catch(Exception e) { return null; }
  }
  boolean hasInternet(){
    try{ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);if(cm==null)return false;android.net.Network n=cm.getActiveNetwork();if(n==null)return false;NetworkCapabilities c=cm.getNetworkCapabilities(n);return c!=null&&c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)&&c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);}catch(Exception e){return false;}
  }
  void requireOnline(Runnable action){if(!hasInternet()){new AlertDialog.Builder(this).setTitle("الاتصال بالإنترنت مطلوب").setMessage("يعمل تطبيق Bio-alksher عند توفر الإنترنت فقط.").setPositiveButton("إعادة المحاولة",(d,w)->{if(hasInternet())action.run();else msg("لا يوجد اتصال بالإنترنت.");}).setNegativeButton("إغلاق",null).show();return;}action.run();}
  void requestNotificationPermission(){
    if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},7101);}
  }
  void registerFcmToken(){
    if(auth==null||auth.getCurrentUser()==null||db==null)return;
    FirebaseMessaging.getInstance().getToken().addOnSuccessListener(token->{
      FirebaseUser u=auth.getCurrentUser(); if(u==null)return;
      Map<String,Object> data=new HashMap<>(); data.put("token",token);
      data.put("uid",u.getUid()); data.put("updatedAt",FieldValue.serverTimestamp());
      db.collection("notificationTokens").document(u.getUid()).set(data,SetOptions.merge())
        .addOnFailureListener(e->android.util.Log.e("BioAlksher","FCM token save failed",e));
    });
  }
  @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==7101&&grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED)registerFcmToken();}
  void notificationFields(String titleHint,String bodyHint,java.util.function.BiConsumer<String,String> submit){
    LinearLayout form=new LinearLayout(this);form.setPadding(18,8,18,8);form.setOrientation(1);
    EditText title=new EditText(this);title.setHint(titleHint);title.setSingleLine(true);form.addView(title);
    EditText body=new EditText(this);body.setHint(bodyHint);body.setMinLines(3);body.setGravity(Gravity.TOP);form.addView(body);
    new AlertDialog.Builder(this).setTitle("إرسال رسالة للطلاب").setView(form)
      .setPositiveButton("إرسال",(d,w)->{String t=title.getText().toString().trim(),b=body.getText().toString().trim();if(t.isEmpty()||b.isEmpty()){msg("اكتب العنوان والرسالة.");return;}submit.accept(t,b);})
      .setNegativeButton("إلغاء",null).show();
  }
  void sendInAppNotificationForm(){
    if(!teacher||db==null){msg("هذه الخاصية للأستاذ فقط.");return;}
    notificationFields("عنوان الرسالة داخل التطبيق","اكتب الرسالة التي ستظهر للطلاب",(t,b)->{
      Map<String,Object> data=new HashMap<>();data.put("title",t);data.put("body",b);data.put("createdAt",FieldValue.serverTimestamp());data.put("createdBy",teacherAuth.getCurrentUser().getUid());data.put("active",true);
      db.collection("teacherNotifications").add(data).addOnSuccessListener(ref->{msg("تم نشر الرسالة داخل التطبيق. ستظهر للطلاب عند فتح صفحة الإشعارات.");teacherPanel();}).addOnFailureListener(e->msg("تعذر نشر الرسالة: "+e.getLocalizedMessage()));
    });
  }
  void sendPhonePushNotificationForm(){
    if(!teacher){msg("هذه الخاصية للأستاذ فقط.");return;}
    notificationFields("عنوان إشعار الهاتف","رسالة قصيرة تظهر على شاشة الهاتف",(t,b)->{
      FirebaseUser u=teacherAuth==null?null:teacherAuth.getCurrentUser();if(u==null){msg("سجّل دخول الأستاذ مجدداً.");return;}
      u.getIdToken(false).addOnSuccessListener(token->{try{JSONObject req=new JSONObject();req.put("action","sendPushNotification");req.put("title",t);req.put("body",b);req.put("teacherIdToken",token.getToken());AppsScriptApi.post(req,(result,error)->{if(error!=null){msg("تعذر إرسال إشعار الهاتف: "+error.getLocalizedMessage());return;}if(result==null||!result.optBoolean("success")){msg(result==null?"لم يصل رد الخادم.":result.optString("message","فشل إرسال الإشعار."));return;}msg("تم إرسال إشعار الهاتف. وصل إلى "+result.optInt("sent",0)+" جهازاً، وتعذر الوصول إلى "+result.optInt("failed",0)+" جهازاً.");teacherPanel();});}catch(Exception ex){msg("تعذر تجهيز الإشعار.");}}).addOnFailureListener(e->msg("تعذر التحقق من حساب الأستاذ: "+e.getLocalizedMessage()));
    });
  }
  void studentNotifications(){
    page("إشعارات الأستاذ");card("الرسائل والإعلانات المنشورة من الأستاذ",DEEP);
    if(db==null){card("تعذر الاتصال بقاعدة البيانات.",MUTED);return;}
    db.collection("teacherNotifications").orderBy("createdAt",Query.Direction.DESCENDING).limit(50).get().addOnSuccessListener(snap->{if(snap.isEmpty()){card("لا توجد رسائل جديدة حالياً.",MUTED);return;}for(DocumentSnapshot d:snap.getDocuments()){String t=d.getString("title"),b=d.getString("body");card((t==null?"إشعار":t)+"\n"+(b==null?"":b),DEEP);}}).addOnFailureListener(e->card("تعذر تحميل الإشعارات: "+e.getLocalizedMessage(),MUTED));
    button("العودة للرئيسية",TEAL,BLUE,()->studentHome());
  }
  void home(){
    page("تسجيل الدخول");
    TextView hero=txt("Bio-alksher\nد. أحمد الكشر\nEdition 2027",25,Color.WHITE,true);hero.setGravity(Gravity.CENTER);hero.setBackground(grad(Color.BLACK,Color.rgb(55,20,88),28));hero.setPadding(18,24,18,24);panel.addView(hero,new LinearLayout.LayoutParams(-1,-2));
    TextView title=txt("تسجيل دخول الطالب",22,DEEP,true);title.setGravity(Gravity.CENTER);panel.addView(title);
    EditText name=field("اسم الطالب");name.setSingleLine(true);if(!studentName.isEmpty())name.setText(studentName);
    EditText phone=field("رقم الهاتف");phone.setSingleLine(true);String savedPhone=getSharedPreferences("bio_alksher",MODE_PRIVATE).getString("phone","");if(!savedPhone.isEmpty())phone.setText(savedPhone);
    button("إرسال طلب التحقق",PURPLE,DEEP,()->requireOnline(()->submitStudent(name.getText().toString().trim(),phone.getText().toString().trim())));
    button("الدخول",Color.BLACK,PURPLE,()->requireOnline(()->studentLogin(name.getText().toString().trim(),phone.getText().toString().trim())));
    card("بعد إرسال الطلب، انتظر موافقة المدرّس. بعد الموافقة استخدم زر الدخول.",MUTED);
    button("المعلم",Color.BLACK,PURPLE,()->teacherGate("panel"));
  }
  void studentHome(){
    page("الرئيسية");
    card("مرحباً بك " + (studentName==null?"":studentName),DEEP);
    button("بنك الأسئلة",PURPLE,DEEP,()->requireOnline(()->showChapters()));
    button("المنهج PDF",TEAL,BLUE,()->requireOnline(()->pdfLibrary()));
    button("إشعارات الأستاذ",BLUE,TEAL,()->requireOnline(()->studentNotifications()));
    button("نتائجي وتقدمي",PURPLE,BLUE,()->requireOnline(()->studentResults()));
    button("الملخصات والمحاضرات",TEAL,BLUE,()->requireOnline(()->videoLibrary()));
    button("تسجيل الخروج",Color.GRAY,MUTED,()->{auth=studentAuth;db=studentDb;home();});
  }
  String sha256(String value){try{byte[] b=MessageDigest.getInstance("SHA-256").digest(value.getBytes("UTF-8"));StringBuilder h=new StringBuilder();for(byte x:b)h.append(String.format(Locale.US,"%02x",x));return h.toString();}catch(Exception e){return null;}}
  void ensureStudentAuth(java.util.function.Consumer<FirebaseUser> done){
    if(studentAuth==null||studentDb==null){msg("Firebase Authentication غير مهيأ.");return;}
    auth=studentAuth;db=studentDb;
    FirebaseUser u=studentAuth.getCurrentUser();
    if(u!=null&&u.isAnonymous()){done.accept(u);return;}
    studentAuth.signInAnonymously().addOnSuccessListener(r->done.accept(r.getUser()))
      .addOnFailureListener(e->msg("تعذر إنشاء جلسة الطالب: "+e.getLocalizedMessage()));
  }
  void submitStudent(String name,String phone){
    if(name.length()<2){msg("يرجى إدخال الاسم الكامل.");return;}if(phone.length()<6){msg("يرجى إدخال رقم الهاتف بصورة صحيحة.");return;}if(db==null){msg("قاعدة بيانات Firebase غير مهيأة.");return;}
    String key=deviceKey();if(key==null){msg("تعذر إنشاء هوية آمنة لهذا الهاتف.");return;}String phoneHash=sha256(phone);if(phoneHash==null){msg("تعذر تجهيز بيانات التسجيل.");return;}
    ensureStudentAuth(u->{String uid=u.getUid();DocumentReference student=db.collection("students").document(uid);DocumentReference phoneRef=db.collection("phoneIndex").document(phoneHash);Map<String,Object> data=new HashMap<>();data.put("uid",uid);data.put("name",name);data.put("phone",phone);data.put("phoneHash",phoneHash);data.put("deviceKeyHash",sha256(key));data.put("status","Pending");data.put("requestedAt",FieldValue.serverTimestamp());data.put("createdAt",FieldValue.serverTimestamp());Map<String,Object> indexData=new HashMap<>();indexData.put("uid",uid);indexData.put("createdAt",FieldValue.serverTimestamp());db.runBatch(batch->{batch.set(student,data);batch.set(phoneRef,indexData);}).addOnSuccessListener(v->{studentName=name;getSharedPreferences("bio_alksher",MODE_PRIVATE).edit().putString("studentName",name).putString("phone",phone).putString("studentId",uid).apply();msg("تم إرسال طلبك إلى المدرّس. انتظر الموافقة.");}).addOnFailureListener(e->{student.get().addOnSuccessListener(existing->{if(existing.exists()){msg("هذا الحساب مسجل مسبقاً. استخدم زر الدخول بالاسم ورقم الهاتف نفسيهما.");}else{msg("تعذر إرسال الطلب: "+e.getLocalizedMessage());}});});});
  }
  void studentLogin(String name,String phone){
    if(name.trim().length()<2||phone.trim().length()<6){msg("أدخل الاسم ورقم الهاتف المسجلين.");return;}
    ensureStudentAuth(u->{String key=deviceKey();if(key==null){msg("تعذر التحقق من هوية الهاتف.");return;}db.collection("students").document(u.getUid()).get().addOnSuccessListener(doc->{if(!doc.exists()){msg("لا يوجد طلب مسجل لهذا الحساب. اضغط إرسال طلب التحقق أولاً.");return;}String savedName=doc.getString("name"),savedPhone=doc.getString("phone"),savedKey=doc.getString("deviceKeyHash"),status=doc.getString("status");if(!name.equals(savedName)||!phone.equals(savedPhone)){msg("الاسم أو رقم الهاتف لا يطابق بيانات التسجيل الأولى.");return;}if(!sha256(key).equals(savedKey)){msg("هذا الحساب مرتبط بهاتف آخر ولا يسمح بالدخول من هاتف ثانٍ.");return;}if(!"Approved".equals(status)){msg("طلبك لم تتم الموافقة عليه بعد، أو تم رفضه.");return;}Timestamp expiry=doc.getTimestamp("expiresAt");if(expiry==null||expiry.toDate().getTime()<=System.currentTimeMillis()){msg("انتهى الاشتراك. تواصل مع المدرّس للتجديد.");return;}studentName=savedName;studentId=u.getUid();FirebaseMessaging.getInstance().subscribeToTopic("students");registerFcmToken();getSharedPreferences("bio_alksher",MODE_PRIVATE).edit().putString("studentName",savedName).putString("phone",savedPhone).putString("studentId",studentId).apply();studentHome();}).addOnFailureListener(e->msg("تعذر قراءة طلب الطالب من Firestore: "+e.getLocalizedMessage()));});
  }
  void checkFirebaseAccess(){studentLogin(studentName,getSharedPreferences("bio_alksher",MODE_PRIVATE).getString("phone",""));}
  String arabicChapter(String c){return c;}

  void pdfLibrary(){
    page("ملفات PDF");
    card("محاضرات المقرر — الملفات الجديدة تظهر هنا تلقائياً",DEEP);
    String[] names={"Introduction","Protein Structure 2027","Enzyme 2027","Lipid Structure 2027"};
    String[] files={"Introduction.pdf","Protein Structure 2027.pdf","Enzyme 2027.pdf","Lipid Structure 2027.pdf"};
    if(db==null){for(int i=0;i<names.length;i++)addBundledPdfButton(names[i],files[i]);}
    else db.collection("appConfig").document("pdfLibrary").get().addOnSuccessListener(doc->{List<String> hidden=(List<String>)doc.get("hiddenBundled");for(int i=0;i<names.length;i++)if(hidden==null||!hidden.contains(files[i]))addBundledPdfButton(names[i],files[i]);}).addOnFailureListener(e->{for(int i=0;i<names.length;i++)addBundledPdfButton(names[i],files[i]);});
    sectionTitle("الفصول المضافة حديثاً");
    loadOnlineLectures();
    button("العودة للرئيسية",TEAL,BLUE,()->studentHome());
  }
  void addBundledPdfButton(String title,String file){button("📕  "+title,PURPLE,DEEP,()->{android.content.Intent intent=new android.content.Intent(this,LecturePdfActivity.class);intent.putExtra("assetName",file);intent.putExtra("title",title);startActivity(intent);});}
  void loadOnlineLectures(){
    try{
      JSONObject req=new JSONObject();req.put("action","listLectures");
      AppsScriptApi.post(req,(result,error)->{
        if(error!=null){card("تعذر تحميل الفصول المضافة: "+error.getMessage(),MUTED);return;}
        if(result==null||!result.optBoolean("success")){card("لا توجد قائمة فصول متاحة حالياً.",MUTED);return;}
        JSONArray items=result.optJSONArray("lectures");if(items==null||items.length()==0){card("لا توجد فصول جديدة حالياً.",MUTED);return;}
        for(int i=0;i<items.length();i++){JSONObject item=items.optJSONObject(i);if(item==null)continue;
          String title=item.optString("title","ملف PDF"),url=item.optString("url","");
          if(url.isEmpty())continue;
          button("📘 "+title,TEAL,BLUE,()->openLectureUrl(url));
        }
      });
    }catch(Exception e){card("تعذر قراءة قائمة الفصول.",MUTED);}
  }
  void openLectureUrl(String url){
    try{android.content.Intent i=new android.content.Intent(android.content.Intent.ACTION_VIEW,android.net.Uri.parse(url));startActivity(i);}
    catch(Exception e){msg("تعذر فتح ملف المنهج: "+e.getLocalizedMessage());}
  }
  void chooseLecturePdf(){
    if(!teacher){msg("هذه الخاصية للأستاذ فقط.");return;}
    android.content.Intent intent=new android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT);
    intent.addCategory(android.content.Intent.CATEGORY_OPENABLE);intent.setType("application/pdf");
    startActivityForResult(intent,PICK_LECTURE_PDF);
  }
  @Override protected void onActivityResult(int requestCode,int resultCode,android.content.Intent data){
    super.onActivityResult(requestCode,resultCode,data);
    if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;
    if(requestCode==PICK_QUESTION_JSON){readQuestionImportFile(data.getData());return;}
    if(requestCode!=PICK_LECTURE_PDF)return;
    android.net.Uri uri=data.getData();
    String name="Chapter_"+System.currentTimeMillis()+".pdf";
    android.database.Cursor cursor=getContentResolver().query(uri,null,null,null,null);
    if(cursor!=null){try{int ix=cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);if(ix>=0&&cursor.moveToFirst())name=cursor.getString(ix);}finally{cursor.close();}}
    final String fileName=name;
    LinearLayout form=new LinearLayout(this);form.setPadding(18,8,18,8);form.setOrientation(1);
    EditText title= new EditText(this);title.setSingleLine(true);title.setHint("اسم الفصل الذي سيظهر للطلاب");title.setText(pendingReplaceTitle.isEmpty()?fileName.replaceAll("(?i)\\.pdf$",""):pendingReplaceTitle);form.addView(title);
    new AlertDialog.Builder(this).setTitle("رفع فصل PDF إلى المنهج").setView(form)
      .setPositiveButton("رفع",(d,w)->uploadLecturePdf(uri,fileName,title.getText().toString().trim()))
      .setNegativeButton("إلغاء",null).show();
  }
  void uploadLecturePdf(android.net.Uri uri,String fileName,String title){
    if(!teacher||title.isEmpty()){msg("أدخل اسم الفصل أولاً.");return;}
    try{
      java.io.InputStream in=getContentResolver().openInputStream(uri);
      if(in==null){msg("تعذر قراءة ملف PDF.");return;}
      java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();
      byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>25L*1024L*1024L){in.close();msg("حجم الملف أكبر من 25 MB. الحد الأقصى المسموح به هو 25 MB.");return;}}
      in.close();
      String encoded=android.util.Base64.encodeToString(out.toByteArray(),android.util.Base64.NO_WRAP);
      FirebaseUser teacherUser=teacherAuth==null?null:teacherAuth.getCurrentUser();
      if(teacherUser==null){msg("انتهت جلسة الأستاذ. سجّل الدخول مجدداً.");return;}
      final String payload64=encoded;
      teacherUser.getIdToken(false).addOnSuccessListener(tokenResult->{
      try {
      JSONObject req=new JSONObject();req.put("action","uploadLecture");req.put("title",title);req.put("fileName",fileName);req.put("mimeType","application/pdf");req.put("base64",payload64);req.put("teacherIdToken",tokenResult.getToken());if(!pendingReplaceFileId.isEmpty())req.put("replaceFileId",pendingReplaceFileId);
      card("جارٍ رفع الفصل إلى Google Drive...",MUTED);
      AppsScriptApi.post(req,(result,error)->{
        if(error!=null){msg("فشل رفع الملف: "+error.getMessage());return;}
        if(result==null||!result.optBoolean("success")){msg(result==null?"لم يصل رد من Google Apps Script.":result.optString("message","فشل الرفع."));return;}
        pendingReplaceFileId="";pendingReplaceTitle="";
        db.collection("appConfig").document("chapters").set(new HashMap<String,Object>(){{put("items",FieldValue.arrayUnion(title));put("updatedAt",FieldValue.serverTimestamp());}},SetOptions.merge());
        db.collection("appConfig").document("content").set(new HashMap<String,Object>(){{put("contentVersion",FieldValue.increment(1));put("updatedAt",FieldValue.serverTimestamp());}},SetOptions.merge());
        msg("تم رفع الفصل بنجاح. سيظهر للطلاب عند تحديث قائمة المنهج.");
        teacherPdfManager();
      });
      } catch(Exception ex){msg("تعذر تجهيز طلب الرفع: "+ex.getLocalizedMessage());}
      }).addOnFailureListener(e->msg("تعذر التحقق من حساب الأستاذ: "+e.getLocalizedMessage()));
    }catch(Exception e){msg("تعذر تجهيز ملف PDF: "+e.getLocalizedMessage());}
  }
  void teacherPdfManager(){
    if(!teacher){msg("هذه الصفحة للأستاذ فقط.");return;}
    page("إدارة ملفات المنهج PDF");card("ارفع ملف الفصل من هاتفك وسيظهر في قائمة المنهج لدى الطلاب.",DEEP);
    button("＋ إضافة فصل PDF للمنهج",TEAL,BLUE,()->chooseLecturePdf());
    button("＋ إضافة Chapter جديد إلى بنك الفصول",PURPLE,DEEP,()->addCustomChapterDialog());
    button("إدارة الفصول المضافة وحذفها",BLUE,TEAL,()->manageCustomChapters());
    button("إدارة ملفات PDF الأساسية وحذفها من عرض الطلاب",BLUE,TEAL,()->manageBundledPdfs());
    button("تحديث قائمة الفصول",PURPLE,DEEP,()->loadTeacherLectureList());
    loadTeacherLectureList();
    button("العودة إلى لوحة الأستاذ",Color.GRAY,MUTED,()->teacherPanel());
  }
  void manageBundledPdfs(){
    if(!teacher)return;page("إدارة ملفات PDF الأساسية");card("يمكنك إخفاء ملف مدمج من قائمة الطلاب. لا يحذف ذلك ملف المصدر من APK القديم؛ ويُستبدل بإضافة PDF جديد من زر إضافة فصل PDF.",DEEP);
    String[] titles={"Introduction","Protein Structure 2027","Enzyme 2027","Lipid Structure 2027"};
    String[] files={"Introduction.pdf","Protein Structure 2027.pdf","Enzyme 2027.pdf","Lipid Structure 2027.pdf"};
    db.collection("appConfig").document("pdfLibrary").get().addOnSuccessListener(doc->{List<String> hidden=(List<String>)doc.get("hiddenBundled");for(int i=0;i<files.length;i++){final String f=files[i],t=titles[i];boolean isHidden=hidden!=null&&hidden.contains(f);card(t+(isHidden?" — مخفي عن الطلاب":" — ظاهر للطلاب"),DEEP);if(isHidden)button("إظهار هذا الملف للطلاب",TEAL,BLUE,()->db.collection("appConfig").document("pdfLibrary").update("hiddenBundled",FieldValue.arrayRemove(f)).addOnSuccessListener(v->{msg("تم إظهار الملف.");manageBundledPdfs();}).addOnFailureListener(e->msg("تعذر تحديث الملف: "+e.getLocalizedMessage())));else button("إخفاء هذا الملف من المنهج",Color.rgb(170,35,55),DEEP,()->new AlertDialog.Builder(this).setTitle("إخفاء ملف المنهج").setMessage("سيختفي هذا الملف من قائمة الطلاب. يمكنك إضافة ملف PDF بديل.").setNegativeButton("إلغاء",null).setPositiveButton("إخفاء",(x,y)->db.collection("appConfig").document("pdfLibrary").set(new HashMap<String,Object>(){{put("hiddenBundled",FieldValue.arrayUnion(f));put("updatedAt",FieldValue.serverTimestamp());}},SetOptions.merge()).addOnSuccessListener(v->{db.collection("appConfig").document("content").set(new HashMap<String,Object>(){{put("contentVersion",FieldValue.increment(1));put("updatedAt",FieldValue.serverTimestamp());}},SetOptions.merge());msg("تم إخفاء الملف عن الطلاب.");manageBundledPdfs();}).addOnFailureListener(e->msg("تعذر إخفاء الملف: "+e.getLocalizedMessage()))).show());}}).addOnFailureListener(e->card("تعذر تحميل حالة ملفات PDF: "+e.getLocalizedMessage(),MUTED));
    button("العودة إلى إدارة المنهج",TEAL,BLUE,()->teacherPdfManager());
  }
  void addCustomChapterDialog(){
    if(!teacher)return;EditText name=new EditText(this);name.setSingleLine(true);name.setHint("اسم الفصل باللغة الإنجليزية");
    new AlertDialog.Builder(this).setTitle("إضافة Chapter جديد").setView(name).setNegativeButton("إلغاء",null).setPositiveButton("إضافة",(d,w)->{
      String value=name.getText().toString().trim();if(value.length()<2){msg("اكتب اسم الفصل بصورة صحيحة.");return;}
      if(Arrays.asList(CHAPTERS).contains(value)){msg("هذا الفصل موجود بالفعل ضمن الفصول الأساسية.");return;}
      db.collection("appConfig").document("chapters").set(new HashMap<String,Object>(){{put("items",FieldValue.arrayUnion(value));put("updatedAt",FieldValue.serverTimestamp());put("updatedBy",teacherAuth.getCurrentUser().getUid());}},SetOptions.merge()).addOnSuccessListener(v->{db.collection("appConfig").document("content").set(new HashMap<String,Object>(){{put("contentVersion",FieldValue.increment(1));put("updatedAt",FieldValue.serverTimestamp());}},SetOptions.merge());msg("تمت إضافة الفصل. سيظهر للطلاب عند فتح بنك الأسئلة بعد المزامنة.");teacherPdfManager();}).addOnFailureListener(e->msg("تعذرت إضافة الفصل: "+e.getLocalizedMessage()));
    }).show();
  }
  void manageCustomChapters(){
    if(!teacher)return;page("إدارة الفصول المضافة");card("يمكنك حذف الفصول التي أضفتها. الفصول الأساسية محمية من الحذف.",DEEP);
    db.collection("appConfig").document("chapters").get().addOnSuccessListener(doc->{List<String> items=(List<String>)doc.get("items");if(items==null||items.isEmpty()){card("لم تتم إضافة فصول مخصصة بعد.",MUTED);return;}for(String ch:items){card(ch,DEEP);button("حذف الفصل: "+ch,Color.rgb(170,35,55),DEEP,()->new AlertDialog.Builder(this).setTitle("تأكيد حذف الفصل").setMessage("سيختفي الفصل من قائمة الطلاب. الأسئلة والملفات المرتبطة به لن تُحذف تلقائياً.").setNegativeButton("إلغاء",null).setPositiveButton("حذف",(x,y)->db.collection("appConfig").document("chapters").update("items",FieldValue.arrayRemove(ch),"updatedAt",FieldValue.serverTimestamp()).addOnSuccessListener(v->{db.collection("appConfig").document("content").set(new HashMap<String,Object>(){{put("contentVersion",FieldValue.increment(1));put("updatedAt",FieldValue.serverTimestamp());}},SetOptions.merge());msg("تم حذف الفصل من القائمة.");manageCustomChapters();}).addOnFailureListener(e->msg("تعذر حذف الفصل: "+e.getLocalizedMessage()))).show());}}).addOnFailureListener(e->card("تعذر تحميل الفصول: "+e.getLocalizedMessage(),MUTED));
    button("العودة إلى إدارة المنهج",TEAL,BLUE,()->teacherPdfManager());
  }
  void loadTeacherLectureList(){
    try{
      JSONObject req=new JSONObject();req.put("action","listLectures");
      AppsScriptApi.post(req,(result,error)->{
        if(error!=null){card("تعذر تحميل قائمة الفصول: "+error.getMessage(),MUTED);return;}
        JSONArray items=result==null?null:result.optJSONArray("lectures");
        if(items==null||items.length()==0){card("لا توجد ملفات PDF مرفوعة حالياً.",MUTED);return;}
        sectionTitle("الفصول المرفوعة — حذف أو استبدال");
        for(int i=0;i<items.length();i++){
          JSONObject item=items.optJSONObject(i);if(item==null)continue;
          final String fileId=item.optString("fileId",""), title=item.optString("title","ملف PDF");
          if(fileId.isEmpty())continue;
          card(title,DEEP);
          button("استبدال هذا الفصل بنسخة جديدة",TEAL,BLUE,()->{
            pendingReplaceFileId=fileId;pendingReplaceTitle=title;
            chooseLecturePdf();
          });
          button("حذف هذا الفصل",Color.RED,DEEP,()->new AlertDialog.Builder(this)
            .setTitle("تأكيد حذف الفصل")
            .setMessage("هل تريد حذف «"+title+"»؟ لن يظهر للطلاب بعد الحذف.")
            .setNegativeButton("إلغاء",null)
            .setPositiveButton("حذف",(d,w)->deleteLecturePdf(fileId))
            .show());
        }
      });
    }catch(Exception e){card("تعذر تجهيز قائمة الملفات.",MUTED);}
  }
  void deleteLecturePdf(String fileId){
    if(!teacher)return;
    try{
      FirebaseUser u=teacherAuth==null?null:teacherAuth.getCurrentUser();
      if(u==null){msg("سجّل دخول الأستاذ مجدداً.");return;}
      u.getIdToken(false).addOnSuccessListener(t->{
        try{
          JSONObject req=new JSONObject();req.put("action","deleteLecture");req.put("fileId",fileId);req.put("teacherIdToken",t.getToken());
          AppsScriptApi.post(req,(r,e)->{
            if(e!=null){msg("تعذر حذف الملف: "+e.getMessage());return;}
            if(r==null||!r.optBoolean("success")){msg(r==null?"لم يصل رد الخادم.":r.optString("message","فشل الحذف."));return;}
            db.collection("appConfig").document("content").set(new HashMap<String,Object>(){{put("contentVersion",FieldValue.increment(1));put("updatedAt",FieldValue.serverTimestamp());}},SetOptions.merge());msg("تم حذف الفصل من قائمة المنهج.");teacherPdfManager();
          });
        }catch(Exception ex){msg("تعذر تجهيز طلب الحذف.");}
      }).addOnFailureListener(e->msg("تعذر التحقق من حساب الأستاذ."));
    }catch(Exception e){msg("حدث خطأ أثناء الحذف.");}
  }
  void videoLibrary(){page("محاضرات الفيديو");card("المحاضرات المصورة",NAVY);card("ستظهر هنا فيديوهات الفصول الدراسية بعد ربط خدمة استضافة الفيديو الآمنة.",MUTED);card("الأستاذ فقط يستطيع إضافة الفيديوهات أو تعديلها أو حذفها. الطالب يستطيع المشاهدة فقط.",TEAL);if(teacher)button("إدارة الفيديوهات (تجهيز الربط)",PURPLE,DEEP,()->teacherVideoManager());button("العودة للرئيسية",BLUE,TEAL,()->studentHome());}
  void teacherVideoManager(){if(!teacher){msg("هذه الصفحة مخصصة للأستاذ فقط.");return;}page("إدارة محاضرات الفيديو");card("واجهة إدارة الفيديوهات",NAVY);card("سيتم تفعيل اختيار الفيديو من الهاتف ورفعه إلى مساحة تخزين خاصة بعد إعداد خدمة الاستضافة. لن نعرض زر رفع وهمياً قبل ربط الخدمة فعلياً.",MUTED);button("العودة إلى لوحة الأستاذ",PURPLE,DEEP,()->teacherPanel());}
  void checkAppsScriptApproval(){checkFirebaseAccess();}
  void chapters(){checkFirebaseAccess();}
  void showChapters(){
    page("الفصول الدراسية");
    TextView intro=txt("استكشف الكيمياء الحيوية\nفصول تعليمية • أسئلة تفاعلية • تصحيح فوري",17,DEEP,true);intro.setGravity(Gravity.CENTER);intro.setBackground(solid(Color.WHITE,22));panel.addView(intro);
    loadCustomChapters(()->{
      for(String ch:activeChapters()){final String chapter=ch;TextView item=txt(arabicChapter(chapter)+"     ❯",18,Color.WHITE,true);item.setGravity(Gravity.CENTER);item.setPadding(18,13,18,13);item.setBackground(grad(DEEP,PURPLE,28));item.setElevation(5);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,5,0,6);panel.addView(item,lp);item.setOnClickListener(v->requireOnline(()->begin(chapter)));}
      button("محاضرات الفيديو",TEAL,BLUE,()->checkFirebaseAccess());button("نتائجي وتقدمي",PURPLE,DEEP,()->studentResults());button("العودة للرئيسية",BLUE,TEAL,()->studentHome());
    });
  }
  void begin(String chapter){selectedChapter=chapter;exam.clear();
    // Start from the bundled bank, then overlay the teacher's live Firestore edits/deletions.
    for(int i=0;i<bank.length();i++){JSONObject q=bank.optJSONObject(i);if(q!=null)exam.add(q);}
    if(db==null){filterExamForChapter(chapter);launchExam();return;}
    db.collection("questionDeletes").get().addOnSuccessListener(deleted->{
      HashSet<String> removed=new HashSet<>();for(DocumentSnapshot d:deleted.getDocuments())removed.add(d.getId());
      for(int i=exam.size()-1;i>=0;i--)if(removed.contains(exam.get(i).optString("id")))exam.remove(i);
      db.collection("questionEdits").get().addOnSuccessListener(edits->{
        for(DocumentSnapshot doc:edits.getDocuments())for(JSONObject q:exam)if(doc.getId().equals(q.optString("id"))){try{applyEdit(q,doc);}catch(Exception ignored){}break;}
        // Filter AFTER applying edits so moving a question to another chapter works correctly.
        filterExamForChapter(chapter);
        db.collection("questions").whereEqualTo("chapter",chapter).get().addOnSuccessListener(snapshot->{
          for(DocumentSnapshot doc:snapshot.getDocuments())try{JSONObject q=new JSONObject();q.put("id",doc.getId());q.put("chapter",chapter);q.put("question",doc.getString("question"));q.put("answer",doc.getString("answer"));q.put("explanation",doc.getString("explanation"));List<String> opts=(List<String>)doc.get("options");q.put("options",new JSONArray(opts==null?new ArrayList<>():opts));q.put("difficulty","Teacher-added");exam.add(q);}catch(Exception ignored){}
          launchExam();
        }).addOnFailureListener(e->{msg("تعذر تحميل أسئلة الأستاذ من الإنترنت. تحقق من الاتصال ثم أعد المحاولة.");});
      }).addOnFailureListener(e->{msg("تعذر مزامنة تعديلات الأسئلة. تحقق من الاتصال ثم أعد المحاولة.");});
    }).addOnFailureListener(e->{msg("تعذر مزامنة قائمة الأسئلة. تحقق من الاتصال ثم أعد المحاولة.");});
  }
  void filterExamForChapter(String chapter){
    for(int i=exam.size()-1;i>=0;i--){JSONObject q=exam.get(i);String qChapter=q.optString("chapter");if(!(chapter.equals(qChapter)||("Enzyme".equals(chapter)&&"Enzymes".equals(qChapter))))exam.remove(i);}
  }
  void applyEdit(JSONObject q,DocumentSnapshot d)throws Exception{if(d.getString("chapter")!=null)q.put("chapter",d.getString("chapter"));if(d.getString("question")!=null)q.put("question",d.getString("question"));if(d.getString("answer")!=null)q.put("answer",d.getString("answer"));if(d.getString("explanation")!=null)q.put("explanation",d.getString("explanation"));List<String> opts=(List<String>)d.get("options");if(opts!=null)q.put("options",new JSONArray(opts));}
  void launchExam(){if(exam.isEmpty()){new AlertDialog.Builder(this).setTitle(selectedChapter).setMessage("No questions are available in this chapter yet.").setPositiveButton("Back",(d,w)->chapters()).show();return;}Collections.shuffle(exam);index=0;correct=0;showQuestion();}
  void showQuestion(){
    if(index>=exam.size()){finishExam();return;}JSONObject q=exam.get(index);page(arabicChapter(selectedChapter));
    TextView banner=txt("اختبار الكيمياء الحيوية  •  "+arabicChapter(selectedChapter),16,Color.WHITE,true);banner.setGravity(Gravity.CENTER);banner.setBackground(grad(DEEP,PURPLE,24));panel.addView(banner,new LinearLayout.LayoutParams(-1,-2));
    TextView progress=txt("السؤال  "+(index+1)+" من "+exam.size()+"     •     "+q.optString("difficulty","متوسط"),16,DEEP,true);progress.setGravity(Gravity.CENTER);progress.setBackground(solid(Color.WHITE,18));panel.addView(progress);
    TextView instruction=txt("اختر الإجابة الصحيحة الواحدة",14,MUTED,false);instruction.setGravity(Gravity.RIGHT);panel.addView(instruction);
    TextView question=txt(q.optString("question"),21,Color.WHITE,true);question.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);question.setTextDirection(View.TEXT_DIRECTION_LTR);question.setBackground(grad(DEEP,PURPLE,24));question.setPadding(18,22,18,22);question.setElevation(4);panel.addView(question);
    JSONArray opts=q.optJSONArray("options");if(opts==null){msg("تعذر تحميل اختيارات السؤال.");index++;showQuestion();return;}
    ArrayList<String> visibleOptions=new ArrayList<>();for(int i=0;i<opts.length();i++){String value=opts.optString(i,"").trim();if(!value.isEmpty())visibleOptions.add(value);}
    if(visibleOptions.size()<2){msg("السؤال يحتاج إلى مراجعة من الأستاذ.");index++;showQuestion();return;}
    String ans=q.optString("answer");
    for(int i=0;i<visibleOptions.size();i++){final int choice=i;String optionText=visibleOptions.get(i);String label=letters[Math.min(i,letters.length-1)]+"     "+optionText;TextView option=txt(label,17,NAVY,true);option.setTextDirection(View.TEXT_DIRECTION_LTR);option.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);option.setPadding(18,14,14,14);int bg=Color.WHITE;if(answered&&optionText.equals(ans))bg=Color.rgb(218,250,228);else if(answered&&i==selectedChoice)bg=Color.rgb(255,230,230);option.setBackground(outlineBox(bg,answered&&optionText.equals(ans)?GREEN:PURPLE,24));option.setElevation(3);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,6,0,6);panel.addView(option,lp);option.setOnClickListener(v->{if(!answered)answer(choice);});}
    if(answered){
      boolean ok=selectedChoice>=0&&selectedChoice<visibleOptions.size()&&visibleOptions.get(selectedChoice).equals(ans);
      TextView status=txt(ok?"✓  إجابة صحيحة":"✕  إجابة غير صحيحة",20,ok?Color.rgb(0,125,45):Color.rgb(175,35,35),true);status.setGravity(Gravity.CENTER);status.setBackground(solid(ok?Color.rgb(218,250,228):Color.rgb(255,232,232),24));panel.addView(status);
      TextView correctBox=txt("الإجابة الصحيحة:  "+ans,16,NAVY,true);correctBox.setBackground(solid(Color.WHITE,18));panel.addView(correctBox);
      TextView explanation=txt("التفسير:\n"+q.optString("explanation"),15,NAVY,false);explanation.setBackground(solid(Color.WHITE,18));panel.addView(explanation);
    }
    LinearLayout nav=new LinearLayout(this);nav.setOrientation(LinearLayout.HORIZONTAL);LinearLayout.LayoutParams navp=new LinearLayout.LayoutParams(-1,-2);navp.setMargins(0,10,0,0);panel.addView(nav,navp);
    Button prev=new Button(this);prev.setText("السابق");prev.setAllCaps(false);prev.setTextColor(Color.WHITE);prev.setBackground(grad(PURPLE,DEEP,24));nav.addView(prev,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));prev.setOnClickListener(v->{if(index>0){index--;answered=false;selectedChoice=-1;showQuestion();}});
    Button next=new Button(this);next.setText(index==exam.size()-1?"إنهاء":"التالي");next.setAllCaps(false);next.setTextColor(Color.WHITE);next.setBackground(grad(TEAL,BLUE,24));LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1);np.setMargins(8,0,0,0);nav.addView(next,np);next.setOnClickListener(v->{if(!answered){msg("اختر إجابة أولاً.");return;}if(index==exam.size()-1)finishExam();else{index++;answered=false;selectedChoice=-1;showQuestion();}});
  }
  void answer(int choice){JSONObject q=exam.get(index);JSONArray opts=q.optJSONArray("options");ArrayList<String> visible=new ArrayList<>();if(opts!=null)for(int i=0;i<opts.length();i++){String value=opts.optString(i,"").trim();if(!value.isEmpty())visible.add(value);}selectedChoice=choice;answered=true;if(choice>=0&&choice<visible.size()&&visible.get(choice).equals(q.optString("answer")))correct++;showQuestion();}
  void finishExam(){int total=exam.size(),wrong=total-correct;double pct=total==0?0:100.0*correct/total;saveResult(correct,wrong,pct,total);
    page("نتيجة الفصل");TextView result=txt("✓  Exam Completed!\\n\\n"+selectedChapter+"\\n\\n"+correct+" / "+total+"\\n"+String.format(Locale.US,"%.1f%%",pct)+"\\n\\nCorrect: "+correct+"     Wrong: "+wrong,23,NAVY,true);result.setGravity(Gravity.CENTER);result.setBackground(grad(Color.rgb(236,250,255),Color.rgb(245,239,255),26));panel.addView(result);
    button("Review Answers",PURPLE,BLUE,()->reviewAnswers());button("My Overall Results",TEAL,BLUE,()->studentResults());button("العودة إلى الفصول",BLUE,TEAL,()->chapters());}
  void saveResult(int c,int w,double pct,int total){if(db==null||auth==null||auth.getCurrentUser()==null)return;Map<String,Object> r=new HashMap<>();r.put("studentName",studentName);r.put("studentUid",auth.getCurrentUser().getUid());r.put("chapter",selectedChapter);r.put("correct",c);r.put("wrong",w);r.put("total",total);r.put("percentage",pct);r.put("createdAt",FieldValue.serverTimestamp());db.collection("results").add(r);}
  void reviewAnswers(){page("مراجعة الإجابات");for(int i=0;i<exam.size();i++){JSONObject q=exam.get(i);card("Q"+(i+1)+": "+q.optString("question"),NAVY);card("Correct answer: "+q.optString("answer"),TEAL);card(q.optString("explanation"),MUTED);}button("رجوع إلى الفصول",BLUE,TEAL,()->chapters());}
  void studentResults(){if(db==null||auth==null||auth.getCurrentUser()==null){page("My Results");card("Firebase connection is required to load saved results.",MUTED);return;}page("My Results");db.collection("results").whereEqualTo("studentUid",auth.getCurrentUser().getUid()).get().addOnSuccessListener(s->{panel.removeAllViews();if(s.isEmpty()){card("No saved results yet.",MUTED);return;}Map<String,int[]> sums=new LinkedHashMap<>();for(DocumentSnapshot d:s.getDocuments()){String ch=d.getString("chapter");int[] a=sums.get(ch);if(a==null){a=new int[3];sums.put(ch,a);}a[0]+=num(d,"correct");a[1]+=num(d,"wrong");a[2]+=num(d,"total");}
      int c=0,w=0,t=0;for(Map.Entry<String,int[]> e:sums.entrySet()){int[] a=e.getValue();c+=a[0];w+=a[1];t+=a[2];card(e.getKey()+"\\nCorrect: "+a[0]+"   Wrong: "+a[1]+"\\nScore: "+String.format(Locale.US,"%.1f%%",a[2]==0?0:100.0*a[0]/a[2]),NAVY);}card("OVERALL TOTAL\\nCorrect: "+c+"   Wrong: "+w+"   Score: "+String.format(Locale.US,"%.1f%%",t==0?0:100.0*c/t),TEAL);
    }).addOnFailureListener(e->card("Could not load results. Check connection.",MUTED));}
  int num(DocumentSnapshot d,String k){Long n=d.getLong(k);return n==null?0:n.intValue();}
  void teacherGate(String destination){
    LinearLayout form=new LinearLayout(this);form.setOrientation(1);form.setPadding(24,8,24,8);
    EditText email=new EditText(this);email.setSingleLine(true);email.setHint("البريد الإلكتروني للمدرّس");email.setInputType(33);email.setText("Ahmedalksher70@gmail.com");form.addView(email);
    EditText password=new EditText(this);password.setSingleLine(true);password.setHint("كلمة المرور");password.setInputType(129);form.addView(password);
    new AlertDialog.Builder(this).setTitle("دخول المدرّس").setView(form).setPositiveButton("دخول",(d,w)->verifyTeacher(email.getText().toString().trim(),password.getText().toString(),destination)).setNegativeButton("إلغاء",null).show();
  }
  void verifyTeacher(String email,String password,String dest){
    if(!hasInternet()){msg("يلزم الاتصال بالإنترنت.");return;}if(!"ahmedalksher70@gmail.com".equalsIgnoreCase(email)){msg("البريد غير مصرح له بدخول لوحة المدرّس.");return;}
    if(teacherAuth==null||teacherDb==null){msg("جلسة المدرّس غير مهيأة.");return;}
    teacherAuth.signInWithEmailAndPassword(email,password).addOnSuccessListener(r->{
      auth=teacherAuth;db=teacherDb;teacher=true;teacherPinSession="email-auth";
      if("panel".equals(dest))teacherPanel();else getTeacherToken(dest);
    }).addOnFailureListener(e->msg("تعذر دخول المدرّس: "+e.getLocalizedMessage()+". تأكد من كلمة المرور وتفعيل Email/Password في Firebase."));
  }
  void getTeacherToken(String dest){if("panel".equals(dest))teacherPanel();else if("results".equals(dest))teacherResults();else if("add".equals(dest))addQuestion();else if("edit".equals(dest))editQuestionPicker();else if("password".equals(dest))changePasswordForm();}
  void teacherPanel(){if(!teacher){msg("غير مصرح بالدخول");return;}page("لوحة الأستاذ");card("إدارة المنصة والطلاب والمحتوى التعليمي",DEEP);button("طلبات تسجيل الطلاب والموافقة",TEAL,BLUE,()->teacherStudents());button("إرسال رسالة داخل التطبيق",BLUE,TEAL,()->sendInAppNotificationForm());button("إرسال إشعار إلى الهاتف",PURPLE,DEEP,()->sendPhonePushNotificationForm());button("نتائج الطلاب",PURPLE,BLUE,()->teacherResults());button("إدارة محاضرات الفيديو",PURPLE,DEEP,()->teacherVideoManager());button("إضافة ملفات المنهج PDF",TEAL,BLUE,()->teacherPdfManager());button("استيراد بنك أسئلة من ملف",TEAL,BLUE,()->chooseQuestionImportFile());button("إضافة سؤال يدوياً",TEAL,BLUE,()->addQuestion());button("تعديل أو حذف سؤال",PURPLE,DEEP,()->editQuestionPicker());button("تغيير كلمة مرور المدرّس",BLUE,TEAL,()->changePasswordForm());button("تسجيل خروج الأستاذ",Color.GRAY,MUTED,()->{teacherAuth.signOut();teacher=false;teacherPinSession="";auth=studentAuth;db=studentDb;home();});}
  void teacherStudents(){
    if(!teacher){msg("غير مصرح بالدخول");return;}page("طلبات تسجيل الطلاب");card("جارٍ تحميل الطلبات...",MUTED);
    db.collection("students").orderBy("requestedAt",Query.Direction.DESCENDING).limit(300).get().addOnSuccessListener(snapshot->{panel.removeAllViews();if(snapshot.isEmpty()){card("لا توجد طلبات تسجيل حالياً.",MUTED);return;}for(DocumentSnapshot st:snapshot.getDocuments()){String uid=st.getId(),name=st.getString("name"),phone=st.getString("phone"),status=st.getString("status");card((name==null?"":name)+"\n"+(phone==null?"":phone)+"\nالحالة: "+status,NAVY);if(!"Approved".equals(status)){button("قبول الطالب وتحديد المدة",TEAL,BLUE,()->chooseSubscription(uid));button("رفض الطلب",PURPLE,DEEP,()->decideStudent(uid,"Rejected",0));}else{button("تجديد الاشتراك",TEAL,BLUE,()->chooseSubscription(uid));button("إيقاف الاشتراك",PURPLE,DEEP,()->decideStudent(uid,"Rejected",0));}}}).addOnFailureListener(e->msg("تعذر تحميل الطلبات من Firestore: "+e.getLocalizedMessage()));
  }
  void chooseSubscription(String uid){String[] labels={"شهر واحد — 30 يوماً","3 أشهر — 90 يوماً","6 أشهر — 180 يوماً","سنة — 365 يوماً"};int[] days={30,90,180,365};new AlertDialog.Builder(this).setTitle("مدة اشتراك الطالب").setItems(labels,(d,w)->decideStudent(uid,"Approved",days[w])).setNegativeButton("إلغاء",null).show();}
  void decideStudent(String uid,String decision,int days){Map<String,Object> data=new HashMap<>();data.put("status",decision);data.put("decidedAt",FieldValue.serverTimestamp());if(days>0){Timestamp start=Timestamp.now();data.put("subscriptionDays",days);data.put("activatedAt",start);data.put("expiresAt",new Timestamp(new Date(start.toDate().getTime()+days*86400000L)));}else{data.put("expiresAt",null);}db.collection("students").document(uid).update(data).addOnSuccessListener(v->{msg("تم تحديث حالة الطالب.");teacherStudents();}).addOnFailureListener(e->msg("تعذر تحديث الطالب: "+e.getLocalizedMessage()));}
  void teacherResults(){if(!teacher){msg("Not authorized");return;}page("Students Results");db.collection("results").orderBy("createdAt",Query.Direction.DESCENDING).limit(1000).get().addOnSuccessListener(s->{panel.removeAllViews();Map<String,Map<String,int[]>> students=new LinkedHashMap<>();Map<String,String> names=new HashMap<>();for(DocumentSnapshot d:s.getDocuments()){String uid=d.getString("studentUid");if(uid==null)continue;names.put(uid,d.getString("studentName"));Map<String,int[]> by=students.get(uid);if(by==null){by=new LinkedHashMap<>();students.put(uid,by);}String ch=d.getString("chapter");int[] a=by.get(ch);if(a==null){a=new int[3];by.put(ch,a);}a[0]+=num(d,"correct");a[1]+=num(d,"wrong");a[2]+=num(d,"total");}
      for(String uid:students.keySet()){card("STUDENT: "+names.get(uid),PURPLE);int c=0,w=0,t=0;for(Map.Entry<String,int[]> e:students.get(uid).entrySet()){int[] a=e.getValue();c+=a[0];w+=a[1];t+=a[2];card(e.getKey()+"\\nCorrect "+a[0]+" • Wrong "+a[1]+" • "+String.format(Locale.US,"%.1f%%",a[2]==0?0:100.0*a[0]/a[2]),NAVY);}card("TOTAL: "+c+" correct • "+w+" wrong • "+String.format(Locale.US,"%.1f%%",t==0?0:100.0*c/t),TEAL);}
    }).addOnFailureListener(e->msg("Could not load teacher results. Check Firestore rules."));}

  void chooseQuestionImportFile(){
    if(!teacher){msg("هذه الخاصية للأستاذ فقط.");return;}
    loadCustomChapters(()->openQuestionImportPicker());
  }
  void openQuestionImportPicker(){
    android.content.Intent intent=new android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT);
    intent.addCategory(android.content.Intent.CATEGORY_OPENABLE);intent.setType("application/json");
    startActivityForResult(intent,PICK_QUESTION_JSON);
  }
  void readQuestionImportFile(android.net.Uri uri){
    if(!teacher){msg("هذه الخاصية للأستاذ فقط.");return;}
    try{
      java.io.InputStream in=getContentResolver().openInputStream(uri);if(in==null){msg("تعذر قراءة الملف.");return;}
      java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] buf=new byte[8192];int n;
      while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>10*1024*1024){in.close();msg("ملف بنك الأسئلة أكبر من 10 MB.");return;}}in.close();
      JSONObject rootJson=new JSONObject(new String(out.toByteArray(),"UTF-8"));JSONArray arr=rootJson.optJSONArray("questions");
      if(arr==null||arr.length()==0){msg("صيغة الملف غير صحيحة. يجب أن يحتوي على questions.");return;}
      JSONArray valid=new JSONArray();int skipped=0;
      for(int i=0;i<arr.length();i++){
        JSONObject q=arr.optJSONObject(i);if(q==null){skipped++;continue;}
        String chapter=q.optString("chapter").trim(),stem=q.optString("question").trim(),answer=q.optString("answer").trim(),ex=q.optString("explanation","").trim();JSONArray options=q.optJSONArray("options");
        if(!Arrays.asList(activeChapters()).contains(chapter)||stem.isEmpty()||answer.isEmpty()||options==null||options.length()!=4){skipped++;continue;}
        HashSet<String> unique=new HashSet<>();boolean ok=true;boolean hasAnswer=false;for(int j=0;j<4;j++){String op=options.optString(j).trim();if(op.isEmpty()||!unique.add(op))ok=false;if(op.equals(answer))hasAnswer=true;}
        if(!ok||!hasAnswer){skipped++;continue;}
        JSONObject clean=new JSONObject();clean.put("chapter",chapter);clean.put("question",stem);clean.put("options",options);clean.put("answer",answer);clean.put("explanation",ex);valid.put(clean);
      }
      if(valid.length()==0){msg("لم أجد أسئلة صالحة. تأكد من اسم الفصل وأربعة اختيارات والإجابة الصحيحة.");return;}
      pendingImportQuestions=valid;
      new AlertDialog.Builder(this).setTitle("معاينة بنك الأسئلة").setMessage("الأسئلة الصالحة: "+valid.length()+"\nالأسئلة التي تم تجاهلها: "+skipped+"\n\nسيتم إضافة الأسئلة إلى القديمة ولن تُحذف الأسئلة الحالية. هل تريد النشر؟")
        .setNegativeButton("مراجعة لاحقاً",(d,w)->teacherPanel()).setPositiveButton("اعتماد ونشر",(d,w)->publishImportedQuestions()).show();
    }catch(Exception e){msg("تعذر قراءة ملف JSON: "+e.getLocalizedMessage());}
  }
  void publishImportedQuestions(){
    if(!teacher||pendingImportQuestions.length()==0){msg("لا توجد أسئلة جاهزة للنشر.");return;}
    FirebaseUser user=teacherAuth==null?null:teacherAuth.getCurrentUser();if(user==null){msg("انتهت جلسة الأستاذ. سجّل الدخول مجدداً.");return;}
    final int total=pendingImportQuestions.length();final int[] position={0};
    card("جارٍ نشر "+total+" سؤالاً إلى قاعدة البيانات...",MUTED);
    publishImportChunk(total,position);
  }
  void publishImportChunk(int total,int[] position){
    if(position[0]>=total){
      Map<String,Object> config=new HashMap<>();config.put("contentVersion",FieldValue.increment(1));config.put("updatedAt",FieldValue.serverTimestamp());config.put("lastImportCount",total);config.put("updatedBy",teacherAuth.getCurrentUser().getUid());
      db.collection("appConfig").document("content").set(config,SetOptions.merge()).addOnSuccessListener(v->{pendingImportQuestions=new JSONArray();msg("تم نشر "+total+" سؤالاً بنجاح. ستظهر للطلاب عند فتح الاختبار أو بنك الأسئلة، دون تحديث APK.");teacherPanel();}).addOnFailureListener(e->msg("تم رفع الأسئلة، لكن تعذر تحديث رقم إصدار المحتوى: "+e.getLocalizedMessage()));return;
    }
    WriteBatch batch=db.batch();int end=Math.min(position[0]+400,total);
    for(int i=position[0];i<end;i++)try{JSONObject q=pendingImportQuestions.getJSONObject(i);Map<String,Object> m=new HashMap<>();m.put("chapter",q.getString("chapter"));m.put("question",q.getString("question"));ArrayList<String> opts=new ArrayList<>();JSONArray a=q.getJSONArray("options");for(int j=0;j<a.length();j++)opts.add(a.getString(j));m.put("options",opts);m.put("answer",q.getString("answer"));m.put("explanation",q.optString("explanation",""));m.put("createdBy",teacherAuth.getCurrentUser().getUid());m.put("createdAt",FieldValue.serverTimestamp());m.put("source","teacher-json-import");String stable=sha256(q.getString("chapter")+"|"+q.getString("question")+"|"+opts.toString()+"|"+q.getString("answer"));batch.set(db.collection("questions").document("import_"+stable),m);}catch(Exception ignored){}
    final int next=end;batch.commit().addOnSuccessListener(v->{position[0]=next;publishImportChunk(total,position);}).addOnFailureListener(e->msg("توقف نشر الأسئلة عند "+position[0]+" من "+total+". السبب: "+e.getLocalizedMessage()));
  }
  void addQuestion(){if(!teacher){msg("Not authorized");return;}page("Add a Question");
    Spinner chapter=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,activeChapters());chapter.setAdapter(adapter);panel.addView(chapter);loadCustomChapters(()->{ArrayAdapter<String> fresh=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,activeChapters());chapter.setAdapter(fresh);});
    EditText q=field("Question"),a=field("Option A"),b=field("Option B"),c=field("Option C"),d=field("Option D"),ans=field("Correct answer (exact option text)"),ex=field("Explanation");
    button("Save Question",PURPLE,BLUE,()->{String stem=q.getText().toString().trim(),answer=ans.getText().toString().trim();List<String> opts=Arrays.asList(a.getText().toString().trim(),b.getText().toString().trim(),c.getText().toString().trim(),d.getText().toString().trim());if(stem.isEmpty()||opts.contains("")||answer.isEmpty()){msg("Complete all required fields.");return;}if(new HashSet<>(opts).size()!=4||!opts.contains(answer)){msg("Options must be unique and answer must match one option.");return;}Map<String,Object> m=new HashMap<>();m.put("chapter",chapter.getSelectedItem().toString());m.put("question",stem);m.put("options",opts);m.put("answer",answer);m.put("explanation",ex.getText().toString().trim());m.put("createdBy",auth.getCurrentUser().getUid());m.put("createdAt",FieldValue.serverTimestamp());db.collection("questions").add(m).addOnSuccessListener(r->{msg("تم حفظ السؤال بنجاح، وسيظهر للطلاب في هذا الفصل.");teacherPanel();}).addOnFailureListener(e->msg("تعذر حفظ السؤال في Firestore: "+e.getLocalizedMessage()));});
    button("العودة إلى لوحة الأستاذ",Color.GRAY,MUTED,()->teacherPanel());}
  void editQuestionPicker(){if(!teacher){msg("Not authorized");return;}loadCustomChapters(()->{});page("Choose a Question to Edit or Delete");card("أسئلة المنهج الأصلية",DEEP);
    for(int i=0;i<bank.length();i++){JSONObject q=bank.optJSONObject(i);if(q==null)continue;final JSONObject selected=q;final String id=q.optString("id");if(id.isEmpty())continue;button(id+" • "+q.optString("chapter")+"\n"+q.optString("question"),PURPLE,BLUE,()->editQuestionForm(selected,id));}
    sectionTitle("الأسئلة التي أضافها الأستاذ");
    db.collection("questions").get().addOnSuccessListener(snapshot->{for(DocumentSnapshot doc:snapshot.getDocuments()){try{JSONObject q=new JSONObject();q.put("id",doc.getId());q.put("teacherAdded",true);q.put("chapter",doc.getString("chapter"));q.put("question",doc.getString("question"));q.put("answer",doc.getString("answer"));q.put("explanation",doc.getString("explanation"));List<String> opts=(List<String>)doc.get("options");q.put("options",new JSONArray(opts==null?new ArrayList<>():opts));button("[جديد] "+q.optString("chapter")+"\n"+q.optString("question"),TEAL,BLUE,()->editQuestionForm(q,doc.getId()));}catch(Exception ignored){}}}).addOnFailureListener(e->msg("تعذر تحميل الأسئلة المضافة: "+e.getLocalizedMessage()));
    button("العودة إلى لوحة الأستاذ",Color.GRAY,MUTED,()->teacherPanel());}
  void editQuestionForm(JSONObject q,String id){page("Edit Question / Answer");card("Question ID: "+id,TEAL);EditText ch=field("Chapter");ch.setText(q.optString("chapter"));EditText stem=field("Question");stem.setText(q.optString("question"));JSONArray old=q.optJSONArray("options");EditText[] o=new EditText[4];for(int i=0;i<4;i++){o[i]=field("Option "+letters[i]);o[i].setText(old==null?"":old.optString(i));}EditText ans=field("Correct answer — exact option text");ans.setText(q.optString("answer"));EditText ex=field("Explanation");ex.setText(q.optString("explanation"));
    button("Save Changes",PURPLE,DEEP,()->{List<String> opts=new ArrayList<>();for(EditText x:o)opts.add(x.getText().toString().trim());if(stem.length()==0||!Arrays.asList(activeChapters()).contains(ch.getText().toString().trim())||new HashSet<>(opts).size()!=4||opts.contains("")||!opts.contains(ans.getText().toString().trim())){msg("Check question, four unique options, and correct answer.");return;}Map<String,Object> m=new HashMap<>();m.put("id",id);m.put("chapter",ch.getText().toString().trim());m.put("question",stem.getText().toString().trim());m.put("options",opts);m.put("answer",ans.getText().toString().trim());m.put("explanation",ex.getText().toString().trim());m.put("updatedBy",auth.getCurrentUser().getUid());m.put("updatedAt",FieldValue.serverTimestamp());if(q.optBoolean("teacherAdded")){db.collection("questions").document(id).update(m).addOnSuccessListener(v->{msg("تم تحديث السؤال المضاف.");editQuestionPicker();}).addOnFailureListener(e->msg("تعذر تحديث السؤال: "+e.getLocalizedMessage()));}else{db.collection("questionEdits").document(id).set(m,SetOptions.merge()).addOnSuccessListener(v->{msg("تم حفظ التعديلات وستظهر في الاختبارات التالية.");editQuestionPicker();}).addOnFailureListener(e->msg("تعذر حفظ التعديل: "+e.getLocalizedMessage()));}});
    button("حذف هذا السؤال",Color.rgb(170,35,55),DEEP,()->new AlertDialog.Builder(this).setTitle("تأكيد الحذف").setMessage("هل تريد حذف السؤال نهائياً من بنك الأسئلة؟").setNegativeButton("إلغاء",null).setPositiveButton("حذف",(dialog,which)->{if(q.optBoolean("teacherAdded")){db.collection("questions").document(id).delete().addOnSuccessListener(v->{msg("تم حذف السؤال.");editQuestionPicker();}).addOnFailureListener(e->msg("تعذر الحذف: "+e.getLocalizedMessage()));}else{Map<String,Object> marker=new HashMap<>();marker.put("deleted",true);marker.put("deletedAt",FieldValue.serverTimestamp());marker.put("deletedBy",auth.getCurrentUser().getUid());db.collection("questionDeletes").document(id).set(marker).addOnSuccessListener(v->{msg("تم إخفاء السؤال من اختبارات الطلاب.");editQuestionPicker();}).addOnFailureListener(e->msg("تعذر حذف السؤال: "+e.getLocalizedMessage()));}}).show());
    button("العودة",Color.GRAY,MUTED,()->editQuestionPicker());}
  void changePasswordForm(){if(!teacher){msg("Not authorized");return;}page("Change Teacher Password");EditText current=field("Current password");current.setInputType(129);EditText next=field("New password (at least 8 characters)");next.setInputType(129);EditText confirm=field("Confirm new password");confirm.setInputType(129);
    button("Update Password",PURPLE,DEEP,()->{String n=next.getText().toString();if(n.length()<8){next.setError("Use at least 8 characters");return;}if(!n.equals(confirm.getText().toString())){confirm.setError("Passwords do not match");return;}FirebaseUser user=teacherAuth.getCurrentUser();if(user==null||user.getEmail()==null){msg("يرجى تسجيل دخول الأستاذ من جديد.");return;}com.google.firebase.auth.AuthCredential credential=com.google.firebase.auth.EmailAuthProvider.getCredential(user.getEmail(),current.getText().toString());user.reauthenticate(credential).addOnSuccessListener(v->user.updatePassword(n).addOnSuccessListener(x->{msg("تم تغيير كلمة المرور بنجاح.");teacherPanel();}).addOnFailureListener(e->msg("تعذر تغيير كلمة المرور: "+e.getLocalizedMessage()))).addOnFailureListener(e->msg("كلمة المرور الحالية غير صحيحة: "+e.getLocalizedMessage()));});
    button("العودة",Color.GRAY,MUTED,()->teacherPanel());}
  void msg(String s){new AlertDialog.Builder(this).setMessage(s).setPositiveButton("OK",null).show();}
}
