package com.biochem.easy;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.spec.ECGenParameterSpec;

/**
 * Creates an app-installation identity backed by Android Keystore.
 * The private key is non-exportable; only a SHA-256 fingerprint of its
 * public key is sent to the backend as the device binding identifier.
 */
public final class DeviceIdentity {
    private static final String STORE = "AndroidKeyStore";
    private static final String ALIAS = "bio_alksher_device_binding_v1";

    private DeviceIdentity() {}

    public static String getDeviceKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance(STORE);
        keyStore.load(null);

        if (!keyStore.containsAlias(ALIAS)) {
            KeyPairGenerator generator = KeyPairGenerator.getInstance(
                    KeyProperties.KEY_ALGORITHM_EC, STORE);
            KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
                    ALIAS,
                    KeyProperties.PURPOSE_SIGN | KeyProperties.PURPOSE_VERIFY)
                    .setAlgorithmParameterSpec(new ECGenParameterSpec("secp256r1"))
                    .setDigests(KeyProperties.DIGEST_SHA256)
                    .setUserAuthenticationRequired(false)
                    .build();
            generator.initialize(spec);
            generator.generateKeyPair();
            keyStore.load(null);
        }

        PublicKey publicKey = keyStore.getCertificate(ALIAS).getPublicKey();
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(publicKey.getEncoded());
        return toHex(digest);
    }

    private static String toHex(byte[] bytes) {
        StringBuilder out = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) out.append(String.format(java.util.Locale.US, "%02x", b & 0xff));
        return out.toString();
    }
}
