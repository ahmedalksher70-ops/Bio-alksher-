# حالة تسجيل الدخول والمزامنة

- يحتفظ المشروع بمشروع Firebase الحالي `biochemistry-easy-with` وبمعرّف Android الحالي `com.biochem.easy`.
- تسجيل الطلاب وقراءة بياناتهم وإدارة الموافقة والاشتراكات تعتمد على Firebase Authentication وFirestore في النسخة المصدرية الحالية.
- حساب الأستاذ يستخدم Firebase Email/Password.
- لا يعتمد إصدار Android الحالي على Firebase Callable Functions.
- قواعد Firestore تحتاج مراجعة UID الأستاذ الفعلي قبل نشرها.
- إشعارات الهاتف تعتمد على FCM عبر Google Apps Script كما هو موضح في `INSTALL_LECTURE_PDF_AR.md`.
- لم يتم اختبار تسجيل الدخول أو الاشتراكات على أجهزة فعلية في هذه الحزمة.
