/**
 * Bio-alksher dynamic lecture PDF API.
 * Add this file as LectureFiles.gs in the EXISTING Apps Script project.
 * Then add the two routing lines shown in INSTALL_LECTURE_PDF_AR.md
 * inside the existing doPost(e), immediately after parsing `data`.
 */
function handleLectureFileAction_(data) {
  if (!data || !data.action) return null;

  if (data.action === 'uploadLecture') {
    if (!data.title || !data.fileName || !data.base64 || !data.teacherIdToken) {
      return json({success:false, message:'بيانات الملف أو جلسة الأستاذ غير مكتملة.'});
    }
    if (!isBioAlksherTeacher_(data.teacherIdToken)) {
      return json({success:false, message:'غير مصرح برفع ملفات المنهج. سجّل دخول الأستاذ.'});
    }
    if (String(data.mimeType || '') !== 'application/pdf') {
      return json({success:false, message:'يسمح بملفات PDF فقط.'});
    }
    // Enforce the same 25 MiB file limit as Android. Base64 transport increases request size.
    var bytes = Utilities.base64Decode(data.base64);
    if (bytes.length > 25 * 1024 * 1024) {
      return json({success:false, message:'حجم الملف يتجاوز 25 MB. الحد الأقصى للملف الواحد هو 25 MB.'});
    }

    var folderId = PropertiesService.getScriptProperties().getProperty('LECTURES_FOLDER_ID');
    var folder = folderId ? DriveApp.getFolderById(folderId) : DriveApp.getRootFolder();
    var blob = Utilities.newBlob(bytes, 'application/pdf', data.fileName);
    var file = folder.createFile(blob);
    // Google Drive link-sharing is required for students to open the file.
    // Anyone with the link can access it; do not upload confidential material.
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);

    var ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    var sheet = ss.getSheetByName('Lectures');
    if (!sheet) {
      sheet = ss.insertSheet('Lectures');
      sheet.appendRow(['fileId','title','fileName','url','createdAt','active']);
    }
    var replaced = false;
    var oldFileId = String(data.replaceFileId || '');
    if (oldFileId && sheet.getLastRow() >= 2) {
      var oldRows = sheet.getDataRange().getValues();
      for (var r = 1; r < oldRows.length; r++) {
        if (String(oldRows[r][0]) === oldFileId && (oldRows[r][5] === true || String(oldRows[r][5]).toLowerCase() === 'true')) {
          // Mark the old record inactive only after the new Drive file exists.
          sheet.getRange(r + 1, 6).setValue(false);
          try { DriveApp.getFileById(oldFileId).setTrashed(true); } catch (trashError) {}
          replaced = true;
          break;
        }
      }
    }
    sheet.appendRow([file.getId(), String(data.title), String(data.fileName),
      file.getUrl(), new Date(), true]);

    return json({success:true, title:String(data.title), url:file.getUrl(),
      fileId:file.getId(), replaced:replaced, message:replaced?'تم استبدال ملف المنهج.':'تم رفع ملف المنهج.'});
  }

  if (data.action === 'listLectures') {
    var ss2 = SpreadsheetApp.openById(SPREADSHEET_ID);
    var sheet2 = ss2.getSheetByName('Lectures');
    if (!sheet2 || sheet2.getLastRow() < 2) {
      return json({success:true, lectures:[]});
    }
    var rows = sheet2.getDataRange().getValues();
    var lectures = [];
    for (var i = 1; i < rows.length; i++) {
      if (rows[i][5] === true || String(rows[i][5]).toLowerCase() === 'true') {
        lectures.push({fileId:String(rows[i][0]), title:String(rows[i][1]), fileName:String(rows[i][2]),
          url:String(rows[i][3]), createdAt:rows[i][4]});
      }
    }
    lectures.reverse();
    return json({success:true, lectures:lectures});
  }
  if (data.action === 'deleteLecture') {
    if (!data.fileId || !data.teacherIdToken || !isBioAlksherTeacher_(data.teacherIdToken)) {
      return json({success:false, message:'غير مصرح بحذف ملفات المنهج.'});
    }
    var ss3 = SpreadsheetApp.openById(SPREADSHEET_ID);
    var sheet3 = ss3.getSheetByName('Lectures');
    if (!sheet3 || sheet3.getLastRow() < 2) return json({success:false, message:'الملف غير موجود.'});
    var rows3 = sheet3.getDataRange().getValues();
    for (var j = 1; j < rows3.length; j++) {
      if (String(rows3[j][0]) === String(data.fileId) && (rows3[j][5] === true || String(rows3[j][5]).toLowerCase() === 'true')) {
        // Remove from student list first, then move the Drive file to trash.
        sheet3.getRange(j + 1, 6).setValue(false);
        try { DriveApp.getFileById(String(data.fileId)).setTrashed(true); } catch (e) {}
        return json({success:true, message:'تم حذف الملف.'});
      }
    }
    return json({success:false, message:'لم يتم العثور على ملف نشط بهذا المعرّف.'});
  }
  return null;
}


function isBioAlksherTeacher_(idToken) {
  var apiKey = PropertiesService.getScriptProperties().getProperty('FIREBASE_WEB_API_KEY');
  if (!apiKey) throw new Error('أضف FIREBASE_WEB_API_KEY في Script Properties.');
  var url = 'https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=' + encodeURIComponent(apiKey);
  var response = UrlFetchApp.fetch(url, {
    method:'post',
    contentType:'application/json',
    payload:JSON.stringify({idToken:idToken}),
    muteHttpExceptions:true
  });
  if (response.getResponseCode() !== 200) return false;
  var parsed = JSON.parse(response.getContentText());
  var users = parsed.users || [];
  return users.some(function(u) {
    return String(u.email || '').toLowerCase() === 'ahmedalksher70@gmail.com'
      && u.emailVerified === true;
  });
}
