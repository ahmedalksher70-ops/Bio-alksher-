/**
 * Phone push notifications for Bio Alksher.
 * Requires LectureFiles.gs in the same Apps Script project because it provides
 * isBioAlksherTeacher_(idToken).
 * The script owner must have permission to send Firebase Cloud Messaging messages.
 */
function handleFcmAction_(data) {
  if (!data || data.action !== 'sendPushNotification') return null;
  var title = String(data.title || '').trim().substring(0, 80);
  var body = String(data.body || '').trim().substring(0, 500);
  var idToken = String(data.teacherIdToken || '');
  if (!title || !body || !idToken) return json({success:false, message:'عنوان الإشعار أو الرسالة أو جلسة الأستاذ غير مكتملة.'});
  if (!isBioAlksherTeacher_(idToken)) return json({success:false, message:'غير مصرح بإرسال إشعارات الهاتف.'});

  var projectId = 'biochemistry-easy-with';
  var base = 'https://firestore.googleapis.com/v1/projects/' + projectId + '/databases/(default)/documents/';
  // Read active student accounts first, so expired/rejected subscriptions are not notified.
  var active = {};
  var pageToken = '';
  do {
    var studentsUrl = base + 'students?pageSize=1000' + (pageToken ? '&pageToken=' + encodeURIComponent(pageToken) : '');
    var studentsResponse = UrlFetchApp.fetch(studentsUrl, {method:'get', headers:{Authorization:'Bearer ' + idToken}, muteHttpExceptions:true});
    if (studentsResponse.getResponseCode() !== 200) return json({success:false, message:'تعذر قراءة حسابات الطلاب من Firestore: ' + studentsResponse.getContentText().substring(0, 250)});
    var studentsParsed = JSON.parse(studentsResponse.getContentText());
    (studentsParsed.documents || []).forEach(function(doc) {
      var f = doc.fields || {};
      var status = f.status && f.status.stringValue;
      var expiry = f.expiresAt && f.expiresAt.timestampValue ? new Date(f.expiresAt.timestampValue).getTime() : 0;
      var uid = doc.name.substring(doc.name.lastIndexOf('/') + 1);
      if (status === 'Approved' && expiry > Date.now()) active[uid] = true;
    });
    pageToken = studentsParsed.nextPageToken || '';
  } while (pageToken);

  var tokens = [];
  pageToken = '';
  do {
    var tokenUrl = base + 'notificationTokens?pageSize=1000' + (pageToken ? '&pageToken=' + encodeURIComponent(pageToken) : '');
    var tokenResponse = UrlFetchApp.fetch(tokenUrl, {method:'get', headers:{Authorization:'Bearer ' + idToken}, muteHttpExceptions:true});
    if (tokenResponse.getResponseCode() !== 200) return json({success:false, message:'تعذر قراءة رموز إشعارات الطلاب من Firestore: ' + tokenResponse.getContentText().substring(0, 250)});
    var tokenParsed = JSON.parse(tokenResponse.getContentText());
    (tokenParsed.documents || []).forEach(function(doc) {
      var uid = doc.name.substring(doc.name.lastIndexOf('/') + 1);
      var fields = doc.fields || {};
      var token = fields.token && fields.token.stringValue;
      if (active[uid] && token) tokens.push(token);
    });
    pageToken = tokenParsed.nextPageToken || '';
  } while (pageToken);

  if (!tokens.length) return json({success:true, sent:0, failed:0, message:'لا توجد أجهزة مسجلة لاستقبال الإشعارات بعد.'});

  var oauth = ScriptApp.getOAuthToken();
  var endpoint = 'https://fcm.googleapis.com/v1/projects/' + projectId + '/messages:send';
  var sent = 0, failed = 0, errors = [];
  for (var offset = 0; offset < tokens.length; offset += 100) {
    var requests = tokens.slice(offset, offset + 100).map(function(token) {
      var payload = {message:{token:token, notification:{title:title, body:body}, data:{screen:'notifications', title:title, body:body}, android:{priority:'HIGH', notification:{channel_id:'bio_alksher_messages', sound:'default'}}}};
      return {url:endpoint, method:'post', contentType:'application/json', headers:{Authorization:'Bearer ' + oauth}, payload:JSON.stringify(payload), muteHttpExceptions:true};
    });
    var responses = UrlFetchApp.fetchAll(requests);
    responses.forEach(function(send) {
      if (send.getResponseCode() >= 200 && send.getResponseCode() < 300) sent++;
      else { failed++; if (errors.length < 3) errors.push(send.getContentText().substring(0, 180)); }
    });
  }
  return json({success:true, sent:sent, failed:failed, message:failed ? ('تم الإرسال مع بعض الإخفاقات: ' + errors.join(' | ')) : 'تم إرسال إشعار الهاتف.'});
}
