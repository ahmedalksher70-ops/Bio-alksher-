# إعداد ملفات المنهج ورسائل التطبيق

يستخدم المشروع رسائل داخل التطبيق فقط من مجموعة Firestore `teacherNotifications`. لا يحتاج FCM أو إذن إشعارات الهاتف أو خدمة Push.

يجب مراجعة `LectureFiles.gs` ودمجه مع Web App الحالي فقط إذا كنت تستخدم رفع ملفات المنهج عبر Apps Script. انشر قواعد `firestore/firestore.rules` بعد التحقق من UID الأستاذ.
