package com.biochem.easy;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.*;
import com.google.firebase.functions.FirebaseFunctions;

public class MainActivity extends Activity {
  final int NAVY=Color.rgb(35,28,76), BLUE=Color.rgb(65,112,220), PURPLE=Color.rgb(116,68,190),
    DEEP=Color.rgb(54,27,105), TEAL=Color.rgb(25,170,170), BG=Color.rgb(249,247,253),
    PALE=Color.rgb(242,237,251), MUTED=Color.rgb(105,99,128), LILAC=Color.rgb(238,225,252), CYAN=Color.rgb(35,205,211), GREEN=Color.rgb(23,160,72);
  final String[] CHAPTERS={"Introduction","Carbohydrate Structure","Carbohydrate Metabolism","Lipid Structure","Lipid Metabolism","Protein Structure","Protein Metabolism","Vitamins","Enzymes","Genetics","Heme","Enzymology","Integration","Minerals"};
  final String[] CHAPTER_ICONS={"✦","◉","◈","●","◉","✧","◈","❋","⚛","⌬","◍","✺","✣","◆"};
  LinearLayout root,panel; FirebaseAuth auth; FirebaseFirestore db; FirebaseFunctions functions;
  JSONArray bank=new JSONArray(); String studentName="",selectedChapter="",studentId=""; int index=0,correct=0; ArrayList<JSONObject> exam=new ArrayList<>();
  String[] letters={"A","B","C","D"}; boolean teacher=false,answered=false; int selectedChoice=-1;
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(54,27,105));getWindow().setNavigationBarColor(Color.WHITE);
    try{FirebaseApp.initializeApp(this);auth=FirebaseAuth.getInstance();db=FirebaseFirestore.getInstance();functions=FirebaseFunctions.getInstance();if(auth.getCurrentUser()==null)auth.signInAnonymously();}catch(Exception ignored){}
    try{java.io.InputStream in=getAssets().open("question_bank.json");java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);in.close();bank=new JSONObject(new String(out.toByteArray(),"UTF-8")).getJSONArray("questions");}catch(Exception ignored){}
    studentId=getSharedPreferences("bio_alksher",MODE_PRIVATE).getString("studentId","");
    studentName=getSharedPreferences("bio_alksher",MODE_PRIVATE).getString("studentName","");
    home();
  }
  GradientDrawable outlineBox(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);d.setStroke(3,stroke);return d;}
  GradientDrawable solid(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
  GradientDrawable grad(int c1,int c2,int radius){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{c1,c2});d.setCornerRadius(radius);return d;}
  TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(9,8,9,8);return t;}
  void page(String title){
    root=new LinearLayout(this);root.setOrientation(1);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setPadding(14,10,14,12);root.setBackgroundColor(BG);setContentView(root);
    TextView brand=txt("⚗  الكيمياء الحيوية",21,Color.WHITE,true);brand.setGravity(Gravity.CENTER);brand.setPadding(16,8,16,8);brand.setBackground(grad(DEEP,PURPLE,26));brand.setElevation(5);root.addView(brand,new LinearLayout.LayoutParams(-1,58));
    TextView subtitle=txt("بطريقة سهلة معي  •  BIOCHEMISTRY EASY WITH ME",12,TEAL,true);subtitle.setGravity(Gravity.CENTER);subtitle.setPadding(4,8,4,2);root.addView(subtitle);
    TextView heading=txt(title,23,NAVY,true);heading.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);heading.setPadding(5,10,5,8);root.addView(heading);
    ScrollView sc=new ScrollView(this);sc.setFillViewport(false);panel=new LinearLayout(this);panel.setOrientation(1);panel.setPadding(2,2,2,22);sc.addView(panel);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
  }
  void card(String s,int color){TextView v=txt(s,15,color,true);v.setBackground(solid(Color.WHITE,20));v.setElevation(2);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,5,0,8);panel.addView(v,p);}
  Button button(String label,int c1,int c2,Runnable action){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setTextSize(15);b.setTypeface(null,Typeface.BOLD);b.setBackground(grad(c1,c2,22));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,6,0,7);panel.addView(b,p);b.setOnClickListener(v->action.run());return b;}
  EditText field(String hint){EditText e=new EditText(this);e.setSingleLine(false);e.setTextSize(15);e.setHint(hint);e.setPadding(14,10,14,10);e.setBackground(solid(Color.WHITE,16));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,5,0,7);panel.addView(e,p);return e;}
  TextView sectionTitle(String text){TextView t=txt(text,18,NAVY,true);t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);t.setPadding(4,16,4,8);panel.addView(t);return t;}
  void addFeatureGrid(){
    String[] icons={"▣","▤","☷","▥","▱","▧"};String[] labels={"محاضرات الفيديو","الفصول الدراسية","بنك الأسئلة\nوالاختبارات","نتائجي وتقدمي","ملخصات وملاحظات","ملفات PDF"};
    Runnable[] actions={()->videoLibrary(),()->{if(studentId.isEmpty())msg("يرجى التسجيل والتحقق من قبولك أولاً.");else checkAppsScriptApproval();},()->{if(studentId.isEmpty())msg("يرجى التسجيل أولاً.");else checkAppsScriptApproval();},()->{if(studentId.isEmpty())msg("يرجى التسجيل أولاً.");else studentResults();},()->msg("ستضاف الملخصات هنا بعد رفع ملفات المقرر."),()->msg("ستضاف ملفات PDF هنا بعد رفع ملفات المقرر.")};
    int[] colors={PURPLE,DEEP,Color.rgb(145,48,190),TEAL,PURPLE,BLUE};
    for(int r=0;r<2;r++){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.setMargins(0,5,0,5);panel.addView(row,rp);
      for(int c=0;c<3;c++){int i=r*3+c;LinearLayout tile=new LinearLayout(this);tile.setOrientation(1);tile.setGravity(Gravity.CENTER);tile.setPadding(5,12,5,12);tile.setBackground(solid(Color.WHITE,22));tile.setElevation(4);TextView ic=txt(icons[i],31,colors[i],true);ic.setGravity(Gravity.CENTER);tile.addView(ic,new LinearLayout.LayoutParams(-1,48));TextView label=txt(labels[i],13,DEEP,true);label.setGravity(Gravity.CENTER);label.setMinHeight(48);tile.addView(label);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,142,1);tp.setMargins(4,2,4,2);row.addView(tile,tp);tile.setOnClickListener(v->actions[i].run());}}
  }
  void home(){page("مرحباً بك في عالم الكيمياء الحيوية");
    TextView hero=txt("⚗\nالكيمياء الحيوية\nبطريقة سهلة معي\n\nإعداد وتقديم\nد. أحمد الكشر\nإصدار 2027",25,Color.WHITE,true);hero.setGravity(Gravity.CENTER);hero.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);hero.setBackground(grad(DEEP,PURPLE,32));hero.setPadding(18,26,18,26);hero.setElevation(8);panel.addView(hero,new LinearLayout.LayoutParams(-1,-2));
    TextView slogan=txt("تعلّم بثقة • تدرب بتميز • حقق التفوق",15,TEAL,true);slogan.setGravity(Gravity.CENTER);slogan.setPadding(5,10,5,8);panel.addView(slogan);
    addFeatureGrid();
    sectionTitle("تسجيل الطالب والتحقق من القبول");
    EditText name=field("اسم الطالب");name.setSingleLine(true);if(!studentName.isEmpty())name.setText(studentName);
    EditText phone=field("رقم الهاتف");phone.setSingleLine(true);
    button("تسجيل طالب جديد  ←",PURPLE,DEEP,()->{
      String enteredName=name.getText().toString().trim();String enteredPhone=phone.getText().toString().trim();
      if(enteredName.isEmpty()){name.setError("اكتب اسمك");return;}
      if(studentId.isEmpty() && enteredPhone.isEmpty()){phone.setError("اكتب رقم الهاتف");return;}
      studentName=enteredName;getSharedPreferences("bio_alksher",MODE_PRIVATE).edit().putString("studentName",studentName).apply();
      if(!studentId.isEmpty()){checkAppsScriptApproval();return;}
      try{JSONObject payload=new JSONObject();payload.put("action","register");payload.put("studentName",studentName);payload.put("phone",enteredPhone);
        AppsScriptApi.post(payload,(response,error)->{if(error!=null||response==null){msg("تعذر الاتصال. تحقق من الإنترنت وحاول مجدداً.");return;}if(!response.optBoolean("success")){msg(response.optString("message","فشل التسجيل"));return;}studentId=response.optString("studentId","");getSharedPreferences("bio_alksher",MODE_PRIVATE).edit().putString("studentId",studentId).apply();checkAppsScriptApproval();});
      }catch(Exception ex){msg("تعذر تجهيز طلب التسجيل.");}
    });
    button("التحقق من حالة القبول",Color.rgb(247,242,255),PURPLE,()->{if(studentId.isEmpty())msg("سجل بياناتك أولاً.");else checkAppsScriptApproval();});
    card("يجب موافقة الأستاذ على حسابك قبل دخول الفصول الدراسية.",MUTED);
    button("لوحة الأستاذ   🔒",DEEP,PURPLE,()->teacherGate("panel"));
    TextView footer=txt("Biochemistry Easy with Me  •  د. أحمد الكشر",12,MUTED,true);footer.setGravity(Gravity.CENTER);footer.setPadding(4,18,4,12);panel.addView(footer);
  }
  String arabicChapter(String c){String[] en={"Introduction","Carbohydrate Structure","Carbohydrate Metabolism","Lipid Structure","Lipid Metabolism","Protein Structure","Protein Metabolism","Vitamins","Enzymes","Genetics","Heme","Enzymology","Integration","Minerals"};String[] ar={"مقدمة في الكيمياء الحيوية","تركيب الكربوهيدرات","أيض الكربوهيدرات","تركيب الدهون","أيض الدهون","تركيب البروتينات","أيض البروتينات","الفيتامينات","الإنزيمات","الوراثة","الهيم","علم الإنزيمات","التكامل الأيضي","المعادن"};for(int i=0;i<en.length;i++)if(en[i].equals(c))return ar[i];return c;}
  void videoLibrary(){page("محاضرات الفيديو");card("المحاضرات المصورة",NAVY);card("ستظهر هنا فيديوهات الفصول الدراسية بعد ربط خدمة استضافة الفيديو الآمنة.",MUTED);card("الأستاذ فقط يستطيع إضافة الفيديوهات أو تعديلها أو حذفها. الطالب يستطيع المشاهدة فقط.",TEAL);if(teacher)button("إدارة الفيديوهات (تجهيز الربط)",PURPLE,DEEP,()->teacherVideoManager());button("العودة للرئيسية",BLUE,TEAL,()->home());}
  void teacherVideoManager(){if(!teacher){msg("هذه الصفحة مخصصة للأستاذ فقط.");return;}page("إدارة محاضرات الفيديو");card("واجهة إدارة الفيديوهات",NAVY);card("سيتم تفعيل اختيار الفيديو من الهاتف ورفعه إلى مساحة تخزين خاصة بعد إعداد خدمة الاستضافة. لن نعرض زر رفع وهمياً قبل ربط الخدمة فعلياً.",MUTED);button("العودة إلى لوحة الأستاذ",PURPLE,DEEP,()->teacherPanel());}
  void checkAppsScriptApproval(){
    try{JSONObject payload=new JSONObject();payload.put("action","checkStatus");payload.put("studentId",studentId);
      AppsScriptApi.post(payload,(response,error)->{
        if(error!=null||response==null){msg("Could not check approval. Try again.");return;}
        if(!response.optBoolean("success")){msg(response.optString("message","Student not found"));return;}
        String status=response.optString("status","Pending");
        if("Approved".equals(status)){showChapters();}
        else if("Pending".equals(status)){msg("Your registration is waiting for teacher approval.");}
        else if("Blocked".equals(status)){msg("Your account is blocked or expired. Contact the teacher.");}
        else if("Rejected".equals(status)){msg("Your registration was rejected. Contact the teacher.");}
        else{msg("Account status: "+status);}
      });
    }catch(Exception ex){msg("Could not check student status.");}
  }
  void chapters(){if(studentId.isEmpty()){home();return;}checkAppsScriptApproval();}
  void showChapters(){page("الفصول الدراسية");
    TextView intro=txt("استكشف الكيمياء الحيوية\n14 فصلاً تعليمياً • أسئلة تفاعلية • تصحيح فوري",17,DEEP,true);intro.setGravity(Gravity.CENTER);intro.setBackground(solid(Color.WHITE,22));panel.addView(intro);
    for(int i=0;i<CHAPTERS.length;i++){final String ch=CHAPTERS[i];final int number=i+1;TextView item=txt("⬡   "+number+"   "+arabicChapter(ch)+"     ❯",18,Color.WHITE,true);item.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);item.setPadding(18,13,18,13);item.setBackground(grad(DEEP,PURPLE,28));item.setElevation(5);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,5,0,6);panel.addView(item,lp);item.setOnClickListener(v->begin(ch));}
    button("محاضرات الفيديو",TEAL,BLUE,()->videoLibrary());button("نتائجي وتقدمي",PURPLE,DEEP,()->studentResults());button("العودة للرئيسية",BLUE,TEAL,()->home());
  }
  void begin(String chapter){selectedChapter=chapter;exam.clear();for(int i=0;i<bank.length();i++){JSONObject q=bank.optJSONObject(i);if(q!=null&&chapter.equals(q.optString("chapter")))exam.add(q);}
    if(db==null){launchExam();return;}
    db.collection("questionEdits").get().addOnSuccessListener(edits->{for(DocumentSnapshot doc:edits.getDocuments())for(JSONObject q:exam)if(doc.getId().equals(q.optString("id"))){try{applyEdit(q,doc);}catch(Exception ignored){}break;}
      db.collection("questions").whereEqualTo("chapter",chapter).get().addOnSuccessListener(snapshot->{for(DocumentSnapshot doc:snapshot.getDocuments())try{JSONObject q=new JSONObject();q.put("id",doc.getId());q.put("chapter",chapter);q.put("question",doc.getString("question"));q.put("answer",doc.getString("answer"));q.put("explanation",doc.getString("explanation"));List<String> opts=(List<String>)doc.get("options");q.put("options",new JSONArray(opts==null?new ArrayList<>():opts));q.put("difficulty","Teacher-added");exam.add(q);}catch(Exception ignored){}launchExam();}).addOnFailureListener(e->launchExam());
    }).addOnFailureListener(e->launchExam());
  }
  void applyEdit(JSONObject q,DocumentSnapshot d)throws Exception{if(d.getString("chapter")!=null)q.put("chapter",d.getString("chapter"));if(d.getString("question")!=null)q.put("question",d.getString("question"));if(d.getString("answer")!=null)q.put("answer",d.getString("answer"));if(d.getString("explanation")!=null)q.put("explanation",d.getString("explanation"));List<String> opts=(List<String>)d.get("options");if(opts!=null)q.put("options",new JSONArray(opts));}
  void launchExam(){if(exam.isEmpty()){new AlertDialog.Builder(this).setTitle(selectedChapter).setMessage("No questions are available in this chapter yet.").setPositiveButton("Back",(d,w)->chapters()).show();return;}Collections.shuffle(exam);index=0;correct=0;showQuestion();}
  void showQuestion(){
    if(index>=exam.size()){finishExam();return;}JSONObject q=exam.get(index);page(arabicChapter(selectedChapter));
    TextView banner=txt("اختبار الكيمياء الحيوية  •  "+arabicChapter(selectedChapter),16,Color.WHITE,true);banner.setGravity(Gravity.CENTER);banner.setBackground(grad(DEEP,PURPLE,24));panel.addView(banner,new LinearLayout.LayoutParams(-1,-2));
    TextView progress=txt("السؤال  "+(index+1)+" من "+exam.size()+"     •     "+q.optString("difficulty","متوسط"),16,DEEP,true);progress.setGravity(Gravity.CENTER);progress.setBackground(solid(Color.WHITE,18));panel.addView(progress);
    TextView instruction=txt("اختر الإجابة الصحيحة الواحدة",14,MUTED,false);instruction.setGravity(Gravity.RIGHT);panel.addView(instruction);
    TextView question=txt(q.optString("question"),21,Color.WHITE,true);question.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);question.setTextDirection(View.TEXT_DIRECTION_LTR);question.setBackground(grad(DEEP,PURPLE,24));question.setPadding(18,22,18,22);question.setElevation(4);panel.addView(question);
    JSONArray opts=q.optJSONArray("options");if(opts==null||opts.length()!=4){msg("السؤال لا يحتوي على أربعة اختيارات. يرجى مراجعة الأستاذ.");index++;showQuestion();return;}
    String ans=q.optString("answer");
    for(int i=0;i<4;i++){final int choice=i;String label=letters[i]+"     "+opts.optString(i);TextView option=txt(label,17,NAVY,true);option.setTextDirection(View.TEXT_DIRECTION_LTR);option.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);option.setPadding(18,14,14,14);int bg=Color.WHITE;if(answered&&opts.optString(i).equals(ans))bg=Color.rgb(218,250,228);else if(answered&&i==selectedChoice)bg=Color.rgb(255,230,230);option.setBackground(outlineBox(bg,answered&&opts.optString(i).equals(ans)?GREEN:PURPLE,24));option.setElevation(3);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,6,0,6);panel.addView(option,lp);option.setOnClickListener(v->{if(!answered)answer(choice);});}
    if(answered){
      boolean ok=opts.optString(selectedChoice).equals(ans);
      TextView status=txt(ok?"✓  إجابة صحيحة":"✕  إجابة غير صحيحة",20,ok?Color.rgb(0,125,45):Color.rgb(175,35,35),true);status.setGravity(Gravity.CENTER);status.setBackground(solid(ok?Color.rgb(218,250,228):Color.rgb(255,232,232),24));panel.addView(status);
      TextView correctBox=txt("الإجابة الصحيحة:  "+ans,16,NAVY,true);correctBox.setBackground(solid(Color.WHITE,18));panel.addView(correctBox);
      TextView explanation=txt("التفسير:\n"+q.optString("explanation"),15,NAVY,false);explanation.setBackground(solid(Color.WHITE,18));panel.addView(explanation);
    }
    LinearLayout nav=new LinearLayout(this);nav.setOrientation(LinearLayout.HORIZONTAL);LinearLayout.LayoutParams navp=new LinearLayout.LayoutParams(-1,-2);navp.setMargins(0,10,0,0);panel.addView(nav,navp);
    Button prev=new Button(this);prev.setText("السابق");prev.setAllCaps(false);prev.setTextColor(Color.WHITE);prev.setBackground(grad(PURPLE,DEEP,24));nav.addView(prev,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));prev.setOnClickListener(v->{if(index>0){index--;answered=false;selectedChoice=-1;showQuestion();}});
    Button next=new Button(this);next.setText(index==exam.size()-1?"إنهاء":"التالي");next.setAllCaps(false);next.setTextColor(Color.WHITE);next.setBackground(grad(TEAL,BLUE,24));LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1);np.setMargins(8,0,0,0);nav.addView(next,np);next.setOnClickListener(v->{if(!answered){msg("اختر إجابة أولاً.");return;}if(index==exam.size()-1)finishExam();else{index++;answered=false;selectedChoice=-1;showQuestion();}});
  }
  void answer(int choice){JSONObject q=exam.get(index);JSONArray opts=q.optJSONArray("options");selectedChoice=choice;answered=true;if(opts.optString(choice).equals(q.optString("answer")))correct++;showQuestion();}
  void finishExam(){int total=exam.size(),wrong=total-correct;double pct=total==0?0:100.0*correct/total;saveResult(correct,wrong,pct,total);
    page("نتيجة الفصل");TextView result=txt("✓  Exam Completed!\\n\\n"+selectedChapter+"\\n\\n"+correct+" / "+total+"\\n"+String.format(Locale.US,"%.1f%%",pct)+"\\n\\nCorrect: "+correct+"     Wrong: "+wrong,23,NAVY,true);result.setGravity(Gravity.CENTER);result.setBackground(grad(Color.rgb(236,250,255),Color.rgb(245,239,255),26));panel.addView(result);
    button("Review Answers",PURPLE,BLUE,()->reviewAnswers());button("My Overall Results",TEAL,BLUE,()->studentResults());button("العودة إلى الفصول",BLUE,TEAL,()->chapters());}
  void saveResult(int c,int w,double pct,int total){if(db==null||auth==null||auth.getCurrentUser()==null)return;Map<String,Object> r=new HashMap<>();r.put("studentName",studentName);r.put("studentUid",auth.getCurrentUser().getUid());r.put("chapter",selectedChapter);r.put("correct",c);r.put("wrong",w);r.put("total",total);r.put("percentage",pct);r.put("createdAt",FieldValue.serverTimestamp());db.collection("results").add(r);}
  void reviewAnswers(){page("مراجعة الإجابات");for(int i=0;i<exam.size();i++){JSONObject q=exam.get(i);card("Q"+(i+1)+": "+q.optString("question"),NAVY);card("Correct answer: "+q.optString("answer"),TEAL);card(q.optString("explanation"),MUTED);}button("رجوع إلى الفصول",BLUE,TEAL,()->chapters());}
  void studentResults(){if(db==null||auth==null||auth.getCurrentUser()==null){page("My Results");card("Firebase connection is required to load saved results.",MUTED);return;}page("My Results");db.collection("results").whereEqualTo("studentUid",auth.getCurrentUser().getUid()).get().addOnSuccessListener(s->{panel.removeAllViews();if(s.isEmpty()){card("No saved results yet.",MUTED);return;}Map<String,int[]> sums=new LinkedHashMap<>();for(DocumentSnapshot d:s.getDocuments()){String ch=d.getString("chapter");int[] a=sums.get(ch);if(a==null){a=new int[3];sums.put(ch,a);}a[0]+=num(d,"correct");a[1]+=num(d,"wrong");a[2]+=num(d,"total");}
      int c=0,w=0,t=0;for(Map.Entry<String,int[]> e:sums.entrySet()){int[] a=e.getValue();c+=a[0];w+=a[1];t+=a[2];card(e.getKey()+"\\nCorrect: "+a[0]+"   Wrong: "+a[1]+"\\nScore: "+String.format(Locale.US,"%.1f%%",a[2]==0?0:100.0*a[0]/a[2]),NAVY);}card("OVERALL TOTAL\\nCorrect: "+c+"   Wrong: "+w+"   Score: "+String.format(Locale.US,"%.1f%%",t==0?0:100.0*c/t),TEAL);
    }).addOnFailureListener(e->card("Could not load results. Check connection.",MUTED));}
  int num(DocumentSnapshot d,String k){Long n=d.getLong(k);return n==null?0:n.intValue();}
  void teacherGate(String destination){EditText pin=new EditText(this);pin.setHint("كلمة مرور الأستاذ");pin.setInputType(129);new AlertDialog.Builder(this).setTitle("التحقق من الأستاذ").setView(pin).setPositiveButton("دخول",(d,w)->verifyTeacher(pin.getText().toString(),destination)).setNegativeButton("إلغاء",null).show();}
  void verifyTeacher(String pin,String dest){
    try{JSONObject data=new JSONObject();data.put("action","adminList");data.put("adminPin",pin);
      AppsScriptApi.post(data,(response,error)->{
        if(error!=null||response==null||!response.optBoolean("success")){msg(response==null?"Teacher verification failed. Check the PIN and connection.":response.optString("message","Teacher verification failed."));return;}
        teacher=true;teacherPanel();
      });
    }catch(Exception ex){msg("Could not verify teacher access.");}
  }
  void getTeacherToken(String dest){auth.getCurrentUser().getIdToken(true).addOnSuccessListener(t->{if("panel".equals(dest))teacherPanel();else if("results".equals(dest))teacherResults();else if("add".equals(dest))addQuestion();else if("edit".equals(dest))editQuestionPicker();else if("password".equals(dest))changePasswordForm();}).addOnFailureListener(e->msg("Teacher session could not be verified."));}
  void teacherPanel(){if(!teacher){msg("غير مصرح بالدخول");return;}page("لوحة الأستاذ");card("إدارة المنصة والطلاب والمحتوى التعليمي",DEEP);button("طلبات تسجيل الطلاب والموافقة",TEAL,BLUE,()->teacherStudents());button("نتائج الطلاب",PURPLE,BLUE,()->teacherResults());button("إدارة محاضرات الفيديو",PURPLE,DEEP,()->teacherVideoManager());button("إضافة سؤال (خدمة Firebase الحالية)",TEAL,BLUE,()->msg("إدارة الأسئلة ما زالت مرتبطة بخدمة Firebase القديمة، ولم تُنقل بعد إلى Apps Script."));button("تعديل الأسئلة",PURPLE,DEEP,()->msg("تعديل الأسئلة ما زال يحتاج نقل الخدمة إلى الخادم الجديد."));button("إعدادات كلمة مرور الأستاذ",BLUE,TEAL,()->msg("تغيير الرقم السري يتم حالياً من إعدادات Apps Script."));button("العودة إلى واجهة الطالب",Color.GRAY,MUTED,()->{teacher=false;home();});}
  void teacherStudents(){if(!teacher){msg("Not authorized");return;}page("طلبات تسجيل الطلاب");card("جارٍ تحميل طلبات الطلاب...",MUTED);
    try{JSONObject payload=new JSONObject();payload.put("action","adminList");teacherPinPromptForRequest(payload,(response,error)->{
      panel.removeAllViews();if(error!=null||response==null||!response.optBoolean("success")){card("Could not load students: "+(response==null?"connection error":response.optString("message")),MUTED);return;}
      JSONArray students=response.optJSONArray("students");if(students==null||students.length()==0){card("No registered students yet.",MUTED);return;}
      for(int i=0;i<students.length();i++){JSONObject st=students.optJSONObject(i);if(st==null)continue;String id=st.optString("studentId"),name=st.optString("studentName"),phone=st.optString("phone"),status=st.optString("status");card(name+"\n"+phone+"\nالحالة: "+(status.equals("Approved")?"مقبول":status.equals("Pending")?"قيد الانتظار":status.equals("Blocked")?"محظور":"مرفوض"),NAVY);
        button("قبول الطالب ✓",TEAL,BLUE,()->setStudentStatus(id,"Approved"));button("رفض الطلب",PURPLE,DEEP,()->setStudentStatus(id,"Rejected"));button("حظر الطالب",Color.GRAY,MUTED,()->setStudentStatus(id,"Blocked"));button("إعادة إلى الانتظار",BLUE,TEAL,()->setStudentStatus(id,"Pending"));
      }
    });}catch(Exception ex){card("Could not load student requests.",MUTED);}
  }
  void teacherPinPromptForRequest(JSONObject payload, AppsScriptApi.Callback callback){EditText pin=new EditText(this);pin.setHint("Teacher PIN");pin.setInputType(129);new AlertDialog.Builder(this).setTitle("Confirm teacher PIN").setView(pin).setPositiveButton("Continue",(d,w)->{try{payload.put("adminPin",pin.getText().toString());AppsScriptApi.post(payload,callback);}catch(Exception ex){callback.onResult(null,ex);}}).setNegativeButton("إلغاء",null).show();}
  void setStudentStatus(String id,String status){try{JSONObject payload=new JSONObject();payload.put("action","adminSetStatus");payload.put("studentId",id);payload.put("status",status);payload.put("accessDays",90);teacherPinPromptForRequest(payload,(response,error)->{if(error!=null||response==null||!response.optBoolean("success")){msg(response==null?"Request failed":response.optString("message","Request failed"));return;}msg("Student status updated: "+status);teacherStudents();});}catch(Exception ex){msg("Could not update student.");}}
  void teacherResults(){if(!teacher){msg("Not authorized");return;}page("Students Results");db.collection("results").orderBy("createdAt",Query.Direction.DESCENDING).limit(1000).get().addOnSuccessListener(s->{panel.removeAllViews();Map<String,Map<String,int[]>> students=new LinkedHashMap<>();Map<String,String> names=new HashMap<>();for(DocumentSnapshot d:s.getDocuments()){String uid=d.getString("studentUid");if(uid==null)continue;names.put(uid,d.getString("studentName"));Map<String,int[]> by=students.get(uid);if(by==null){by=new LinkedHashMap<>();students.put(uid,by);}String ch=d.getString("chapter");int[] a=by.get(ch);if(a==null){a=new int[3];by.put(ch,a);}a[0]+=num(d,"correct");a[1]+=num(d,"wrong");a[2]+=num(d,"total");}
      for(String uid:students.keySet()){card("STUDENT: "+names.get(uid),PURPLE);int c=0,w=0,t=0;for(Map.Entry<String,int[]> e:students.get(uid).entrySet()){int[] a=e.getValue();c+=a[0];w+=a[1];t+=a[2];card(e.getKey()+"\\nCorrect "+a[0]+" • Wrong "+a[1]+" • "+String.format(Locale.US,"%.1f%%",a[2]==0?0:100.0*a[0]/a[2]),NAVY);}card("TOTAL: "+c+" correct • "+w+" wrong • "+String.format(Locale.US,"%.1f%%",t==0?0:100.0*c/t),TEAL);}
    }).addOnFailureListener(e->msg("Could not load teacher results. Check Firestore rules."));}
  void addQuestion(){if(!teacher){msg("Not authorized");return;}page("Add a Question");EditText ch=field("Chapter name (exact)"),q=field("Question"),a=field("Option A"),b=field("Option B"),c=field("Option C"),d=field("Option D"),ans=field("Correct answer (exact option text)"),ex=field("Explanation");
    button("Save Question",PURPLE,BLUE,()->{if(q.length()==0||a.length()==0||b.length()==0||c.length()==0||d.length()==0||ans.length()==0){msg("Complete all required fields.");return;}List<String> opts=Arrays.asList(a.getText().toString(),b.getText().toString(),c.getText().toString(),d.getText().toString());if(new HashSet<>(opts).size()!=4||!opts.contains(ans.getText().toString())){msg("Options must be unique and answer must match one option.");return;}Map<String,Object> m=new HashMap<>();m.put("chapter",ch.getText().toString());m.put("question",q.getText().toString());m.put("options",opts);m.put("answer",ans.getText().toString());m.put("explanation",ex.getText().toString());m.put("createdBy",auth.getCurrentUser().getUid());m.put("createdAt",FieldValue.serverTimestamp());db.collection("questions").add(m).addOnSuccessListener(r->msg("Question saved.")).addOnFailureListener(e->msg("Database denied this action."));});}
  void editQuestionPicker(){if(!teacher){msg("Not authorized");return;}page("Choose a Question to Edit");for(int i=0;i<bank.length();i++){JSONObject q=bank.optJSONObject(i);if(q==null)continue;final JSONObject selected=q;final String id=q.optString("id");button(id+" • "+q.optString("chapter")+"\\n"+q.optString("question"),PURPLE,BLUE,()->editQuestionForm(selected,id));}}
  void editQuestionForm(JSONObject q,String id){page("Edit Question / Answer");card("Question ID: "+id,TEAL);EditText ch=field("Chapter");ch.setText(q.optString("chapter"));EditText stem=field("Question");stem.setText(q.optString("question"));JSONArray old=q.optJSONArray("options");EditText[] o=new EditText[4];for(int i=0;i<4;i++){o[i]=field("Option "+letters[i]);o[i].setText(old==null?"":old.optString(i));}EditText ans=field("Correct answer — exact option text");ans.setText(q.optString("answer"));EditText ex=field("Explanation");ex.setText(q.optString("explanation"));
    button("Save Changes",PURPLE,DEEP,()->{List<String> opts=new ArrayList<>();for(EditText x:o)opts.add(x.getText().toString().trim());if(stem.length()==0||new HashSet<>(opts).size()!=4||opts.contains("")||!opts.contains(ans.getText().toString().trim())){msg("Check question, four unique options, and correct answer.");return;}Map<String,Object> m=new HashMap<>();m.put("id",id);m.put("chapter",ch.getText().toString().trim());m.put("question",stem.getText().toString().trim());m.put("options",opts);m.put("answer",ans.getText().toString().trim());m.put("explanation",ex.getText().toString().trim());m.put("updatedBy",auth.getCurrentUser().getUid());m.put("updatedAt",FieldValue.serverTimestamp());db.collection("questionEdits").document(id).set(m,SetOptions.merge()).addOnSuccessListener(v->msg("Changes saved and will be loaded in the next exam.")).addOnFailureListener(e->msg("Database denied the edit."));});}
  void changePasswordForm(){if(!teacher){msg("Not authorized");return;}page("Change Teacher Password");EditText current=field("Current password");current.setInputType(129);EditText next=field("New password (at least 8 characters)");next.setInputType(129);EditText confirm=field("Confirm new password");confirm.setInputType(129);
    button("Update Password",PURPLE,DEEP,()->{String n=next.getText().toString();if(n.length()<8){next.setError("Use at least 8 characters");return;}if(!n.equals(confirm.getText().toString())){confirm.setError("Passwords do not match");return;}Map<String,Object> data=new HashMap<>();data.put("currentPin",current.getText().toString());data.put("newPin",n);functions.getHttpsCallable("changeTeacherPin").call(data).addOnSuccessListener(r->msg("Teacher password changed successfully.")).addOnFailureListener(e->msg("Password change failed. Check current password."));});}
  void msg(String s){new AlertDialog.Builder(this).setMessage(s).setPositiveButton("OK",null).show();}
}
