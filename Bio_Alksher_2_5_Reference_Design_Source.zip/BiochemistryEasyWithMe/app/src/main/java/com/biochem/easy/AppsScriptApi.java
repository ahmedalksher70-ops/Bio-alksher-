package com.biochem.easy;

import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Apps Script API client. All network work runs off the UI thread. */
public final class AppsScriptApi {
    public static final String ENDPOINT = "https://script.google.com/macros/s/AKfycbyVecnCwKHy00oncioMUR2W-vBeUGUWBpftwgWuPzkjG54qljbG3Y2sh8s5kv8naMOinQ/exec";
    public interface Callback { void onResult(JSONObject result, Exception error); }
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private AppsScriptApi() {}

    public static void post(JSONObject payload, Callback callback) {
        EXECUTOR.execute(() -> {
            HttpURLConnection connection = null;
            JSONObject result = null;
            Exception failure = null;
            try {
                URL url = new URL(ENDPOINT);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(20000);
                connection.setReadTimeout(20000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream out = connection.getOutputStream()) { out.write(body); }
                int code = connection.getResponseCode();
                InputStream stream = (code >= 200 && code < 400) ? connection.getInputStream() : connection.getErrorStream();
                if (stream == null) throw new IOException("HTTP " + code);
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                byte[] buffer = new byte[4096]; int count;
                while ((count = stream.read(buffer)) != -1) bytes.write(buffer, 0, count);
                stream.close();
                result = new JSONObject(new String(bytes.toByteArray(), StandardCharsets.UTF_8));
                if (code < 200 || code >= 400) throw new IOException("HTTP " + code + ": " + result.toString());
            } catch (Exception ex) { failure = ex; }
            finally { if (connection != null) connection.disconnect(); }
            final JSONObject finalResult = result;
            final Exception finalFailure = failure;
            MAIN.post(() -> callback.onResult(finalResult, finalFailure));
        });
    }
}
