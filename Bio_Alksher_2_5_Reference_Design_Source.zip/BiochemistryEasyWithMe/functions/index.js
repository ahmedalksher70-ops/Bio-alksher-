const {onCall, HttpsError} = require('firebase-functions/v2/https');
const admin = require('firebase-admin');
const crypto = require('crypto');
admin.initializeApp();
const db = admin.firestore();
const privateRef = db.doc('_private/teacherAuth');

function makeHash(pin, salt) {
  return crypto.scryptSync(pin, salt, 64).toString('hex');
}
function equalHex(a,b) {
  try { const x=Buffer.from(a,'hex'), y=Buffer.from(b,'hex'); return x.length===y.length && crypto.timingSafeEqual(x,y); }
  catch (_) { return false; }
}
async function pinMatches(pin) {
  const snap = await privateRef.get();
  if (snap.exists && snap.data().salt && snap.data().hash) {
    return equalHex(makeHash(pin, snap.data().salt), snap.data().hash);
  }
  const initial = process.env.TEACHER_PIN;
  if (!initial || pin !== initial) return false;
  const salt = crypto.randomBytes(16).toString('hex');
  await privateRef.set({salt, hash:makeHash(initial,salt), initializedAt:admin.firestore.FieldValue.serverTimestamp()});
  return true;
}
exports.verifyTeacherPin = onCall({secrets:['TEACHER_PIN']}, async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated','Sign-in required');
  const pin = String(request.data.pin || '');
  if (!await pinMatches(pin)) throw new HttpsError('permission-denied','Invalid teacher password');
  await admin.auth().setCustomUserClaims(request.auth.uid,{teacher:true});
  return {ok:true};
});
exports.changeTeacherPin = onCall(async (request) => {
  if (!request.auth || request.auth.token.teacher !== true)
    throw new HttpsError('permission-denied','Teacher access required');
  const currentPin = String(request.data.currentPin || '');
  const newPin = String(request.data.newPin || '');
  if (newPin.length < 8) throw new HttpsError('invalid-argument','New password must be at least 8 characters');
  if (!await pinMatches(currentPin)) throw new HttpsError('permission-denied','Current password is incorrect');
  const salt = crypto.randomBytes(16).toString('hex');
  await privateRef.set({salt,hash:makeHash(newPin,salt),updatedAt:admin.firestore.FieldValue.serverTimestamp()});
  return {ok:true};
});
