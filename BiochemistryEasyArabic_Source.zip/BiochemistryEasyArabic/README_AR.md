# Biochemistry Easy with Me — Arabic Android App
تطبيق أندرويد عربي مستقل، يعمل دون Firebase أو اتصال إنترنت.
- اختبارات MCQ وتصحيح فوري وشرح.
- فصول الكيمياء الحيوية.
- إضافة أسئلة من داخل التطبيق وحفظها محلياً.
- اسم المؤلف: أحمد الكشر — Edition 2027.

## البناء
افتح المشروع في Android Studio ثم نفّذ assembleDebug. يتطلب Android SDK 35 و Gradle 8.9+.
