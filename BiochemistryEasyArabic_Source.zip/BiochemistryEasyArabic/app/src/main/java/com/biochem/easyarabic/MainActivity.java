package com.biochem.easyarabic;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.*;

public class MainActivity extends Activity {
    int purple=Color.rgb(75,28,135), deep=Color.rgb(35,17,76), teal=Color.rgb(22,190,170);
    LinearLayout root, body;
    ArrayList<Q> questions=new ArrayList<>();
    int current=0, score=0, chosen=-1;
    String chapter="كل الفصول";
    static class Q {
        String chapter, question, explanation; String[] options; int answer;
        Q(String c,String q,String[] o,int a,String e){chapter=c;question=q;options=o;answer=a;explanation=e;}
    }
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(deep); getWindow().setNavigationBarColor(deep); load(); home();}
    void load(){
        questions.add(new Q("الكربوهيدرات","ما الوحدة الأساسية المكوّنة للنشا؟",new String[]{"الجلوكوز","الأحماض الأمينية","الأحماض الدهنية","النيوكليوتيدات"},0,"النشا عديد سكاريد يتكون من وحدات α-D-glucose."));
        questions.add(new Q("الدهون","أي مما يلي يُعد حمضاً دهنياً أساسياً؟",new String[]{"حمض اللينوليك","حمض البالميتيك","حمض الستياريك","حمض الأولييك"},0,"حمض اللينوليك لا يستطيع الجسم تصنيعه بكميات كافية."));
        questions.add(new Q("البروتينات","ما نوع الرابطة التي تربط الأحماض الأمينية؟",new String[]{"رابطة ببتيدية","رابطة جليكوسيدية","رابطة فوسفوديستر","رابطة هيدروجينية فقط"},0,"تتكون الرابطة الببتيدية بين مجموعة الكربوكسيل ومجموعة الأمين."));
        questions.add(new Q("الإنزيمات","ما الموقع الذي ترتبط به الركيزة في الإنزيم؟",new String[]{"الموقع الفعال","الموقع التنظيمي فقط","النواة","الغشاء الخلوي"},0,"الموقع الفعال هو الجزء الذي ترتبط به الركيزة ويحدث فيه التفاعل."));
        questions.add(new Q("الفيتامينات","أي فيتامين يساعد في امتصاص الكالسيوم؟",new String[]{"Vitamin D","Vitamin C","Vitamin B12","Vitamin K"},0,"يساعد فيتامين D على زيادة امتصاص الكالسيوم والفوسفات."));
        questions.add(new Q("الأيض","ما العملة الرئيسية للطاقة في الخلية؟",new String[]{"ATP","DNA","Urea","Cholesterol"},0,"ATP ينقل الطاقة القابلة للاستخدام في التفاعلات الخلوية."));
    }
    GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
    GradientDrawable gradient(){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{purple,deep,Color.rgb(0,105,120)});d.setCornerRadius(34);return d;}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER);if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(12,10,12,10);return t;}
    void setup(){root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(Color.rgb(245,243,252));root.setPadding(18,18,18,18);setContentView(root);}
    void header(String title){TextView h=text(title,23,Color.WHITE,true);h.setBackground(gradient());root.addView(h,new LinearLayout.LayoutParams(-1,110));}
    void button(String label,Runnable r){Button b=new Button(this);b.setText(label);b.setTextColor(Color.WHITE);b.setTextSize(16);b.setAllCaps(false);b.setBackground(gradient());LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,8,0,8);root.addView(b,p);b.setOnClickListener(v->r.run());}
    void home(){
        setup(); TextView brand=text("Biochemistry\\nEasy with Me",30,Color.WHITE,true);brand.setBackground(gradient());root.addView(brand,new LinearLayout.LayoutParams(-1,190));
        root.addView(text("المؤلف: أحمد الكشر  •  النسخة 2027",16,deep,true));
        root.addView(text("مرحباً بك في تطبيق الكيمياء الحيوية",20,deep,true));
        button("ابدأ الاختبارات",()->chapters());
        button("بنك الأسئلة",()->bank());
        button("إضافة سؤال جديد  ✚",()->editor());
        button("نتائج الاختبارات",()->results());
        TextView note=text("اختبر معلوماتك • تعلّم • تقدّم",15,purple,true);root.addView(note);
    }
    void chapters(){
        setup();header("فصول الكيمياء الحيوية");
        String[] cs={"كل الفصول","الكربوهيدرات","الدهون","البروتينات","الإنزيمات","الفيتامينات","الأحماض النووية","الأيض"};
        for(String c:cs) button("🧬  "+c,()->{chapter=c;current=0;score=0;nextQuestion();});
        button("رجوع",()->home());
    }
    ArrayList<Q> selected(){ArrayList<Q>a=new ArrayList<>();for(Q q:questions)if(chapter.equals("كل الفصول")||q.chapter.equals(chapter))a.add(q);return a;}
    void nextQuestion(){
        ArrayList<Q> list=selected(); if(current>=list.size()){finish();return;}
        Q q=list.get(current);chosen=-1;setup();header("اختبار: "+q.chapter);
        root.addView(text("السؤال "+(current+1)+" من "+list.size(),16,purple,true));
        root.addView(text(q.question,22,deep,true));
        RadioGroup rg=new RadioGroup(this);rg.setOrientation(1);
        for(int i=0;i<q.options.length;i++){RadioButton rb=new RadioButton(this);rb.setText(q.options[i]);rb.setTextSize(18);rb.setTextColor(deep);rb.setPadding(14,12,14,12);final int ix=i;rb.setOnClickListener(v->chosen=ix);rg.addView(rb); }
        root.addView(rg);
        button("تأكيد الإجابة",()->{if(chosen<0){toast("اختر إجابة أولاً");return;}if(chosen==q.answer)score++;answer(q,chosen);});
        button("إنهاء الاختبار",()->finish());
    }
    void answer(Q q,int c){
        setup();header(c==q.answer?"إجابة صحيحة ✓":"إجابة غير صحيحة");
        root.addView(text("الإجابة الصحيحة: "+q.options[q.answer],21,Color.rgb(15,130,75),true));
        root.addView(text("التفسير",20,purple,true));root.addView(text(q.explanation,18,deep,false));
        button("السؤال التالي",()->{current++;nextQuestion();});
    }
    void finish(){
        int total=selected().size();setup();header("نتيجة الاختبار");
        root.addView(text(score+" / "+total,42,purple,true));
        root.addView(text("نسبتك: "+(total==0?0:(score*100/total))+"%",25,deep,true));
        button("إعادة الاختبار",()->{current=0;score=0;nextQuestion();});
        button("العودة للرئيسية",()->home());
    }
    void bank(){
        setup();header("بنك الأسئلة");
        root.addView(text("عدد الأسئلة: "+questions.size(),20,deep,true));
        for(Q q:questions)root.addView(text("• "+q.chapter+" — "+q.question,16,deep,false));
        button("إضافة سؤال",()->editor());button("الرئيسية",()->home());
    }
    void editor(){
        setup();header("إضافة سؤال جديد");
        EditText ch=field("اسم الفصل");EditText qu=field("نص السؤال");EditText[] op={field("الخيار الأول"),field("الخيار الثاني"),field("الخيار الثالث"),field("الخيار الرابع")};EditText ans=field("رقم الإجابة الصحيحة من 1 إلى 4");EditText ex=field("شرح الإجابة");
        button("حفظ السؤال",()->{try{int a=Integer.parseInt(ans.getText().toString().trim())-1;if(a<0||a>3)throw new Exception();questions.add(new Q(ch.getText().toString(),qu.getText().toString(),new String[]{op[0].getText().toString(),op[1].getText().toString(),op[2].getText().toString(),op[3].getText().toString()},a,ex.getText().toString()));save();toast("تم حفظ السؤال");bank();}catch(Exception e){toast("أدخل البيانات ورقم الإجابة من 1 إلى 4");}});
        button("إلغاء",()->home());
    }
    EditText field(String hint){EditText e=new EditText(this);e.setSingleLine(false);e.setHint(hint);e.setTextSize(16);e.setPadding(16,10,16,10);e.setBackground(bg(Color.WHITE,18));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,5,0,5);root.addView(e,p);return e;}
    void results(){setup();header("النتائج");root.addView(text("نتيجة آخر اختبار تظهر بعد إكمال الاختبار.",18,deep,false));button("الرئيسية",()->home());}
    void save(){
        try{JSONArray arr=new JSONArray();for(Q q:questions){JSONObject o=new JSONObject();o.put("chapter",q.chapter);o.put("question",q.question);o.put("options",new JSONArray(q.options));o.put("answer",q.answer);o.put("explanation",q.explanation);arr.put(o);}getSharedPreferences("bank",0).edit().putString("questions",arr.toString()).apply();}catch(Exception ignored){}
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
