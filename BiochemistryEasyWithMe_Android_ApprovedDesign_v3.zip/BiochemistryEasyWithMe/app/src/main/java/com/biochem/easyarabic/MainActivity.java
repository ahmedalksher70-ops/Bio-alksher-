package com.biochem.easyarabic;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.*;
import com.google.firebase.functions.FirebaseFunctions;

public class MainActivity extends Activity {
  final int NAVY=Color.rgb(13,35,105), BLUE=Color.rgb(28,122,220), PURPLE=Color.rgb(100,42,190),
    DEEP=Color.rgb(66,20,125), TEAL=Color.rgb(0,190,190), BG=Color.rgb(250,252,255),
    PALE=Color.rgb(237,246,255), MUTED=Color.rgb(93,112,150);
  final String[] CHAPTERS={"Introduction","Carbohydrate Structure","Carbohydrate Metabolism","Lipid Structure","Lipid Metabolism","Protein Structure","Protein Metabolism","Vitamins","Enzymes","Genetics","Heme","Enzymology","Integration","Minerals"};
  final String[] CHAPTER_ICONS={"✦","◉","◈","●","◉","✧","◈","❋","⚛","⌬","◍","✺","✣","◆"};
  LinearLayout root,panel; FirebaseAuth auth; FirebaseFirestore db; FirebaseFunctions functions;
  JSONArray bank=new JSONArray(); String studentName="",selectedChapter=""; int index=0,correct=0; ArrayList<JSONObject> exam=new ArrayList<>();
  String[] letters={"A","B","C","D"}; boolean teacher=false;
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.WHITE);getWindow().setNavigationBarColor(Color.WHITE);
    try{FirebaseApp.initializeApp(this);auth=FirebaseAuth.getInstance();db=FirebaseFirestore.getInstance();functions=FirebaseFunctions.getInstance();if(auth.getCurrentUser()==null)auth.signInAnonymously();}catch(Exception ignored){}
    try{java.io.InputStream in=getAssets().open("question_bank.json");java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);in.close();bank=new JSONObject(new String(out.toByteArray(),"UTF-8")).getJSONArray("questions");}catch(Exception ignored){}
    home();
  }
  GradientDrawable solid(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
  GradientDrawable grad(int c1,int c2,int radius){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{c1,c2});d.setCornerRadius(radius);return d;}
  TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(9,8,9,8);return t;}
  void page(String title){root=new LinearLayout(this);root.setOrientation(1);root.setPadding(16,12,16,12);root.setBackgroundColor(BG);setContentView(root);
    TextView brand=txt("⚛  Biochemistry Easy with Me",21,NAVY,true);brand.setGravity(Gravity.CENTER_VERTICAL);brand.setBackground(solid(Color.WHITE,22));brand.setElevation(3);root.addView(brand,new LinearLayout.LayoutParams(-1,58));
    TextView heading=txt(title,20,NAVY,true);heading.setPadding(4,14,4,8);root.addView(heading);
    ScrollView sc=new ScrollView(this);panel=new LinearLayout(this);panel.setOrientation(1);panel.setPadding(2,2,2,18);sc.addView(panel);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
  }
  void card(String s,int color){TextView v=txt(s,15,color,true);v.setBackground(solid(Color.WHITE,20));v.setElevation(2);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,5,0,8);panel.addView(v,p);}
  Button button(String label,int c1,int c2,Runnable action){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setTextSize(15);b.setTypeface(null,Typeface.BOLD);b.setBackground(grad(c1,c2,22));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,6,0,7);panel.addView(b,p);b.setOnClickListener(v->action.run());return b;}
  EditText field(String hint){EditText e=new EditText(this);e.setSingleLine(false);e.setTextSize(15);e.setHint(hint);e.setPadding(14,10,14,10);e.setBackground(solid(Color.WHITE,16));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,5,0,7);panel.addView(e,p);return e;}
  void home(){page("Welcome to your learning space");
    TextView hero=txt("Biochemistry\\nEasy with Me\\n\\nBy Dr. Ahmed Al-Kisher  •  Edition 2027\\n\\nLearn  •  Practice  •  Excel",22,NAVY,true);hero.setGravity(Gravity.CENTER);hero.setBackground(grad(Color.rgb(240,249,255),Color.rgb(245,238,255),28));hero.setPadding(15,24,15,24);panel.addView(hero);
    EditText name=field("Student name");name.setSingleLine(true);
    button("Continue to Chapters  →",TEAL,BLUE,()->{studentName=name.getText().toString().trim();if(studentName.isEmpty()){name.setError("Enter your name");return;}chapters();});
    button("My Results",PURPLE,BLUE,()->{if(studentName.isEmpty()){studentName=name.getText().toString().trim();}if(studentName.isEmpty()){name.setError("Enter your name first");return;}studentResults();});
    card("Teacher access • Results • Add / Edit questions",MUTED);
    button("Teacher Panel  🔒",PURPLE,DEEP,()->teacherGate("panel"));
  }
  void chapters(){page("Chapters  (14)");card("Choose a chapter and start your MCQ exam",MUTED);
    for(int i=0;i<CHAPTERS.length;i++){final String ch=CHAPTERS[i];final int ix=i;button(CHAPTER_ICONS[i]+"   "+(i+1)+".  "+ch+"     ›",new int[]{BLUE,TEAL,PURPLE}[i%3],new int[]{Color.rgb(80,170,240),Color.rgb(45,190,170),Color.rgb(150,90,220)}[i%3],()->begin(ch));}
    button("My Results",TEAL,BLUE,()->studentResults());
  }
  void begin(String chapter){selectedChapter=chapter;exam.clear();for(int i=0;i<bank.length();i++){JSONObject q=bank.optJSONObject(i);if(q!=null&&chapter.equals(q.optString("chapter")))exam.add(q);}
    if(db==null){launchExam();return;}
    db.collection("questionEdits").get().addOnSuccessListener(edits->{for(DocumentSnapshot doc:edits.getDocuments())for(JSONObject q:exam)if(doc.getId().equals(q.optString("id"))){try{applyEdit(q,doc);}catch(Exception ignored){}break;}
      db.collection("questions").whereEqualTo("chapter",chapter).get().addOnSuccessListener(snapshot->{for(DocumentSnapshot doc:snapshot.getDocuments())try{JSONObject q=new JSONObject();q.put("id",doc.getId());q.put("chapter",chapter);q.put("question",doc.getString("question"));q.put("answer",doc.getString("answer"));q.put("explanation",doc.getString("explanation"));List<String> opts=(List<String>)doc.get("options");q.put("options",new JSONArray(opts==null?new ArrayList<>():opts));q.put("difficulty","Teacher-added");exam.add(q);}catch(Exception ignored){}launchExam();}).addOnFailureListener(e->launchExam());
    }).addOnFailureListener(e->launchExam());
  }
  void applyEdit(JSONObject q,DocumentSnapshot d)throws Exception{if(d.getString("chapter")!=null)q.put("chapter",d.getString("chapter"));if(d.getString("question")!=null)q.put("question",d.getString("question"));if(d.getString("answer")!=null)q.put("answer",d.getString("answer"));if(d.getString("explanation")!=null)q.put("explanation",d.getString("explanation"));List<String> opts=(List<String>)d.get("options");if(opts!=null)q.put("options",new JSONArray(opts));}
  void launchExam(){if(exam.isEmpty()){new AlertDialog.Builder(this).setTitle(selectedChapter).setMessage("No questions are available in this chapter yet.").setPositiveButton("Back",(d,w)->chapters()).show();return;}Collections.shuffle(exam);index=0;correct=0;showQuestion();}
  void showQuestion(){if(index>=exam.size()){finishExam();return;}JSONObject q=exam.get(index);page(selectedChapter);
    TextView progress=txt("QUESTION  "+(index+1)+" / "+exam.size()+"      •      "+q.optString("difficulty","MCQ"),13,TEAL,true);panel.addView(progress);
    TextView question=txt("◎   "+q.optString("question"),19,Color.WHITE,true);question.setBackground(grad(DEEP,PURPLE,22));question.setPadding(17,18,17,18);panel.addView(question);
    JSONArray opts=q.optJSONArray("options");for(int i=0;i<opts.length();i++){final int choice=i;button(letters[i]+"     "+opts.optString(i),Color.WHITE,PALE,()->answer(choice));panel.getChildAt(panel.getChildCount()-1).setBackground(solid(Color.WHITE,18));((Button)panel.getChildAt(panel.getChildCount()-1)).setTextColor(NAVY);}
    button("Back to Chapters",BLUE,TEAL,()->chapters());
  }
  void answer(int choice){JSONObject q=exam.get(index);JSONArray opts=q.optJSONArray("options");String picked=opts.optString(choice),ans=q.optString("answer");boolean ok=picked.equals(ans);if(ok)correct++;
    new AlertDialog.Builder(this).setTitle(ok?"Correct answer ✓":"Incorrect answer").setMessage("Correct answer: "+ans+"\\n\\n"+q.optString("explanation")).setCancelable(false).setPositiveButton("Next",(d,w)->{index++;showQuestion();}).show();}
  void finishExam(){int total=exam.size(),wrong=total-correct;double pct=total==0?0:100.0*correct/total;saveResult(correct,wrong,pct,total);
    page("Chapter result");TextView result=txt("✓  Exam Completed!\\n\\n"+selectedChapter+"\\n\\n"+correct+" / "+total+"\\n"+String.format(Locale.US,"%.1f%%",pct)+"\\n\\nCorrect: "+correct+"     Wrong: "+wrong,23,NAVY,true);result.setGravity(Gravity.CENTER);result.setBackground(grad(Color.rgb(236,250,255),Color.rgb(245,239,255),26));panel.addView(result);
    button("Review Answers",PURPLE,BLUE,()->reviewAnswers());button("My Overall Results",TEAL,BLUE,()->studentResults());button("Back to Chapters",BLUE,TEAL,()->chapters());}
  void saveResult(int c,int w,double pct,int total){if(db==null||auth==null||auth.getCurrentUser()==null)return;Map<String,Object> r=new HashMap<>();r.put("studentName",studentName);r.put("studentUid",auth.getCurrentUser().getUid());r.put("chapter",selectedChapter);r.put("correct",c);r.put("wrong",w);r.put("total",total);r.put("percentage",pct);r.put("createdAt",FieldValue.serverTimestamp());db.collection("results").add(r);}
  void reviewAnswers(){page("Review Answers");for(int i=0;i<exam.size();i++){JSONObject q=exam.get(i);card("Q"+(i+1)+": "+q.optString("question"),NAVY);card("Correct answer: "+q.optString("answer"),TEAL);card(q.optString("explanation"),MUTED);}button("Back",BLUE,TEAL,()->chapters());}
  void studentResults(){if(db==null||auth==null||auth.getCurrentUser()==null){page("My Results");card("Firebase connection is required to load saved results.",MUTED);return;}page("My Results");db.collection("results").whereEqualTo("studentUid",auth.getCurrentUser().getUid()).get().addOnSuccessListener(s->{panel.removeAllViews();if(s.isEmpty()){card("No saved results yet.",MUTED);return;}Map<String,int[]> sums=new LinkedHashMap<>();for(DocumentSnapshot d:s.getDocuments()){String ch=d.getString("chapter");int[] a=sums.get(ch);if(a==null){a=new int[3];sums.put(ch,a);}a[0]+=num(d,"correct");a[1]+=num(d,"wrong");a[2]+=num(d,"total");}
      int c=0,w=0,t=0;for(Map.Entry<String,int[]> e:sums.entrySet()){int[] a=e.getValue();c+=a[0];w+=a[1];t+=a[2];card(e.getKey()+"\\nCorrect: "+a[0]+"   Wrong: "+a[1]+"\\nScore: "+String.format(Locale.US,"%.1f%%",a[2]==0?0:100.0*a[0]/a[2]),NAVY);}card("OVERALL TOTAL\\nCorrect: "+c+"   Wrong: "+w+"   Score: "+String.format(Locale.US,"%.1f%%",t==0?0:100.0*c/t),TEAL);
    }).addOnFailureListener(e->card("Could not load results. Check connection.",MUTED));}
  int num(DocumentSnapshot d,String k){Long n=d.getLong(k);return n==null?0:n.intValue();}
  void teacherGate(String destination){EditText pin=new EditText(this);pin.setHint("Teacher password");pin.setInputType(129);new AlertDialog.Builder(this).setTitle("Teacher verification").setView(pin).setPositiveButton("Verify",(d,w)->verifyTeacher(pin.getText().toString(),destination)).setNegativeButton("Cancel",null).show();}
  void verifyTeacher(String pin,String dest){if(functions==null||auth==null||auth.getCurrentUser()==null){msg("Firebase setup is required first.");return;}Map<String,Object> data=new HashMap<>();data.put("pin",pin);
    functions.getHttpsCallable("verifyTeacherPin").call(data).addOnSuccessListener(r->{teacher=true;getTeacherToken(dest);}).addOnFailureListener(e->msg("Incorrect password or teacher verification failed."));}
  void getTeacherToken(String dest){auth.getCurrentUser().getIdToken(true).addOnSuccessListener(t->{if("panel".equals(dest))teacherPanel();else if("results".equals(dest))teacherResults();else if("add".equals(dest))addQuestion();else if("edit".equals(dest))editQuestionPicker();else if("password".equals(dest))changePasswordForm();}).addOnFailureListener(e->msg("Teacher session could not be verified."));}
  void teacherPanel(){if(!teacher){msg("Not authorized");return;}page("Teacher Panel  🔒");button("Students Results",PURPLE,BLUE,()->teacherResults());button("Add Questions",TEAL,BLUE,()->addQuestion());button("Edit Questions & Answers",PURPLE,DEEP,()->editQuestionPicker());button("Change Teacher Password",BLUE,TEAL,()->changePasswordForm());button("Return to Student Home",Color.GRAY,MUTED,()->{teacher=false;home();});}
  void teacherResults(){if(!teacher){msg("Not authorized");return;}page("Students Results");db.collection("results").orderBy("createdAt",Query.Direction.DESCENDING).limit(1000).get().addOnSuccessListener(s->{panel.removeAllViews();Map<String,Map<String,int[]>> students=new LinkedHashMap<>();Map<String,String> names=new HashMap<>();for(DocumentSnapshot d:s.getDocuments()){String uid=d.getString("studentUid");if(uid==null)continue;names.put(uid,d.getString("studentName"));Map<String,int[]> by=students.get(uid);if(by==null){by=new LinkedHashMap<>();students.put(uid,by);}String ch=d.getString("chapter");int[] a=by.get(ch);if(a==null){a=new int[3];by.put(ch,a);}a[0]+=num(d,"correct");a[1]+=num(d,"wrong");a[2]+=num(d,"total");}
      for(String uid:students.keySet()){card("STUDENT: "+names.get(uid),PURPLE);int c=0,w=0,t=0;for(Map.Entry<String,int[]> e:students.get(uid).entrySet()){int[] a=e.getValue();c+=a[0];w+=a[1];t+=a[2];card(e.getKey()+"\\nCorrect "+a[0]+" • Wrong "+a[1]+" • "+String.format(Locale.US,"%.1f%%",a[2]==0?0:100.0*a[0]/a[2]),NAVY);}card("TOTAL: "+c+" correct • "+w+" wrong • "+String.format(Locale.US,"%.1f%%",t==0?0:100.0*c/t),TEAL);}
    }).addOnFailureListener(e->msg("Could not load teacher results. Check Firestore rules."));}
  void addQuestion(){if(!teacher){msg("Not authorized");return;}page("Add a Question");EditText ch=field("Chapter name (exact)"),q=field("Question"),a=field("Option A"),b=field("Option B"),c=field("Option C"),d=field("Option D"),ans=field("Correct answer (exact option text)"),ex=field("Explanation");
    button("Save Question",PURPLE,BLUE,()->{if(q.length()==0||a.length()==0||b.length()==0||c.length()==0||d.length()==0||ans.length()==0){msg("Complete all required fields.");return;}List<String> opts=Arrays.asList(a.getText().toString(),b.getText().toString(),c.getText().toString(),d.getText().toString());if(new HashSet<>(opts).size()!=4||!opts.contains(ans.getText().toString())){msg("Options must be unique and answer must match one option.");return;}Map<String,Object> m=new HashMap<>();m.put("chapter",ch.getText().toString());m.put("question",q.getText().toString());m.put("options",opts);m.put("answer",ans.getText().toString());m.put("explanation",ex.getText().toString());m.put("createdBy",auth.getCurrentUser().getUid());m.put("createdAt",FieldValue.serverTimestamp());db.collection("questions").add(m).addOnSuccessListener(r->msg("Question saved.")).addOnFailureListener(e->msg("Database denied this action."));});}
  void editQuestionPicker(){if(!teacher){msg("Not authorized");return;}page("Choose a Question to Edit");for(int i=0;i<bank.length();i++){JSONObject q=bank.optJSONObject(i);if(q==null)continue;final JSONObject selected=q;final String id=q.optString("id");button(id+" • "+q.optString("chapter")+"\\n"+q.optString("question"),PURPLE,BLUE,()->editQuestionForm(selected,id));}}
  void editQuestionForm(JSONObject q,String id){page("Edit Question / Answer");card("Question ID: "+id,TEAL);EditText ch=field("Chapter");ch.setText(q.optString("chapter"));EditText stem=field("Question");stem.setText(q.optString("question"));JSONArray old=q.optJSONArray("options");EditText[] o=new EditText[4];for(int i=0;i<4;i++){o[i]=field("Option "+letters[i]);o[i].setText(old==null?"":old.optString(i));}EditText ans=field("Correct answer — exact option text");ans.setText(q.optString("answer"));EditText ex=field("Explanation");ex.setText(q.optString("explanation"));
    button("Save Changes",PURPLE,DEEP,()->{List<String> opts=new ArrayList<>();for(EditText x:o)opts.add(x.getText().toString().trim());if(stem.length()==0||new HashSet<>(opts).size()!=4||opts.contains("")||!opts.contains(ans.getText().toString().trim())){msg("Check question, four unique options, and correct answer.");return;}Map<String,Object> m=new HashMap<>();m.put("id",id);m.put("chapter",ch.getText().toString().trim());m.put("question",stem.getText().toString().trim());m.put("options",opts);m.put("answer",ans.getText().toString().trim());m.put("explanation",ex.getText().toString().trim());m.put("updatedBy",auth.getCurrentUser().getUid());m.put("updatedAt",FieldValue.serverTimestamp());db.collection("questionEdits").document(id).set(m,SetOptions.merge()).addOnSuccessListener(v->msg("Changes saved and will be loaded in the next exam.")).addOnFailureListener(e->msg("Database denied the edit."));});}
  void changePasswordForm(){if(!teacher){msg("Not authorized");return;}page("Change Teacher Password");EditText current=field("Current password");current.setInputType(129);EditText next=field("New password (at least 8 characters)");next.setInputType(129);EditText confirm=field("Confirm new password");confirm.setInputType(129);
    button("Update Password",PURPLE,DEEP,()->{String n=next.getText().toString();if(n.length()<8){next.setError("Use at least 8 characters");return;}if(!n.equals(confirm.getText().toString())){confirm.setError("Passwords do not match");return;}Map<String,Object> data=new HashMap<>();data.put("currentPin",current.getText().toString());data.put("newPin",n);functions.getHttpsCallable("changeTeacherPin").call(data).addOnSuccessListener(r->msg("Teacher password changed successfully.")).addOnFailureListener(e->msg("Password change failed. Check current password."));});}
  void msg(String s){new AlertDialog.Builder(this).setMessage(s).setPositiveButton("OK",null).show();}
}
