# Biochemistry Easy with Me — Android app source (Version 3)

## UI
The app uses the approved design direction: white background, navy typography, blue/teal/purple cards, deep-purple question panel with white text, and a clean mobile layout. The code is a native Android implementation inspired by the approved mockup; it is not a pixel-perfect image export.

## Student flow
1. Student enters their name.
2. Student selects one of the 14 chapters.
3. MCQ questions are displayed; after each answer the correct answer and explanation appear.
4. Chapter score is calculated and saved to Firestore.
5. My Results shows each chapter separately and the overall total for the signed-in student.

## Teacher flow
- Teacher Panel, Students Results, Add Questions, Edit Questions & Answers, and Change Teacher Password require teacher PIN verification.
- Teacher PIN is checked by Cloud Functions. It is never embedded in Android source.
- The initial PIN is supplied as the `TEACHER_PIN` secret when deploying functions.
- The PIN can be changed in the app (minimum 8 characters); the new value is stored as a salted scrypt hash in the private Firestore document `_private/teacherAuth`.
- Firestore rules protect result reading and question writes using the `teacher` custom claim.

## Firebase setup required before APK build
1. Create/open your Firebase project.
2. Enable Authentication > Anonymous.
3. Create Cloud Firestore.
4. Register Android app id `com.biochem.easyarabic`.
5. Download `google-services.json` and place it in `app/`.
6. Deploy rules: `firebase deploy --only firestore:rules`.
7. Set initial teacher password: `firebase functions:secrets:set TEACHER_PIN`.
8. Deploy functions: `firebase deploy --only functions`.
9. Build the APK in Android Studio or Codemagic.

## Important limitations
- The supplied question bank JSON is embedded in assets. It contains 200 Carbohydrate Structure and 200 Enzymes items, but its question content still needs the previously discussed editorial/source reconciliation before high-stakes use.
- The twelve other chapters appear in the app but currently have no embedded question bank in this package unless questions are added by the teacher.
- The student name is associated with the anonymous Firebase UID on that device. If a student changes device or clears app data, anonymous identity may change; use Firebase account-based student IDs for cross-device persistence.
- This ZIP is source code, not a compiled APK. Firebase configuration and deployment are required before build/run.
