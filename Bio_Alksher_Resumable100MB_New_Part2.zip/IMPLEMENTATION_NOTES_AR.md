# ملاحظات تنفيذ Bio Alksher — مسار Firebase Spark

هذه الوثيقة تحل محل أي ملاحظات أقدم تشير إلى ضرورة Firebase Cloud Functions لهذا المسار. تم اعتماد مسار لا يستخدم Cloud Functions:
- بيانات الطلاب والأسئلة والإشعارات داخل التطبيق في Firestore.
- رفع ملفات المنهج PDF عبر Google Apps Script وGoogle Drive.
- لا توجد Firebase Functions dependency في Android أو إعداد نشر Functions في `firebase.json`.

راجع:
- `IMPLEMENTATION_STATUS_AR.md` لمعرفة ما تم وما لم يتم اختباره.
- `IMPORT_QUESTION_BANK_FORMAT_AR.md` لصيغة استيراد الأسئلة.

لم يتم بناء APK نهائي أو نشر التعديلات على حساب Firebase/Google الخاص بالمستخدم. يجب مراجعة قواعد Firestore ثم اختبار التطبيق فعلياً قبل التوزيع.
