# Bio Alksher — النسخة الجديدة الموحدة مع رفع PDF حتى 100 MB

## محتويات النسخة
- تطبيق Android كامل بمصدر MainActivity وملفات Firebase الحالية.
- إدارة الأسئلة: إضافة وتعديل وحذف ونشر التغييرات عبر Firestore.
- زر المعلم موجود في الواجهة.
- ملفات PDF الأساسية الأربعة وملفات بنك الأسئلة.
- محرك رفع Google Drive Resumable Upload حتى 100 MiB.
- ملفات Apps Script: `Code.gs`, `LectureFiles.gs`, `LargePdfUpload.gs`.
- ملف `codemagic.yaml` مضبوط على أسماء الأجزاء الثلاثة الجديدة.

## تجميع الأجزاء
نزّل الأجزاء الثلاثة وفك ضغطها جميعاً في مجلد واحد. الأجزاء تحتوي المسارات النسبية نفسها من جذر المشروع، ولا يوجد مجلد خارجي إضافي. وافق على دمج الملفات إذا طلب النظام ذلك.

## Codemagic
ارفع ملفات ZIP الثلاثة و`codemagic.yaml` إلى جذر المستودع. شغّل workflow `android-apk`.

## إعداد Apps Script
في مشروع Apps Script الحالي:
1. حدّث `Code.gs` و`LectureFiles.gs` و`LargePdfUpload.gs` من هذه الحزمة.
2. احتفظ بملف `FCM.gs` وأي خدمات أخرى خاصة بك؛ لا تحذفها.
3. من Script Properties اضبط:
   - `SPREADSHEET_ID`: معرّف جدول الطلاب الحالي.
   - `ADMIN_PIN`: رمز جديد قوي (غيّر الرمز الذي ظهر في لقطة الشاشة).
   - `FIREBASE_WEB_API_KEY`: Web API key لمشروع Firebase المستخدم في التطبيق.
   - `LECTURES_FOLDER_ID`: اختياري، معرّف مجلد Drive للمحاضرات.
4. تأكد من تفعيل Google Drive API في مشروع Google Cloud المرتبط.
5. تأكد من صلاحيات Apps Script في `appsscript.json` (Drive, Spreadsheets, External Request).
6. انشر Web App كإصدار جديد، Execute as: Me، مع الإبقاء على إعدادات الوصول المناسبة. إذا تغيّر رابط النشر، حدّث `AppsScriptApi.ENDPOINT` وأعد بناء APK.

## مهم بخصوص الرفع
تطبيق Android يرسل `startLectureUpload`، ثم يرفع البايتات مباشرة إلى رابط جلسة Drive على أجزاء، ثم يرسل `finishLectureUpload`. لا يُرسل PDF كاملاً كـ Base64 إلى Apps Script. الملف النهائي يُسجّل في ورقة `Lectures` ذات الأعمدة الستة المتوافقة مع `listLectures` و`deleteLecture`.

## حدود الاختبار
تم فحص سلامة ملفات ZIP وصياغة ملفات Apps Script، ومراجعة وجود مسارات Android المطلوبة. لم يتم تشغيل Gradle/Android SDK في بيئة إعداد الحزمة، ولم يتم اختبار Firebase أو Google Drive فعلياً بحساب المستخدم. لذلك يلزم تشغيل Codemagic واختبار الرفع بملف صغير ثم ملف كبير قبل توزيع APK.
