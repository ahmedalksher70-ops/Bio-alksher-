/**
 * Bio Alksher — Apps Script Web App entry point.
 * Existing student registration/admin API + lecture PDF API.
 * Keep LectureFiles.gs and LectureFiles_100MB.gs in this same Apps Script project.
 */
const SPREADSHEET_ID = PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID');
function getAdminPin_() { return PropertiesService.getScriptProperties().getProperty('ADMIN_PIN') || ''; }

function doGet() {
  return json({status:'online', app:'Bio Alksher'});
}

function doPost(e) {
  try {
    const data = JSON.parse((e && e.postData && e.postData.contents) || '{}');

    // New direct-to-Drive resumable upload flow (teacher Firebase ID token required).
    const largeUpload = handleLargeLectureUploadAction_(data);
    if (largeUpload) return largeUpload;

    // Existing PDF upload/list/delete API (including legacy uploadLecture).
    const lectureAction = handleLectureFileAction_(data);
    if (lectureAction) return lectureAction;

    if (!SPREADSHEET_ID) throw new Error('Set SPREADSHEET_ID in Apps Script Script Properties.');
    const sheet = SpreadsheetApp.openById(SPREADSHEET_ID).getSheets()[0];
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(['StudentID','StudentName','Phone','Status','RegistrationDate','ExpiryDate']);
    }
    const rows = sheet.getDataRange().getValues();
    const action = data.action;

    if (action === 'register') {
      if (!data.studentName || !data.phone) {
        return json({success:false, message:'Missing student data'});
      }
      const id = Utilities.getUuid();
      sheet.appendRow([id, data.studentName, data.phone, 'Pending', new Date(), '']);
      return json({success:true, studentId:id, status:'Pending'});
    }

    if (action === 'checkStatus') {
      const row = rows.findIndex((r, i) => i > 0 && String(r[0]) === String(data.studentId));
      if (row < 0) return json({success:false, status:'NotFound'});
      const record = rows[row];
      const expired = record[5] && new Date(record[5]).getTime() < Date.now();
      return json({
        success:true,
        status: expired ? 'Expired' : record[3],
        expiryDate: record[5] || ''
      });
    }

    const configuredPin = getAdminPin_();
    if (!configuredPin || data.adminPin !== configuredPin) {
      return json({success:false, message:'Unauthorized'});
    }

    if (action === 'adminList') {
      return json({
        success:true,
        students: rows.slice(1).map(r => ({
          studentId:r[0], studentName:r[1], phone:r[2],
          status:r[3], registrationDate:r[4], expiryDate:r[5]
        }))
      });
    }

    if (action === 'adminSetStatus') {
      const row = rows.findIndex((r, i) => i > 0 && String(r[0]) === String(data.studentId));
      if (row < 0) return json({success:false, message:'NotFound'});
      const allowed = ['Approved','Rejected','Blocked','Pending'];
      if (!allowed.includes(data.status)) return json({success:false, message:'Invalid status'});
      sheet.getRange(row + 1, 4).setValue(data.status);
      sheet.getRange(row + 1, 6).setValue(data.expiryDate || '');
      return json({success:true, status:data.status});
    }

    return json({success:false, message:'Unknown action'});
  } catch (err) {
    return json({success:false, message:String(err)});
  }
}

function json(value) {
  return ContentService.createTextOutput(JSON.stringify(value))
    .setMimeType(ContentService.MimeType.JSON);
}
