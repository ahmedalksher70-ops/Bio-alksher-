# Bio-alksher — Full Specification Package

- الاسم العربي: بايو الكشر
- الاسم الظاهر: دكتور أحمد الكشر
- الاسم الإنجليزي: Bio-alksher

ابدأ بقراءة `docs/FULL_PRODUCT_SPEC_AR.md` ثم استخدم `docs/IMPLEMENTATION_CHECKLIST_AR.md` لتتبع التنفيذ والاختبار.
`config/app_config.json` يحتوي على هوية التطبيق وترتيب الفصول الثمانية عشر.

**تنبيه:** هذه حزمة مواصفات شاملة وليست كود Android أو APK. يلزم مشروع المصدر والمواد الأصلية لتنفيذ التطبيق فعلياً.
