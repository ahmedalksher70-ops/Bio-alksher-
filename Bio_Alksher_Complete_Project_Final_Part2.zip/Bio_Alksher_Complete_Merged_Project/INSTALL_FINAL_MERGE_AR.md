# الدمج النهائي — Bio Alksher

## الملفات المضافة
- `Code.gs`: نقطة دخول موحدة. يوجه أولاً عمليات رفع PDF الكبيرة، ثم عمليات PDF القديمة، ثم عمليات تسجيل الطلاب وإدارة الاشتراك الظاهرة في الصور.
- `LectureFiles_100MB.gs`: إنشاء جلسة Drive resumable وإنهاء تسجيل الملف في ورقة Lectures.
- `LectureFiles.gs`: الحفاظ على listLectures/deleteLecture/الرفع القديم.
- `app/src/main/java/com/biochem/easy/DriveResumableUpload.java`: رفع مباشر مجزأ إلى Drive.
- `MainActivity.java`: يستدعي startLectureUpload ثم يرفع URI مباشرة ويستدعي finishLectureUpload.

## إعداد Apps Script (ضروري قبل النشر)
1. في مشروع Apps Script الحالي أضف/استبدل الملفات: `Code.gs`, `LectureFiles.gs`, `LectureFiles_100MB.gs`.
2. لا تحذف ملفات `FCM.gs` أو ملفات الخدمات الحالية في مشروعك. إن كان لديك `doPost` آخر في FCM، لا تنشئ نقطة دخول ثانية؛ ادمج محتواه داخل `doPost` الموحد.
3. من Project Settings > Script Properties عيّن:
   - `SPREADSHEET_ID` = معرّف Google Sheet الحقيقي المستخدم حالياً.
   - `FIREBASE_WEB_API_KEY` = Web API key لمشروع Firebase الحالي.
   - `LECTURES_FOLDER_ID` = (اختياري) مجلد Drive للمنهج.
   - `ADMIN_PIN` = رمز جديد قوي. لا تستخدم الرمز الذي ظهر في لقطة الشاشة.
4. من Apps Script Project Settings فعّل إظهار `appsscript.json`، وأضف scopes:
   - `https://www.googleapis.com/auth/drive`
   - `https://www.googleapis.com/auth/spreadsheets`
   - `https://www.googleapis.com/auth/script.external_request`
5. فعّل Google Drive API في مشروع Google Cloud المرتبط بـ Apps Script.
6. انشر Web App كنسخة جديدة: Execute as = Me. استخدم نفس رابط النشر الموجود في `AppsScriptApi.ENDPOINT` أو حدّثه بالرابط الجديد.
7. لا تعتبر رفع 100 MiB ناجحاً قبل تجربة ملف حقيقي على هاتف المعلم والتحقق من ظهور ملف PDF واحد للطالب.

## المحافظة على الأسئلة
- عمليات إضافة/تعديل/حذف الأسئلة موجودة في Android وتستخدم Firestore collections (`questions`, `questionEdits`, `questionDeletes`).
- قواعد Firestore المرفقة تسمح للمعلم المعرّف في `isTeacher()` بتعديل الأسئلة.
- `Code.gs` لا يستبدل عمليات الأسئلة؛ الأسئلة لا تمر عبر Apps Script في هذا المشروع.

## اختبارات قبل التوزيع
- بناء Debug APK.
- دخول المعلم وظهور زر المعلم أسفل الشاشة.
- إضافة سؤال وتعديله وحذفه، ثم إعادة فتح التطبيق والتحقق من Firestore.
- تسجيل طالب جديد، ثم اعتماد/رفض/حظر الطالب وتغيير تاريخ الانتهاء.
- رفع PDF صغير ثم 25 MiB ثم ملف قريب من 100 MiB.
- فتح الملف من حساب طالب.
- التأكد أن حساب الطالب لا يعمل على جهاز ثانٍ.

## حدود التحقق
هذه حزمة مصدر، لا APK. لا يمكن تأكيد عمل حساب Google/Firebase أو صلاحيات Drive دون النشر والاختبار على حسابك. لا تدّعي هذه الحزمة أن اختباراً حياً تم.
