package com.biochem.easy;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

/** Streams a selected PDF to a Google Drive resumable session without buffering the whole file. */
public final class DriveResumableUpload {
  public interface Callback { void onProgress(long sent, long total); void onComplete(String driveResponse, Exception error); }
  private static final int CHUNK = 5 * 1024 * 1024; // multiple of Drive's 256 KiB granularity
  private static final long MAX = 100L * 1024L * 1024L;
  private DriveResumableUpload() {}

  public static void upload(Context context, Uri uri, String sessionUrl, long total, Callback callback) {
    final Context app = context.getApplicationContext();
    final Handler main = new Handler(Looper.getMainLooper());
    new Thread(() -> {
      Exception failure = null; String finalBody = null;
      try {
        if (total < 1 || total > MAX) throw new IOException("حجم الملف يجب ألا يتجاوز 100 MB.");
        ContentResolver resolver = app.getContentResolver();
        try (InputStream in = resolver.openInputStream(uri)) {
          if (in == null) throw new IOException("تعذر فتح ملف PDF.");
          byte[] buffer = new byte[CHUNK]; long offset = 0;
          while (offset < total) {
            int wanted = (int)Math.min(buffer.length, total - offset);
            int got = 0;
            while (got < wanted) { int n = in.read(buffer, got, wanted-got); if (n < 0) break; got += n; }
            if (got != wanted) throw new EOFException("انتهى الملف قبل اكتمال قراءته.");
            HttpURLConnection c = (HttpURLConnection)new URL(sessionUrl).openConnection();
            c.setRequestMethod("PUT"); c.setConnectTimeout(60000); c.setReadTimeout(180000); c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/pdf");
            c.setRequestProperty("Content-Length", String.valueOf(got));
            c.setRequestProperty("Content-Range", "bytes " + offset + "-" + (offset+got-1) + "/" + total);
            try (OutputStream out = c.getOutputStream()) { out.write(buffer,0,got); }
            int code = c.getResponseCode();
            InputStream response = (code >= 200 && code < 400) ? c.getInputStream() : c.getErrorStream();
            ByteArrayOutputStream body = new ByteArrayOutputStream();
            if (response != null) { byte[] b = new byte[4096]; int n; while((n=response.read(b))!=-1) body.write(b,0,n); response.close(); }
            String text = new String(body.toByteArray(), "UTF-8"); c.disconnect();
            if (code == 308) { offset += got; final long sentNow = offset; main.post(() -> callback.onProgress(sentNow, total)); }
            else if ((code == 200 || code == 201) && offset + got == total) { offset += got; finalBody = text; main.post(() -> callback.onProgress(total,total)); }
            else throw new IOException("Google Drive upload failed (HTTP " + code + "): " + text);
          }
        }
      } catch (Exception e) { failure = e; }
      final String body = finalBody; final Exception err = failure;
      main.post(() -> callback.onComplete(body, err));
    }, "BioAlksher-DriveUpload").start();
  }
  private static long offsetSafe(long value) { return value; }
}
