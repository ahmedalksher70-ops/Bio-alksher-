# حالة تسجيل الدخول والمزامنة

- يحتفظ المشروع بمشروع Firebase الحالي `biochemistry-easy-with` وبمعرّف Android الحالي `com.biochem.easy`.
- تسجيل الطلاب وقراءة بياناتهم وإدارة الموافقة والاشتراكات تعتمد على Firebase Authentication وFirestore في النسخة المصدرية الحالية.
- حساب الأستاذ يستخدم Firebase Email/Password.
- لا يعتمد إصدار Android الحالي على Firebase Callable Functions.
- قواعد Firestore تحتاج مراجعة UID الأستاذ الفعلي قبل نشرها.
- لم يتم اختبار تسجيل الدخول أو الاشتراكات على أجهزة فعلية في هذه الحزمة.
