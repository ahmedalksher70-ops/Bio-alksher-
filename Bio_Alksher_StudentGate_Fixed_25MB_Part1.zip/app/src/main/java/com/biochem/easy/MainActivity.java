package com.biochem.easy;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.widget.*;
import org.json.*;
import java.util.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.*;
import com.google.firebase.auth.FirebaseUser;
import java.security.MessageDigest;

public class MainActivity extends Activity {
  final int NAVY=Color.rgb(35,28,76), BLUE=Color.rgb(65,112,220), PURPLE=Color.rgb(116,68,190),
    DEEP=Color.rgb(54,27,105), TEAL=Color.rgb(25,170,170), BG=Color.rgb(249,247,253),
    PALE=Color.rgb(242,237,251), MUTED=Color.rgb(105,99,128), LILAC=Color.rgb(238,225,252), CYAN=Color.rgb(35,205,211), GREEN=Color.rgb(23,160,72);
  final String[] CHAPTERS={"Introduction","Carbohydrate Structure","Carbohydrate Metabolism","Lipid Structure","Lipid Metabolism","Protein Structure","Protein Metabolism","Enzyme","Vitamin","Integration","Hormone","Heme","Mineral","Genetic","Enzymology","Nucleic Acid Structure","Nucleic Acid Metabolism","Practical"};
  final String[] CHAPTER_ICONS={"✦","◉","◈","●","◉","✧","◈","❋","⚛","⌬","◍","✺","✣","◆"};
  LinearLayout root,panel;
  static class PageState { final LinearLayout root,panel; PageState(LinearLayout r,LinearLayout p){root=r;panel=p;} }
  final ArrayDeque<PageState> pageHistory=new ArrayDeque<>();
  FirebaseAuth auth,studentAuth,teacherAuth; FirebaseFirestore db,studentDb,teacherDb;
  JSONArray bank=new JSONArray(); String studentName="",selectedChapter="",studentId="",selectedQuestionType="MCQ"; int index=0,correct=0; ArrayList<JSONObject> exam=new ArrayList<>();
  final ArrayList<String> customChapters=new ArrayList<>();
  String[] activeChapters(){ArrayList<String> all=new ArrayList<>(Arrays.asList(CHAPTERS));for(String c:customChapters)if(!c.trim().isEmpty()&&!all.contains(c))all.add(c);return all.toArray(new String[0]);}
  void loadCustomChapters(Runnable done){if(db==null){done.run();return;}db.collection("appConfig").document("chapters").get().addOnSuccessListener(d->{customChapters.clear();List<String> values=(List<String>)d.get("items");if(values!=null)for(String v:values)if(v!=null&&!v.trim().isEmpty()&&!Arrays.asList(CHAPTERS).contains(v))customChapters.add(v.trim());done.run();}).addOnFailureListener(e->{android.util.Log.e("BioAlksher","Chapter list sync failed",e);done.run();});}
  static final int PICK_LECTURE_PDF=8201, PICK_QUESTION_JSON=8202; String pendingLectureTitle=""; String pendingReplaceFileId=""; String pendingReplaceTitle=""; JSONArray pendingImportQuestions=new JSONArray();
  String[] letters={"A","B","C","D"}; boolean teacher=false,answered=false; String teacherPinSession=""; int selectedChoice=-1;
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,WindowManager.LayoutParams.FLAG_SECURE);getWindow().setStatusBarColor(Color.rgb(54,27,105));getWindow().setNavigationBarColor(Color.WHITE);
    try{
      FirebaseApp defaultApp=FirebaseApp.initializeApp(this);
      if(defaultApp==null)defaultApp=FirebaseApp.getInstance();
      studentAuth=FirebaseAuth.getInstance(defaultApp);
      studentDb=FirebaseFirestore.getInstance(defaultApp);
      FirebaseApp teacherApp;
      try{teacherApp=FirebaseApp.getInstance("teacher-session");}
      catch(IllegalStateException missing){teacherApp=FirebaseApp.initializeApp(this,defaultApp.getOptions(),"teacher-session");}
      teacherAuth=FirebaseAuth.getInstance(teacherApp);
      teacherDb=FirebaseFirestore.getInstance(teacherApp);
      auth=studentAuth;db=studentDb;
    }catch(Exception e){android.util.Log.e("BioAlksher","Firebase initialization failed",e);}
    try{java.io.InputStream in=getAssets().open("question_bank.json");java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);in.close();bank=new JSONObject(new String(out.toByteArray(),"UTF-8")).getJSONArray("questions");}catch(Exception ignored){}
    studentId=getSharedPreferences("bio_alksher",MODE_PRIVATE).getString("studentId","");
    studentName=getSharedPreferences("bio_alksher",MODE_PRIVATE).getString("studentName","");
    home();
  }
  void navigateBack(){
    if(!pageHistory.isEmpty()){PageState previous=pageHistory.pop();root=previous.root;panel=previous.panel;setContentView(root);return;}
    if(teacher){teacherPanel();return;}
    // At the first screen, Android Back returns to the phone's previous screen/home.
    finish();
  }
  @Override public void onBackPressed(){navigateBack();}
  GradientDrawable outlineBox(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);d.setStroke(3,stroke);return d;}
  GradientDrawable solid(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
  GradientDrawable grad(int c1,int c2,int radius){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{c1,c2});d.setCornerRadius(radius);return d;}
  TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(9,8,9,8);return t;}
  void page(String title){
    getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,WindowManager.LayoutParams.FLAG_SECURE);
    if(root!=null && panel!=null && root.getParent()!=null) pageHistory.push(new PageState(root,panel));
    root=new LinearLayout(this);root.setOrientation(1);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setPadding(14,10,14,12);root.setBackgroundColor(BG);setContentView(root);
    TextView brand=txt("⚗  الكيمياء الحيوية",21,Color.WHITE,true);brand.setGravity(Gravity.CENTER);brand.setPadding(16,8,16,8);brand.setBackground(grad(DEEP,PURPLE,26));brand.setElevation(5);root.addView(brand,new LinearLayout.LayoutParams(-1,58));
    // Teacher entry is deliberately absent from all student menus; only a long-press opens the credential gate.
    brand.setOnLongClickListener(v->{if(!teacher)teacherGate("panel");return true;});
    TextView subtitle=txt("بطريقة سهلة معي  •  BIOCHEMISTRY EASY WITH ME",12,TEAL,true);subtitle.setGravity(Gravity.CENTER);subtitle.setPadding(4,8,4,2);root.addView(subtitle);
    TextView heading=txt(title,23,NAVY,true);heading.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);heading.setPadding(5,10,5,8);root.addView(heading);
    ScrollView sc=new ScrollView(this);sc.setFillViewport(false);panel=new LinearLayout(this);panel.setOrientation(1);panel.setPadding(2,2,2,22);sc.addView(panel);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
    Button back=new Button(this);back.setText("رجوع");back.setAllCaps(false);back.setTextColor(Color.WHITE);back.setBackground(grad(BLUE,TEAL,20));root.addView(back,new LinearLayout.LayoutParams(-1,48));back.setOnClickListener(v->navigateBack());
  }
  void card(String s,int color){TextView v=txt(s,15,color,true);v.setBackground(solid(Color.WHITE,20));v.setElevation(2);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,5,0,8);panel.addView(v,p);}
  Button button(String label,int c1,int c2,Runnable action){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setTextSize(15);b.setTypeface(null,Typeface.BOLD);b.setBackground(grad(c1,c2,22));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,6,0,7);panel.addView(b,p);b.setOnClickListener(v->action.run());return b;}
  EditText field(String hint){EditText e=new EditText(this);e.setSingleLine(false);e.setTextSize(15);e.setHint(hint);e.setPadding(14,10,14,10);e.setBackground(solid(Color.WHITE,16));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,5,0,7);panel.addView(e,p);return e;}
  TextView sectionTitle(String text){TextView t=txt(text,18,NAVY,true);t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);t.setPadding(4,16,4,8);panel.addView(t);return t;}
  void addFeatureGrid(){
    String[] icons={"▣","▤","☷","▥","▱","▧"};String[] labels={"محاضرات الفيديو","الفصول الدراسية","بنك الأسئلة\nوالاختبارات","نتائجي وتقدمي","ملخصات وملاحظات","ملفات PDF"};
    Runnable[] actions={()->{checkFirebaseAccess();videoLibrary();},()->checkFirebaseAccess(),()->checkFirebaseAccess(),()->{checkFirebaseAccess();studentResults();},()->msg("ستضاف الملخصات هنا بعد رفع ملفات المقرر."),()->{checkFirebaseAccess();pdfLibrary();}};
    int[] colors={PURPLE,DEEP,Color.rgb(145,48,190),TEAL,PURPLE,BLUE};
    for(int r=0;r<2;r++){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.setMargins(0,5,0,5);panel.addView(row,rp);
      for(int c=0;c<3;c++){int i=r*3+c;LinearLayout tile=new LinearLayout(this);tile.setOrientation(1);tile.setGravity(Gravity.CENTER);tile.setPadding(5,12,5,12);tile.setBackground(solid(Color.WHITE,22));tile.setElevation(4);TextView ic=txt(icons[i],31,colors[i],true);ic.setGravity(Gravity.CENTER);tile.addView(ic,new LinearLayout.LayoutParams(-1,48));TextView label=txt(labels[i],13,DEEP,true);label.setGravity(Gravity.CENTER);label.setMinHeight(48);tile.addView(label);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,142,1);tp.setMargins(4,2,4,2);row.addView(tile,tp);tile.setOnClickListener(v->actions[i].run());}}
  }
  String deviceKey(){
    try { return DeviceIdentity.getDeviceKey(); }
    catch(Exception e) { return null; }
  }
  boolean hasInternet(){
    try{ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);if(cm==null)return false;android.net.Network n=cm.getActiveNetwork();if(n==null)return false;NetworkCapabilities c=cm.getNetworkCapabilities(n);return c!=null&&c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)&&c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);}catch(Exception e){return false;}
  }
  void requireOnline(Runnable action){if(!hasInternet()){new AlertDialog.Builder(this).setTitle("الاتصال بالإنترنت مطلوب").setMessage("يعمل تطبيق Bio-alksher عند توفر الإنترنت فقط.").setPositiveButton("إعادة المحاولة",(d,w)->{if(hasInternet())action.run();else msg("لا يوجد اتصال بالإنترنت.");}).setNegativeButton("إغلاق",null).show();return;}action.run();}
  void notificationFields(String titleHint,String bodyHint,java.util.function.BiConsumer<String,String> submit){
    LinearLayout form=new LinearLayout(this);form.setPadding(18,8,18,8);form.setOrientation(1);
    EditText title=new EditText(this);title.setHint(titleHint);title.setSingleLine(true);form.addView(title);
    EditText body=new EditText(this);body.setHint(bodyHint);body.setMinLines(3);body.setGravity(Gravity.TOP);form.addView(body);
    new AlertDialog.Builder(this).setTitle("إرسال رسالة للطلاب").setView(form)
      .setPositiveButton("إرسال",(d,w)->{String t=title.getText().toString().trim(),b=body.getText().toString().trim();if(t.isEmpty()||b.isEmpty()){msg("اكتب العنوان والرسالة.");return;}submit.accept(t,b);})
      .setNegativeButton("إلغاء",null).show();
  }
  void sendInAppNotificationForm(){
    if(!teacher||db==null){msg("هذه الخاصية للأستاذ فقط.");return;}
    db.collection("students").orderBy("name").limit(500).get().addOnSuccessListener(snapshot->{
      ArrayList<String> labels=new ArrayList<>();ArrayList<String> ids=new ArrayList<>();
      labels.add("إرسال جماعي إلى جميع الطلاب");ids.add("__ALL__");
      for(DocumentSnapshot st:snapshot.getDocuments()){
        String status=st.getString("status");
        if(!"Approved".equals(status))continue;
        String nm=st.getString("name");String ph=st.getString("phone");
        labels.add((nm==null?"طالب":nm)+(ph==null?"":" — "+ph));ids.add(st.getId());
      }
      new AlertDialog.Builder(this).setTitle("اختر مستلم الإشعار")
        .setItems(labels.toArray(new String[0]),(dialog,which)->{
          final String recipient=ids.get(which);
          notificationFields("عنوان الإشعار","نص الإشعار",(t,b)->{
            Map<String,Object> data=new HashMap<>();data.put("title",t);data.put("body",b);
            data.put("createdAt",FieldValue.serverTimestamp());data.put("createdBy",teacherAuth.getCurrentUser().getUid());
            data.put("active",true);data.put("audience",recipient.equals("__ALL__")?"all":"student");
            if(!recipient.equals("__ALL__"))data.put("recipientUid",recipient);
            db.collection("teacherNotifications").add(data).addOnSuccessListener(ref->{msg("تم إرسال الإشعار وحفظه داخل التطبيق.");teacherPanel();})
              .addOnFailureListener(e->msg("تعذر إرسال الإشعار: "+e.getLocalizedMessage()));
          });
        }).setNegativeButton("إلغاء",null).show();
    }).addOnFailureListener(e->msg("تعذر تحميل قائمة الطلاب: "+e.getLocalizedMessage()));
  }
  void toggleAppAvailability(){
    if(!teacher||db==null){msg("هذه الخاصية للأستاذ فقط.");return;}
    DocumentReference ref=db.collection("appConfig").document("appControl");
    ref.get().addOnSuccessListener(doc->{boolean enabled=doc.getBoolean("enabled")==null||Boolean.TRUE.equals(doc.getBoolean("enabled"));
      String action=enabled?"إيقاف التطبيق مؤقتاً":"تفعيل التطبيق";
      new AlertDialog.Builder(this).setTitle(action).setMessage(enabled?"سيُمنع الطلاب من الدخول إلى التطبيق حتى تعيد تفعيله. ستبقى لوحة المعلم متاحة.":"سيُسمح للطلاب بالدخول مجدداً بعد التحقق من اشتراكاتهم.")
        .setNegativeButton("إلغاء",null).setPositiveButton("تأكيد",(d,w)->ref.set(new HashMap<String,Object>(){{put("enabled",!enabled);put("updatedAt",FieldValue.serverTimestamp());put("updatedBy",teacherAuth.getCurrentUser().getUid());}},SetOptions.merge())
          .addOnSuccessListener(v->{msg(!enabled?"تم تفعيل التطبيق للطلاب.":"تم إيقاف التطبيق مؤقتاً.");teacherPanel();})
          .addOnFailureListener(e->msg("تعذر تغيير حالة التطبيق: "+e.getLocalizedMessage()))).show();
    }).addOnFailureListener(e->msg("تعذر قراءة حالة التطبيق: "+e.getLocalizedMessage()));
  }
  void studentNotifications(){
    page("إشعارات الأستاذ");card("الرسائل والإعلانات المنشورة من الأستاذ",DEEP);
    if(db==null||studentAuth==null||studentAuth.getCurrentUser()==null){card("تعذر الاتصال بقاعدة البيانات.",MUTED);return;}
    String uid=studentAuth.getCurrentUser().getUid();
    final ArrayList<DocumentSnapshot> messages=new ArrayList<>();final int[] remaining={2};final boolean[] failed={false};
    Runnable render=()->{if(--remaining[0]!=0)return;if(failed[0]){card("تعذر تحميل الإشعارات. تحقق من الاتصال.",MUTED);return;}
      Collections.sort(messages,(a,b)->{Timestamp x=a.getTimestamp("createdAt"),y=b.getTimestamp("createdAt");long xt=x==null?0:x.toDate().getTime(),yt=y==null?0:y.toDate().getTime();return Long.compare(yt,xt);});
      if(messages.isEmpty()){card("لا توجد رسائل جديدة حالياً.",MUTED);return;}for(DocumentSnapshot d:messages){String t=d.getString("title"),body=d.getString("body");card((t==null?"إشعار":t)+"\n"+(body==null?"":body),DEEP);}
    };
    db.collection("teacherNotifications").whereEqualTo("audience","all").limit(100).get().addOnSuccessListener(s->{messages.addAll(s.getDocuments());render.run();}).addOnFailureListener(e->{failed[0]=true;render.run();});
    db.collection("teacherNotifications").whereEqualTo("recipientUid",uid).limit(100).get().addOnSuccessListener(s->{messages.addAll(s.getDocuments());render.run();}).addOnFailureListener(e->{failed[0]=true;render.run();});
    button("العودة للرئيسية",TEAL,BLUE,()->studentHome());
  }
  void home(){
    ensureStudentAuth(u->{
      db.collection("appConfig").document("appControl").get().addOnSuccessListener(control->{
        boolean enabled=control.getBoolean("enabled")==null||Boolean.TRUE.equals(control.getBoolean("enabled"));
        if(!enabled){page("التطبيق متوقف مؤقتاً");card("أوقف المعلم التطبيق مؤقتاً. يرجى المحاولة لاحقاً.",PURPLE);button("دخول المعلم",NAVY,PURPLE,()->requireOnline(()->teacherGate("panel")));return;}
        db.collection("students").document(u.getUid()).get().addOnSuccessListener(this::renderStudentGate)
          .addOnFailureListener(e->renderStudentGate(null,"تعذر قراءة حالة الطالب من الخادم. تحقق من الإنترنت ثم أعد المحاولة."));
      }).addOnFailureListener(e->renderStudentGate(null,"تعذر قراءة حالة التطبيق من الخادم. تحقق من الإنترنت ثم أعد المحاولة."));
    });
  }
  void renderStudentGate(DocumentSnapshot doc){renderStudentGate(doc,null);}
  void renderStudentGate(DocumentSnapshot doc,String serverWarning){
    page("تسجيل الدخول");
    try{ImageView logo=new ImageView(this);logo.setImageDrawable(android.graphics.drawable.Drawable.createFromStream(getAssets().open("branding/bio_alksher_logo.png"),null));logo.setScaleType(ImageView.ScaleType.FIT_CENTER);logo.setBackground(solid(Color.WHITE,24));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,180);lp.setMargins(0,4,0,8);panel.addView(logo,lp);}catch(Exception ignored){}
    TextView hero=txt("Bio-alksher\nد. أحمد الكشر\nEdition 2027",23,Color.WHITE,true);hero.setGravity(Gravity.CENTER);hero.setBackground(grad(Color.BLACK,Color.rgb(55,20,88),28));hero.setPadding(18,18,18,18);panel.addView(hero,new LinearLayout.LayoutParams(-1,-2));
    // A visible teacher entry is always available on the first screen.
    button("دخول المعلم",NAVY,PURPLE,()->requireOnline(()->teacherGate("panel")));
    if(serverWarning!=null&&!serverWarning.trim().isEmpty()){
      card(serverWarning,PURPLE);
      button("إعادة المحاولة",TEAL,BLUE,()->requireOnline(()->home()));
    }
    String status=doc==null?"":doc.getString("status");
    Timestamp expiry=doc==null?null:doc.getTimestamp("expiresAt");
    boolean approved="Approved".equals(status)&&expiry!=null&&expiry.toDate().getTime()>System.currentTimeMillis();
    boolean pending="Pending".equals(status);
    if(approved){
      card("تمت الموافقة على طلبك\nيمكنك الآن الدخول إلى التطبيق.",GREEN);
      button("دخول",Color.BLACK,PURPLE,()->requireOnline(()->studentLogin()));
    }else if(pending){
      card("تم إرسال طلبك إلى المعلم. طلبك قيد المراجعة، يرجى الانتظار حتى تتم الموافقة.",MUTED);
      button("تحديث حالة الطلب",TEAL,BLUE,()->requireOnline(()->home()));
    }else{
      if("Rejected".equals(status))card("تم رفض طلبك. يمكنك إرسال طلب تسجيل جديد.",PURPLE);
      else if("Approved".equals(status)||expiry!=null)card("انتهت مدة اشتراكك. يرجى إرسال طلب تسجيل جديد.",PURPLE);
      TextView title=txt("تسجيل طلب التحقق من المعلم",22,DEEP,true);title.setGravity(Gravity.CENTER);panel.addView(title);
      EditText name=field("اسم الطالب");name.setSingleLine(true);
      EditText phone=field("رقم الهاتف");phone.setSingleLine(true);phone.setInputType(3);
      button("إرسال طلب التحقق",PURPLE,DEEP,()->requireOnline(()->submitStudent(name.getText().toString().trim(),phone.getText().toString().trim())));
      card("سيصل طلبك إلى المعلم للمراجعة. بعد الموافقة سيظهر لك زر دخول فقط.",MUTED);
    }
  }
  void studentHome(){
    if(db==null){page("التطبيق متوقف");card("يلزم الاتصال بالخادم للتحقق من حالة التطبيق.",PURPLE);return;}
    db.collection("appConfig").document("appControl").get().addOnSuccessListener(control->{
      boolean enabled=control.getBoolean("enabled")==null||Boolean.TRUE.equals(control.getBoolean("enabled"));
      if(!enabled){page("التطبيق متوقف مؤقتاً");card("أوقف المعلم التطبيق مؤقتاً. يرجى المحاولة لاحقاً.",PURPLE);button("تحديث الحالة",TEAL,BLUE,()->requireOnline(()->studentHome()));}
      else renderStudentHome();
    }).addOnFailureListener(e->{page("تعذر التحقق");card("تعذر التحقق من حالة التطبيق. تحقق من الإنترنت.",PURPLE);button("إعادة المحاولة",TEAL,BLUE,()->requireOnline(()->studentHome()));});
  }
  void renderStudentHome(){
    page("الرئيسية");
    card("مرحباً بك " + (studentName==null?"":studentName),DEEP);
    loadStudentSubscriptionCard();
    button("بنك الأسئلة",PURPLE,DEEP,()->requireOnline(()->showChapters()));
    button("المنهج PDF",TEAL,BLUE,()->requireOnline(()->pdfLibrary()));
    button("إشعارات الأستاذ",BLUE,TEAL,()->requireOnline(()->studentNotifications()));
    button("نتائجي وتقدمي",PURPLE,BLUE,()->requireOnline(()->studentResults()));
    button("الملخصات والمحاضرات",TEAL,BLUE,()->requireOnline(()->videoLibrary()));
    button("تسجيل الخروج",Color.GRAY,MUTED,()->{auth=studentAuth;db=studentDb;home();});
  }
  void loadStudentSubscriptionCard(){
    if(studentAuth==null||studentAuth.getCurrentUser()==null||studentDb==null){card("تعذر تحميل بيانات الاشتراك.",MUTED);return;}
    studentDb.collection("students").document(studentAuth.getCurrentUser().getUid()).get().addOnSuccessListener(d->{
      if(!d.exists()){card("بيانات الاشتراك غير موجودة.",MUTED);return;}
      Timestamp expiry=d.getTimestamp("expiresAt");String status=d.getString("status");
      if(!"Approved".equals(status)||expiry==null){card("حالة الاشتراك: غير مفعل",PURPLE);return;}
      long remaining=expiry.toDate().getTime()-System.currentTimeMillis();long days=Math.max(0,(remaining+86400000L-1)/86400000L);
      java.text.SimpleDateFormat fmt=new java.text.SimpleDateFormat("yyyy/MM/dd",new Locale("ar"));
      card("بيانات اشتراكك\nالحالة: "+(days>0?"نشط":"منتهي")+"\nتاريخ الانتهاء: "+fmt.format(expiry.toDate())+"\nالأيام المتبقية: "+days+" يوم",days>0?TEAL:PURPLE);
    }).addOnFailureListener(e->card("تعذر تحديث مدة الاشتراك. تحقق من الإنترنت.",MUTED));
  }
  String sha256(String value){try{byte[] b=MessageDigest.getInstance("SHA-256").digest(value.getBytes("UTF-8"));StringBuilder h=new StringBuilder();for(byte x:b)h.append(String.format(Locale.US,"%02x",x));return h.toString();}catch(Exception e){return null;}}
  void ensureStudentAuth(java.util.function.Consumer<FirebaseUser> done){
    if(studentAuth==null||studentDb==null){msg("Firebase Authentication غير مهيأ.");return;}
    auth=studentAuth;db=studentDb;
    FirebaseUser u=studentAuth.getCurrentUser();
    if(u!=null&&u.isAnonymous()){done.accept(u);return;}
    studentAuth.signInAnonymously().addOnSuccessListener(r->done.accept(r.getUser()))
      .addOnFailureListener(e->msg("تعذر إنشاء جلسة الطالب: "+e.getLocalizedMessage()));
  }
  void submitStudent(String name,String phone){
    if(name.length()<2){msg("يرجى إدخال الاسم الكامل.");return;}if(phone.length()<6){msg("يرجى إدخال رقم الهاتف بصورة صحيحة.");return;}if(db==null){msg("قاعدة بيانات Firebase غير مهيأة.");return;}
    String key=deviceKey();if(key==null){msg("تعذر إنشاء هوية آمنة لهذا الهاتف.");return;}String phoneHash=sha256(phone);if(phoneHash==null){msg("تعذر تجهيز بيانات التسجيل.");return;}
    ensureStudentAuth(u->{String uid=u.getUid();DocumentReference student=db.collection("students").document(uid);DocumentReference phoneRef=db.collection("phoneIndex").document(phoneHash);student.get().addOnSuccessListener(existing->{
      Map<String,Object> data=new HashMap<>();data.put("uid",uid);data.put("name",name);data.put("phone",phone);data.put("phoneHash",phoneHash);data.put("deviceKeyHash",sha256(key));data.put("status","Pending");data.put("requestedAt",FieldValue.serverTimestamp());data.put("createdAt",FieldValue.serverTimestamp());
      if(existing.exists()){
        String oldHash=existing.getString("phoneHash"),oldDevice=existing.getString("deviceKeyHash");
        if(!phoneHash.equals(oldHash)||!sha256(key).equals(oldDevice)){msg("هذا الحساب أو رقم الهاتف مرتبط مسبقاً ببيانات أخرى. تواصل مع الأستاذ.");return;}
        String oldStatus=existing.getString("status");
        Timestamp oldExpiry=existing.getTimestamp("expiresAt");
        if("Pending".equals(oldStatus)){msg("طلبك قيد المراجعة بالفعل. انتظر موافقة الأستاذ.");home();return;}
        if("Approved".equals(oldStatus)&&oldExpiry!=null&&oldExpiry.toDate().getTime()>System.currentTimeMillis()){
          msg("تمت الموافقة على حسابك بالفعل. استخدم زر دخول الطالب.");home();return;
        }
        Map<String,Object> update=new HashMap<>();update.put("name",name);update.put("phone",phone);update.put("status","Pending");update.put("requestedAt",FieldValue.serverTimestamp());update.put("expiresAt",null);
        student.update(update).addOnSuccessListener(v->{studentName=name;getSharedPreferences("bio_alksher",MODE_PRIVATE).edit().putString("studentName",name).putString("phone",phone).putString("studentId",uid).apply();msg("تم إرسال طلبك مجدداً إلى الأستاذ.");home();}).addOnFailureListener(e->msg("تعذر إعادة إرسال الطلب: "+e.getLocalizedMessage()));
      }else{
        Map<String,Object> indexData=new HashMap<>();indexData.put("uid",uid);indexData.put("createdAt",FieldValue.serverTimestamp());
        db.runBatch(batch->{batch.set(student,data);batch.set(phoneRef,indexData);}).addOnSuccessListener(v->{studentName=name;getSharedPreferences("bio_alksher",MODE_PRIVATE).edit().putString("studentName",name).putString("phone",phone).putString("studentId",uid).apply();msg("تم إرسال طلبك إلى المدرّس. انتظر الموافقة.");home();}).addOnFailureListener(e->msg("تعذر إرسال الطلب: "+e.getLocalizedMessage()));
      }
    }).addOnFailureListener(e->msg("تعذر التحقق من طلب التسجيل السابق: "+e.getLocalizedMessage()));});
  }
  void studentLogin(){
    requireOnline(()->ensureStudentAuth(u->{
      String key=deviceKey();if(key==null){msg("تعذر التحقق من هوية الهاتف.");return;}
      db.collection("students").document(u.getUid()).get().addOnSuccessListener(doc->{
        if(!doc.exists()){msg("لا يوجد طلب تسجيل لهذا الحساب.");home();return;}
        String savedName=doc.getString("name"),savedKey=doc.getString("deviceKeyHash"),status=doc.getString("status");
        if(!sha256(key).equals(savedKey)){msg("هذا الحساب مرتبط بهاتف آخر ولا يسمح بالدخول من هاتف ثانٍ.");return;}
        if(!"Approved".equals(status)){msg("طلبك غير مقبول حالياً. أرسل طلب تحقق جديداً إذا كان التسجيل مرفوضاً.");home();return;}
        Timestamp expiry=doc.getTimestamp("expiresAt");if(expiry==null||expiry.toDate().getTime()<=System.currentTimeMillis()){msg("انتهى الاشتراك. أرسل طلب تسجيل جديداً.");home();return;}
        studentName=savedName==null?"":savedName;studentId=u.getUid();
        getSharedPreferences("bio_alksher",MODE_PRIVATE).edit().putString("studentName",studentName).putString("studentId",studentId).apply();studentHome();
      }).addOnFailureListener(e->msg("تعذر قراءة حالة الطالب من Firestore: "+e.getLocalizedMessage()));
    }));
  }
  void checkFirebaseAccess(){studentLogin();}
  String arabicChapter(String c){return c;}

  void pdfLibrary(){
    page("ملفات PDF");
    card("محاضرات المقرر — الملفات الجديدة تظهر هنا تلقائياً",DEEP);
    String[] names={"Introduction","Protein Structure 2027","Enzyme 2027","Lipid Structure 2027"};
    String[] files={"Introduction.pdf","Protein Structure 2027.pdf","Enzyme 2027.pdf","Lipid Structure 2027.pdf"};
    if(db==null){for(int i=0;i<names.length;i++)addBundledPdfButton(names[i],files[i]);}
    else db.collection("appConfig").document("pdfLibrary").get().addOnSuccessListener(doc->{List<String> hidden=(List<String>)doc.get("hiddenBundled");for(int i=0;i<names.length;i++)if(hidden==null||!hidden.contains(files[i]))addBundledPdfButton(names[i],files[i]);}).addOnFailureListener(e->{for(int i=0;i<names.length;i++)addBundledPdfButton(names[i],files[i]);});
    sectionTitle("الفصول المضافة حديثاً");
    loadOnlineLectures();
    button("العودة للرئيسية",TEAL,BLUE,()->studentHome());
  }
  void addBundledPdfButton(String title,String file){button("📕  "+title,PURPLE,DEEP,()->{android.content.Intent intent=new android.content.Intent(this,LecturePdfActivity.class);intent.putExtra("assetName",file);intent.putExtra("title",title);startActivity(intent);});}
  void loadOnlineLectures(){
    try{
      JSONObject req=new JSONObject();req.put("action","listLectures");
      AppsScriptApi.post(req,(result,error)->{
        if(error!=null){card("تعذر تحميل الفصول المضافة: "+error.getMessage(),MUTED);return;}
        if(result==null||!result.optBoolean("success")){card("لا توجد قائمة فصول متاحة حالياً.",MUTED);return;}
        JSONArray items=result.optJSONArray("lectures");if(items==null||items.length()==0){card("لا توجد فصول جديدة حالياً.",MUTED);return;}
        for(int i=0;i<items.length();i++){JSONObject item=items.optJSONObject(i);if(item==null)continue;
          String title=item.optString("title","ملف PDF"),url=item.optString("url","");
          if(url.isEmpty())continue;
          button("📘 "+title,TEAL,BLUE,()->openLectureUrl(url));
        }
      });
    }catch(Exception e){card("تعذر قراءة قائمة الفصول.",MUTED);}
  }
  void openLectureUrl(String url){
    try{android.content.Intent i=new android.content.Intent(android.content.Intent.ACTION_VIEW,android.net.Uri.parse(url));startActivity(i);}
    catch(Exception e){msg("تعذر فتح ملف المنهج: "+e.getLocalizedMessage());}
  }
  void chooseLecturePdf(){
    if(!teacher){msg("هذه الخاصية للأستاذ فقط.");return;}
    android.content.Intent intent=new android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT);
    intent.addCategory(android.content.Intent.CATEGORY_OPENABLE);intent.setType("application/pdf");
    startActivityForResult(intent,PICK_LECTURE_PDF);
  }
  @Override protected void onActivityResult(int requestCode,int resultCode,android.content.Intent data){
    super.onActivityResult(requestCode,resultCode,data);
    if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;
    if(requestCode==PICK_QUESTION_JSON){readQuestionImportFile(data.getData());return;}
    if(requestCode!=PICK_LECTURE_PDF)return;
    android.net.Uri uri=data.getData();
    String name="Chapter_"+System.currentTimeMillis()+".pdf";
    android.database.Cursor cursor=getContentResolver().query(uri,null,null,null,null);
    if(cursor!=null){try{int ix=cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);if(ix>=0&&cursor.moveToFirst())name=cursor.getString(ix);}finally{cursor.close();}}
    final String fileName=name;
    LinearLayout form=new LinearLayout(this);form.setPadding(18,8,18,8);form.setOrientation(1);
    EditText title= new EditText(this);title.setSingleLine(true);title.setHint("اسم الفصل الذي سيظهر للطلاب");title.setText(pendingReplaceTitle.isEmpty()?fileName.replaceAll("(?i)\\.pdf$",""):pendingReplaceTitle);form.addView(title);
    new AlertDialog.Builder(this).setTitle("رفع فصل PDF إلى المنهج").setView(form)
      .setPositiveButton("رفع",(d,w)->uploadLecturePdf(uri,fileName,title.getText().toString().trim()))
      .setNegativeButton("إلغاء",null).show();
  }
  void uploadLecturePdf(android.net.Uri uri,String fileName,String title){
    if(!teacher||title.isEmpty()){msg("أدخل اسم الفصل أولاً.");return;}
    try{
      java.io.InputStream in=getContentResolver().openInputStream(uri);
      if(in==null){msg("تعذر قراءة ملف PDF.");return;}
      java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();
      byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>25L*1024L*1024L){in.close();msg("حجم الملف أكبر من 25 MB. الحد الأقصى المسموح به هو 25 MB.");return;}}
      in.close();
      String encoded=android.util.Base64.encodeToString(out.toByteArray(),android.util.Base64.NO_WRAP);
      FirebaseUser teacherUser=teacherAuth==null?null:teacherAuth.getCurrentUser();
      if(teacherUser==null){msg("انتهت جلسة الأستاذ. سجّل الدخول مجدداً.");return;}
      final String payload64=encoded;
      teacherUser.getIdToken(false).addOnSuccessListener(tokenResult->{
      try {
      JSONObject req=new JSONObject();req.put("action","uploadLecture");req.put("title",title);req.put("fileName",fileName);req.put("mimeType","application/pdf");req.put("base64",payload64);req.put("teacherIdToken",tokenResult.getToken());if(!pendingReplaceFileId.isEmpty())req.put("replaceFileId",pendingReplaceFileId);
      card("جارٍ رفع الفصل إلى Google Drive...",MUTED);
      AppsScriptApi.post(req,(result,error)->{
        if(error!=null){msg("فشل رفع الملف: "+error.getMessage());return;}
        if(result==null||!result.optBoolean("success")){msg(result==null?"لم يصل رد من Google Apps Script.":result.optString("message","فشل الرفع."));return;}
        pendingReplaceFileId="";pendingReplaceTitle="";
        db.collection("appConfig").document("chapters").set(new HashMap<String,Object>(){{put("items",FieldValue.arrayUnion(title));put("updatedAt",FieldValue.serverTimestamp());}},SetOptions.merge());
        db.collection("appConfig").document("content").set(new HashMap<String,Object>(){{put("contentVersion",FieldValue.increment(1));put("updatedAt",FieldValue.serverTimestamp());}},SetOptions.merge());
        msg("تم رفع الفصل بنجاح. سيظهر للطلاب عند تحديث قائمة المنهج.");
        teacherPdfManager();
      });
      } catch(Exception ex){msg("تعذر تجهيز طلب الرفع: "+ex.getLocalizedMessage());}
      }).addOnFailureListener(e->msg("تعذر التحقق من حساب الأستاذ: "+e.getLocalizedMessage()));
    }catch(Exception e){msg("تعذر تجهيز ملف PDF: "+e.getLocalizedMessage());}
  }
  void teacherPdfManager(){
    if(!teacher || teacherAuth==null || teacherAuth.getCurrentUser()==null){msg("هذه الصفحة للأستاذ فقط.");return;}
    page("المنهج");
    button("إضافة Chapter جديد (PDF)",TEAL,BLUE,()->chooseLecturePdf());
    button("إخفاء / استبدال ملفات المنهج الأساسية",PURPLE,DEEP,()->manageBundledPdfs());
    button("حذف Chapter",Color.rgb(170,35,55),DEEP,()->manageCustomChapters());
    loadTeacherLectureList();
    button("العودة",Color.GRAY,MUTED,()->teacherPanel());
  }
  void manageBundledPdfs(){
    if(!teacher)return;page("إدارة ملفات PDF الأساسية");card("يمكنك إخفاء ملف مدمج من قائمة الطلاب. لا يحذف ذلك ملف المصدر من APK القديم؛ ويُستبدل بإضافة PDF جديد من زر إضافة فصل PDF.",DEEP);
    String[] titles={"Introduction","Protein Structure 2027","Enzyme 2027","Lipid Structure 2027"};
    String[] files={"Introduction.pdf","Protein Structure 2027.pdf","Enzyme 2027.pdf","Lipid Structure 2027.pdf"};
    db.collection("appConfig").document("pdfLibrary").get().addOnSuccessListener(doc->{List<String> hidden=(List<String>)doc.get("hiddenBundled");for(int i=0;i<files.length;i++){final String f=files[i],t=titles[i];boolean isHidden=hidden!=null&&hidden.contains(f);card(t+(isHidden?" — مخفي عن الطلاب":" — ظاهر للطلاب"),DEEP);if(isHidden)button("إظهار هذا الملف للطلاب",TEAL,BLUE,()->db.collection("appConfig").document("pdfLibrary").update("hiddenBundled",FieldValue.arrayRemove(f)).addOnSuccessListener(v->{msg("تم إظهار الملف.");manageBundledPdfs();}).addOnFailureListener(e->msg("تعذر تحديث الملف: "+e.getLocalizedMessage())));else button("إخفاء هذا الملف من المنهج",Color.rgb(170,35,55),DEEP,()->new AlertDialog.Builder(this).setTitle("إخفاء ملف المنهج").setMessage("سيختفي هذا الملف من قائمة الطلاب. يمكنك إضافة ملف PDF بديل.").setNegativeButton("إلغاء",null).setPositiveButton("إخفاء",(x,y)->db.collection("appConfig").document("pdfLibrary").set(new HashMap<String,Object>(){{put("hiddenBundled",FieldValue.arrayUnion(f));put("updatedAt",FieldValue.serverTimestamp());}},SetOptions.merge()).addOnSuccessListener(v->{db.collection("appConfig").document("content").set(new HashMap<String,Object>(){{put("contentVersion",FieldValue.increment(1));put("updatedAt",FieldValue.serverTimestamp());}},SetOptions.merge());msg("تم إخفاء الملف عن الطلاب.");manageBundledPdfs();}).addOnFailureListener(e->msg("تعذر إخفاء الملف: "+e.getLocalizedMessage()))).show());}}).addOnFailureListener(e->card("تعذر تحميل حالة ملفات PDF: "+e.getLocalizedMessage(),MUTED));
    button("العودة إلى إدارة المنهج",TEAL,BLUE,()->teacherPdfManager());
  }
  void addCustomChapterDialog(){
    if(!teacher)return;EditText name=new EditText(this);name.setSingleLine(true);name.setHint("اسم الفصل باللغة الإنجليزية");
    new AlertDialog.Builder(this).setTitle("إضافة Chapter جديد").setView(name).setNegativeButton("إلغاء",null).setPositiveButton("إضافة",(d,w)->{
      String value=name.getText().toString().trim();if(value.length()<2){msg("اكتب اسم الفصل بصورة صحيحة.");return;}
      if(Arrays.asList(CHAPTERS).contains(value)){msg("هذا الفصل موجود بالفعل ضمن الفصول الأساسية.");return;}
      db.collection("appConfig").document("chapters").set(new HashMap<String,Object>(){{put("items",FieldValue.arrayUnion(value));put("updatedAt",FieldValue.serverTimestamp());put("updatedBy",teacherAuth.getCurrentUser().getUid());}},SetOptions.merge()).addOnSuccessListener(v->{db.collection("appConfig").document("content").set(new HashMap<String,Object>(){{put("contentVersion",FieldValue.increment(1));put("updatedAt",FieldValue.serverTimestamp());}},SetOptions.merge());msg("تمت إضافة الفصل. سيظهر للطلاب عند فتح بنك الأسئلة بعد المزامنة.");teacherPdfManager();}).addOnFailureListener(e->msg("تعذرت إضافة الفصل: "+e.getLocalizedMessage()));
    }).show();
  }
  void manageCustomChapters(){
    if(!teacher)return;page("إدارة الفصول المضافة");card("يمكنك حذف الفصول التي أضفتها. الفصول الأساسية محمية من الحذف.",DEEP);
    db.collection("appConfig").document("chapters").get().addOnSuccessListener(doc->{List<String> items=(List<String>)doc.get("items");if(items==null||items.isEmpty()){card("لم تتم إضافة فصول مخصصة بعد.",MUTED);return;}for(String ch:items){card(ch,DEEP);button("حذف الفصل: "+ch,Color.rgb(170,35,55),DEEP,()->new AlertDialog.Builder(this).setTitle("تأكيد حذف الفصل").setMessage("سيختفي الفصل من قائمة الطلاب. الأسئلة والملفات المرتبطة به لن تُحذف تلقائياً.").setNegativeButton("إلغاء",null).setPositiveButton("حذف",(x,y)->db.collection("appConfig").document("chapters").update("items",FieldValue.arrayRemove(ch),"updatedAt",FieldValue.serverTimestamp()).addOnSuccessListener(v->{db.collection("appConfig").document("content").set(new HashMap<String,Object>(){{put("contentVersion",FieldValue.increment(1));put("updatedAt",FieldValue.serverTimestamp());}},SetOptions.merge());msg("تم حذف الفصل من القائمة.");manageCustomChapters();}).addOnFailureListener(e->msg("تعذر حذف الفصل: "+e.getLocalizedMessage()))).show());}}).addOnFailureListener(e->card("تعذر تحميل الفصول: "+e.getLocalizedMessage(),MUTED));
    button("العودة إلى إدارة المنهج",TEAL,BLUE,()->teacherPdfManager());
  }
  void loadTeacherLectureList(){
    try{
      JSONObject req=new JSONObject();req.put("action","listLectures");
      AppsScriptApi.post(req,(result,error)->{
        if(error!=null){card("تعذر تحميل قائمة الفصول: "+error.getMessage(),MUTED);return;}
        JSONArray items=result==null?null:result.optJSONArray("lectures");
        if(items==null||items.length()==0){card("لا توجد ملفات PDF مرفوعة حالياً.",MUTED);return;}
        sectionTitle("الفصول المرفوعة — حذف أو استبدال");
        for(int i=0;i<items.length();i++){
          JSONObject item=items.optJSONObject(i);if(item==null)continue;
          final String fileId=item.optString("fileId",""), title=item.optString("title","ملف PDF");
          if(fileId.isEmpty())continue;
          card(title,DEEP);
          button("استبدال هذا الفصل بنسخة جديدة",TEAL,BLUE,()->{
            pendingReplaceFileId=fileId;pendingReplaceTitle=title;
            chooseLecturePdf();
          });
          button("حذف هذا الفصل",Color.RED,DEEP,()->new AlertDialog.Builder(this)
            .setTitle("تأكيد حذف الفصل")
            .setMessage("هل تريد حذف «"+title+"»؟ لن يظهر للطلاب بعد الحذف.")
            .setNegativeButton("إلغاء",null)
            .setPositiveButton("حذف",(d,w)->deleteLecturePdf(fileId))
            .show());
        }
      });
    }catch(Exception e){card("تعذر تجهيز قائمة الملفات.",MUTED);}
  }
  void deleteLecturePdf(String fileId){
    if(!teacher)return;
    try{
      FirebaseUser u=teacherAuth==null?null:teacherAuth.getCurrentUser();
      if(u==null){msg("سجّل دخول الأستاذ مجدداً.");return;}
      u.getIdToken(false).addOnSuccessListener(t->{
        try{
          JSONObject req=new JSONObject();req.put("action","deleteLecture");req.put("fileId",fileId);req.put("teacherIdToken",t.getToken());
          AppsScriptApi.post(req,(r,e)->{
            if(e!=null){msg("تعذر حذف الملف: "+e.getMessage());return;}
            if(r==null||!r.optBoolean("success")){msg(r==null?"لم يصل رد الخادم.":r.optString("message","فشل الحذف."));return;}
            db.collection("appConfig").document("content").set(new HashMap<String,Object>(){{put("contentVersion",FieldValue.increment(1));put("updatedAt",FieldValue.serverTimestamp());}},SetOptions.merge());msg("تم حذف الفصل من قائمة المنهج.");teacherPdfManager();
          });
        }catch(Exception ex){msg("تعذر تجهيز طلب الحذف.");}
      }).addOnFailureListener(e->msg("تعذر التحقق من حساب الأستاذ."));
    }catch(Exception e){msg("حدث خطأ أثناء الحذف.");}
  }
  void videoLibrary(){page("محاضرات الفيديو");card("المحاضرات المصورة",NAVY);card("ستظهر هنا فيديوهات الفصول الدراسية بعد ربط خدمة استضافة الفيديو الآمنة.",MUTED);card("الأستاذ فقط يستطيع إضافة الفيديوهات أو تعديلها أو حذفها. الطالب يستطيع المشاهدة فقط.",TEAL);if(teacher)button("إدارة الفيديوهات (تجهيز الربط)",PURPLE,DEEP,()->teacherVideoManager());button("العودة للرئيسية",BLUE,TEAL,()->studentHome());}
  void teacherVideoManager(){if(!teacher){msg("هذه الصفحة مخصصة للأستاذ فقط.");return;}page("إدارة محاضرات الفيديو");card("واجهة إدارة الفيديوهات",NAVY);card("سيتم تفعيل اختيار الفيديو من الهاتف ورفعه إلى مساحة تخزين خاصة بعد إعداد خدمة الاستضافة. لن نعرض زر رفع وهمياً قبل ربط الخدمة فعلياً.",MUTED);button("العودة إلى لوحة الأستاذ",PURPLE,DEEP,()->teacherPanel());}
  void checkAppsScriptApproval(){checkFirebaseAccess();}
  void chapters(){checkFirebaseAccess();}
  void showChapters(){
    page("الفصول الدراسية");
    TextView intro=txt("استكشف الكيمياء الحيوية\nفصول تعليمية • أسئلة تفاعلية • تصحيح فوري",17,DEEP,true);intro.setGravity(Gravity.CENTER);intro.setBackground(solid(Color.WHITE,22));panel.addView(intro);
    loadCustomChapters(()->{
      for(String ch:activeChapters()){final String chapter=ch;TextView item=txt(arabicChapter(chapter)+"     ❯",18,Color.WHITE,true);item.setGravity(Gravity.CENTER);item.setPadding(18,13,18,13);item.setBackground(grad(DEEP,PURPLE,28));item.setElevation(5);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,5,0,6);panel.addView(item,lp);item.setOnClickListener(v->requireOnline(()->showChapterTypes(chapter)));}
      button("محاضرات الفيديو",TEAL,BLUE,()->checkFirebaseAccess());button("نتائجي وتقدمي",PURPLE,DEEP,()->studentResults());button("العودة للرئيسية",BLUE,TEAL,()->studentHome());
    });
  }
  void showChapterTypes(String chapter){
    selectedChapter=chapter;page(chapter);card("اختر نوع الأسئلة داخل هذا الفصل",DEEP);
    String[] labels={"MCQ","Case Question","True & False","Written Question"};
    for(int i=0;i<labels.length;i++){final String type=labels[i];button(type,i==0?PURPLE:i==1?TEAL:i==2?BLUE:DEEP,DEEP,()->begin(chapter,type));}
    button("رجوع إلى الفصول",BLUE,TEAL,()->showChapters());
  }
  boolean hasChapterResource(String folder,String file){try{getAssets().open("chapter_resources/"+folder+"/"+file).close();return true;}catch(Exception e){return false;}}
  void openAssetPdf(String title,String path){android.content.Intent i=new android.content.Intent(this,LecturePdfActivity.class);i.putExtra("assetName",path);i.putExtra("title",title);startActivity(i);}
  void begin(String chapter){begin(chapter,"MCQ");}
  void begin(String chapter,String type){selectedChapter=chapter;selectedQuestionType=type;exam.clear();
    // Start from the bundled bank, then overlay the teacher's live Firestore edits/deletions.
    for(int i=0;i<bank.length();i++){JSONObject q=bank.optJSONObject(i);if(q!=null)exam.add(q);}
    if(db==null){filterExamForChapter(chapter);filterExamForType(selectedQuestionType);launchExam();return;}
    db.collection("questionDeletes").get(Source.SERVER).addOnSuccessListener(deleted->{
      HashSet<String> removed=new HashSet<>();for(DocumentSnapshot d:deleted.getDocuments())removed.add(d.getId());
      for(int i=exam.size()-1;i>=0;i--)if(removed.contains(exam.get(i).optString("id")))exam.remove(i);
      db.collection("questionEdits").get(Source.SERVER).addOnSuccessListener(edits->{
        for(DocumentSnapshot doc:edits.getDocuments())for(JSONObject q:exam)if(doc.getId().equals(q.optString("id"))){try{applyEdit(q,doc);}catch(Exception ignored){}break;}
        // Filter AFTER applying edits so moving a question to another chapter works correctly.
        filterExamForChapter(chapter);
        filterExamForType(selectedQuestionType);
        db.collection("questions").whereEqualTo("chapter",chapter).get(Source.SERVER).addOnSuccessListener(snapshot->{
          for(DocumentSnapshot doc:snapshot.getDocuments())try{JSONObject q=new JSONObject();q.put("id",doc.getId());q.put("chapter",chapter);q.put("type",doc.getString("type")==null?"MCQ":doc.getString("type"));q.put("question",doc.getString("question"));q.put("answer",doc.getString("answer"));q.put("explanation",doc.getString("explanation"));List<String> opts=(List<String>)doc.get("options");q.put("options",new JSONArray(opts==null?new ArrayList<>():opts));q.put("difficulty","Teacher-added");exam.add(q);}catch(Exception ignored){}
          filterExamForType(selectedQuestionType);
          launchExam();
        }).addOnFailureListener(e->{msg("تعذر تحميل أسئلة الأستاذ من الإنترنت. تحقق من الاتصال ثم أعد المحاولة.");});
      }).addOnFailureListener(e->{msg("تعذر مزامنة تعديلات الأسئلة. تحقق من الاتصال ثم أعد المحاولة.");});
    }).addOnFailureListener(e->{msg("تعذر مزامنة قائمة الأسئلة. تحقق من الاتصال ثم أعد المحاولة.");});
  }
  void filterExamForChapter(String chapter){
    for(int i=exam.size()-1;i>=0;i--){JSONObject q=exam.get(i);String qChapter=q.optString("chapter");if(!(chapter.equals(qChapter)||("Enzyme".equals(chapter)&&"Enzymes".equals(qChapter))))exam.remove(i);}
  }
  void filterExamForType(String type){
    for(int i=exam.size()-1;i>=0;i--){JSONObject q=exam.get(i);String qt=q.optString("type","MCQ");if(!type.equals(qt))exam.remove(i);}
  }
  void applyEdit(JSONObject q,DocumentSnapshot d)throws Exception{if(d.getString("chapter")!=null)q.put("chapter",d.getString("chapter"));if(d.getString("question")!=null)q.put("question",d.getString("question"));if(d.getString("answer")!=null)q.put("answer",d.getString("answer"));if(d.getString("type")!=null)q.put("type",d.getString("type"));if(d.getString("explanation")!=null)q.put("explanation",d.getString("explanation"));List<String> opts=(List<String>)d.get("options");if(opts!=null)q.put("options",new JSONArray(opts));}
  void launchExam(){if(exam.isEmpty()){new AlertDialog.Builder(this).setTitle(selectedChapter).setMessage("No questions are available in this chapter yet.").setPositiveButton("Back",(d,w)->chapters()).show();return;}Collections.shuffle(exam);index=0;correct=0;showQuestion();}
  void showQuestion(){
    if(index>=exam.size()){finishExam();return;}JSONObject q=exam.get(index);page(arabicChapter(selectedChapter));
    // Protect the actual question screen AFTER page() creates the new window content.
    getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,WindowManager.LayoutParams.FLAG_SECURE);
    TextView banner=txt("اختبار الكيمياء الحيوية  •  "+arabicChapter(selectedChapter),16,Color.WHITE,true);banner.setGravity(Gravity.CENTER);banner.setBackground(grad(DEEP,PURPLE,24));panel.addView(banner,new LinearLayout.LayoutParams(-1,-2));
    TextView progress=txt("السؤال  "+(index+1)+" من "+exam.size()+"     •     "+q.optString("difficulty","متوسط"),16,DEEP,true);progress.setGravity(Gravity.CENTER);progress.setBackground(solid(Color.WHITE,18));panel.addView(progress);
    TextView instruction=txt("اختر الإجابة الصحيحة الواحدة",14,MUTED,false);instruction.setGravity(Gravity.RIGHT);panel.addView(instruction);
    TextView question=txt(q.optString("question"),21,Color.WHITE,true);question.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);question.setTextDirection(View.TEXT_DIRECTION_LTR);question.setBackground(grad(DEEP,PURPLE,24));question.setPadding(18,22,18,22);question.setElevation(4);panel.addView(question);
    JSONArray opts=q.optJSONArray("options");
    ArrayList<String> visibleOptions=new ArrayList<>();if(opts!=null)for(int i=0;i<opts.length();i++){String value=opts.optString(i,"").trim();if(!value.isEmpty())visibleOptions.add(value);}
    String ans=q.optString("answer");
    if(visibleOptions.size()<2){
      instruction.setText(q.optString("type").equals("Written Question")?"اضغط على السؤال لإظهار الإجابة النموذجية":"هذه الحالة من المصدر لا تحتوي على اختيارات؛ اضغط لإظهار الإجابة");
      question.setOnClickListener(v->{answered=true;showQuestion();});
      if(answered){TextView reveal=txt((ans.isEmpty()?"لا توجد إجابة نموذجية في الملف المصدر.":"الإجابة النموذجية:\\n"+ans),17,NAVY,false);reveal.setTextDirection(View.TEXT_DIRECTION_LTR);reveal.setBackground(solid(Color.WHITE,20));reveal.setPadding(16,16,16,16);panel.addView(reveal);}
      else {TextView hint=txt("اضغط على السؤال لعرض الإجابة",15,TEAL,true);hint.setGravity(Gravity.CENTER);panel.addView(hint);}
    } else {
      if(q.optString("type").equals("True & False"))instruction.setText("اختر TRUE أو FALSE");

    for(int i=0;i<visibleOptions.size();i++){final int choice=i;String optionText=visibleOptions.get(i);String label=q.optString("type").equals("True & False")?optionText:letters[Math.min(i,letters.length-1)]+"     "+optionText;TextView option=txt(label,17,NAVY,true);option.setTextDirection(View.TEXT_DIRECTION_LTR);option.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);option.setPadding(18,14,14,14);int bg=Color.WHITE;if(answered&&optionText.equals(ans))bg=Color.rgb(218,250,228);else if(answered&&i==selectedChoice)bg=Color.rgb(255,230,230);option.setBackground(outlineBox(bg,answered&&optionText.equals(ans)?GREEN:PURPLE,24));option.setElevation(3);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,6,0,6);panel.addView(option,lp);option.setOnClickListener(v->{if(!answered)answer(choice);});}
    if(answered){
      boolean ok=selectedChoice>=0&&selectedChoice<visibleOptions.size()&&visibleOptions.get(selectedChoice).equals(ans);
      TextView status=txt(ok?"✓  إجابة صحيحة":"✕  إجابة غير صحيحة",20,ok?Color.rgb(0,125,45):Color.rgb(175,35,35),true);status.setGravity(Gravity.CENTER);status.setBackground(solid(ok?Color.rgb(218,250,228):Color.rgb(255,232,232),24));panel.addView(status);
      TextView correctBox=txt("الإجابة الصحيحة:  "+ans,16,NAVY,true);correctBox.setBackground(solid(Color.WHITE,18));panel.addView(correctBox);
      TextView explanation=txt("التفسير:\n"+q.optString("explanation"),15,NAVY,false);explanation.setBackground(solid(Color.WHITE,18));panel.addView(explanation);
    }
    }
    LinearLayout nav=new LinearLayout(this);nav.setOrientation(LinearLayout.HORIZONTAL);LinearLayout.LayoutParams navp=new LinearLayout.LayoutParams(-1,-2);navp.setMargins(0,10,0,0);panel.addView(nav,navp);
    Button prev=new Button(this);prev.setText("السابق");prev.setAllCaps(false);prev.setTextColor(Color.WHITE);prev.setBackground(grad(PURPLE,DEEP,24));nav.addView(prev,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));prev.setOnClickListener(v->{if(index>0){index--;answered=false;selectedChoice=-1;showQuestion();}});
    Button next=new Button(this);next.setText(index==exam.size()-1?"إنهاء":"التالي");next.setAllCaps(false);next.setTextColor(Color.WHITE);next.setBackground(grad(TEAL,BLUE,24));LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1);np.setMargins(8,0,0,0);nav.addView(next,np);next.setOnClickListener(v->{if(!answered){msg(visibleOptions.size()<2?"اضغط على السؤال أولاً لإظهار الإجابة.":"اختر إجابة أولاً.");return;}if(index==exam.size()-1)finishExam();else{index++;answered=false;selectedChoice=-1;showQuestion();}});
  }
  void answer(int choice){JSONObject q=exam.get(index);JSONArray opts=q.optJSONArray("options");ArrayList<String> visible=new ArrayList<>();if(opts!=null)for(int i=0;i<opts.length();i++){String value=opts.optString(i,"").trim();if(!value.isEmpty())visible.add(value);}selectedChoice=choice;answered=true;if(choice>=0&&choice<visible.size()&&visible.get(choice).equals(q.optString("answer")))correct++;showQuestion();}
  void finishExam(){int ungraded=0;for(JSONObject q:exam){JSONArray o=q.optJSONArray("options");if(o==null||o.length()<2)ungraded++;}int total=exam.size()-ungraded,wrong=total-correct;double pct=total==0?0:100.0*correct/total;saveResult(correct,wrong,pct,total);
    page("نتيجة الفصل");getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,WindowManager.LayoutParams.FLAG_SECURE);TextView result=txt("✓  Exam Completed!\\n\\n"+selectedChapter+"\\n\\n"+correct+" / "+total+"\\n"+String.format(Locale.US,"%.1f%%",pct)+"\\n\\nCorrect: "+correct+"     Wrong: "+wrong+(ungraded>0?"\\nAnswer-reveal questions: "+ungraded:""),23,NAVY,true);result.setGravity(Gravity.CENTER);result.setBackground(grad(Color.rgb(236,250,255),Color.rgb(245,239,255),26));panel.addView(result);
    button("Review Answers",PURPLE,BLUE,()->reviewAnswers());button("My Overall Results",TEAL,BLUE,()->studentResults());button("العودة إلى الفصول",BLUE,TEAL,()->chapters());}
  void saveResult(int c,int w,double pct,int total){if(db==null||auth==null||auth.getCurrentUser()==null)return;Map<String,Object> r=new HashMap<>();r.put("studentName",studentName);r.put("studentUid",auth.getCurrentUser().getUid());r.put("chapter",selectedChapter);r.put("correct",c);r.put("wrong",w);r.put("total",total);r.put("percentage",pct);r.put("createdAt",FieldValue.serverTimestamp());db.collection("results").add(r);}
  void reviewAnswers(){page("مراجعة الإجابات");getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,WindowManager.LayoutParams.FLAG_SECURE);for(int i=0;i<exam.size();i++){JSONObject q=exam.get(i);card("Q"+(i+1)+": "+q.optString("question"),NAVY);card("Correct answer: "+q.optString("answer"),TEAL);card(q.optString("explanation"),MUTED);}button("رجوع إلى الفصول",BLUE,TEAL,()->chapters());}
  void studentResults(){if(db==null||auth==null||auth.getCurrentUser()==null){page("My Results");getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,WindowManager.LayoutParams.FLAG_SECURE);card("Firebase connection is required to load saved results.",MUTED);return;}page("My Results");getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,WindowManager.LayoutParams.FLAG_SECURE);db.collection("results").whereEqualTo("studentUid",auth.getCurrentUser().getUid()).get().addOnSuccessListener(s->{panel.removeAllViews();if(s.isEmpty()){card("No saved results yet.",MUTED);return;}Map<String,int[]> sums=new LinkedHashMap<>();for(DocumentSnapshot d:s.getDocuments()){String ch=d.getString("chapter");int[] a=sums.get(ch);if(a==null){a=new int[3];sums.put(ch,a);}a[0]+=num(d,"correct");a[1]+=num(d,"wrong");a[2]+=num(d,"total");}
      int c=0,w=0,t=0;for(Map.Entry<String,int[]> e:sums.entrySet()){int[] a=e.getValue();c+=a[0];w+=a[1];t+=a[2];card(e.getKey()+"\\nCorrect: "+a[0]+"   Wrong: "+a[1]+"\\nScore: "+String.format(Locale.US,"%.1f%%",a[2]==0?0:100.0*a[0]/a[2]),NAVY);}card("OVERALL TOTAL\\nCorrect: "+c+"   Wrong: "+w+"   Score: "+String.format(Locale.US,"%.1f%%",t==0?0:100.0*c/t),TEAL);
    }).addOnFailureListener(e->card("Could not load results. Check connection.",MUTED));}
  int num(DocumentSnapshot d,String k){Long n=d.getLong(k);return n==null?0:n.intValue();}
  void teacherGate(String destination){
    LinearLayout form=new LinearLayout(this);form.setOrientation(1);form.setPadding(24,8,24,8);
    EditText password=new EditText(this);password.setSingleLine(true);password.setHint("أدخل الرقم السري فقط");password.setInputType(129);form.addView(password);
    new AlertDialog.Builder(this).setTitle("دخول الأستاذ").setView(form).setPositiveButton("دخول",(d,w)->verifyTeacher("Ahmedalksher70@gmail.com",password.getText().toString(),destination)).setNegativeButton("إلغاء",null).show();
  }
  void verifyTeacher(String email,String password,String dest){
    if(!hasInternet()){msg("يلزم الاتصال بالإنترنت.");return;}if(!"ahmedalksher70@gmail.com".equalsIgnoreCase(email)){msg("البريد غير مصرح له بدخول لوحة المدرّس.");return;}
    if(teacherAuth==null||teacherDb==null){msg("جلسة المدرّس غير مهيأة.");return;}
    teacherAuth.signInWithEmailAndPassword(email,password).addOnSuccessListener(r->{
      auth=teacherAuth;db=teacherDb;teacher=true;teacherPinSession="email-auth";
      if("panel".equals(dest))teacherPanel();else getTeacherToken(dest);
    }).addOnFailureListener(e->msg("تعذر دخول المدرّس: "+e.getLocalizedMessage()+". تأكد من كلمة المرور وتفعيل Email/Password في Firebase."));
  }
  void getTeacherToken(String dest){if("panel".equals(dest))teacherPanel();else if("results".equals(dest))teacherResults();else if("add".equals(dest))addQuestion();else if("edit".equals(dest))editQuestionPicker();else if("password".equals(dest))changePasswordForm();}
  void teacherPanel(){
    if(!teacher || teacherAuth==null || teacherAuth.getCurrentUser()==null){msg("غير مصرح بالدخول");teacher=false;auth=studentAuth;db=studentDb;home();return;}
    page("لوحة الأستاذ");
    card("إدارة بنك الأسئلة والمنهج وطلبات تسجيل الطلاب",DEEP);
    button("طلبات تسجيل الطلاب — قبول / رفض / إيقاف",TEAL,BLUE,()->teacherStudents());
    button("بنك الأسئلة — مشاهدة / إضافة / تعديل / حذف",PURPLE,DEEP,()->teacherQuestionBank());
    button("المنهج — إضافة Chapter / حذف Chapter",TEAL,BLUE,()->teacherPdfManager());
    button("نتائج الطلاب",BLUE,TEAL,()->teacherResults());
    button("إرسال إشعار للطلاب (الجميع / طالب محدد)",PURPLE,DEEP,()->sendInAppNotificationForm());
    button("إيقاف / تفعيل التطبيق",Color.rgb(190,110,25),DEEP,()->toggleAppAvailability());
    button("تغيير الرقم السري للأستاذ",TEAL,BLUE,()->changePasswordForm());
    button("تسجيل خروج الأستاذ",Color.GRAY,MUTED,()->{teacherAuth.signOut();teacher=false;teacherPinSession="";auth=studentAuth;db=studentDb;home();});
  }
  void teacherQuestionBank(){
    if(!teacher || teacherAuth.getCurrentUser()==null){msg("غير مصرح بالدخول");return;}
    page("بنك الأسئلة");
    button("إضافة سؤال جديد",TEAL,BLUE,()->addQuestion());
    button("تعديل أو حذف سؤال",PURPLE,DEEP,()->editQuestionPicker());
    Map<String,Integer> typeCounts=new LinkedHashMap<>();for(String t:questionTypes())typeCounts.put(t,0);for(int i=0;i<bank.length();i++){JSONObject q=bank.optJSONObject(i);if(q!=null){String t=q.optString("type","MCQ");typeCounts.put(t,typeCounts.getOrDefault(t,0)+1);}}
    card("الأسئلة المدمجة حسب النوع\nMCQ: "+typeCounts.get("MCQ")+"\nCase Question: "+typeCounts.get("Case Question")+"\nTrue & False: "+typeCounts.get("True & False")+"\nWritten Question: "+typeCounts.get("Written Question")+"\n\nيمكنك إضافة وتعديل وحذف جميع الأنواع الأربعة. تُحفظ التغييرات على Firestore وتُحمّل من الخادم عند فتح الطالب للفصل.",NAVY);
    button("العودة",Color.GRAY,MUTED,()->teacherPanel());
  }
  void teacherStudents(){
    if(!teacher){msg("غير مصرح بالدخول");return;}page("طلبات تسجيل الطلاب");card("جارٍ تحميل الطلبات...",MUTED);
    db.collection("students").orderBy("requestedAt",Query.Direction.DESCENDING).limit(300).get().addOnSuccessListener(snapshot->{panel.removeAllViews();if(snapshot.isEmpty()){card("لا توجد طلبات تسجيل حالياً.",MUTED);return;}for(DocumentSnapshot st:snapshot.getDocuments()){String uid=st.getId(),name=st.getString("name"),phone=st.getString("phone"),status=st.getString("status");card((name==null?"":name)+"\n"+(phone==null?"":phone)+"\nالحالة: "+status,NAVY);if(!"Approved".equals(status)){button("قبول الطالب وتحديد المدة",TEAL,BLUE,()->chooseSubscription(uid));button("رفض الطلب",PURPLE,DEEP,()->decideStudent(uid,"Rejected",0));}else{button("تجديد الاشتراك",TEAL,BLUE,()->chooseSubscription(uid));button("إيقاف الاشتراك",PURPLE,DEEP,()->decideStudent(uid,"Rejected",0));}}}).addOnFailureListener(e->msg("تعذر تحميل الطلبات من Firestore: "+e.getLocalizedMessage()));
  }
  void chooseSubscription(String uid){String[] labels={"30 يوماً","40 يوماً","60 يوماً","6 أشهر — 180 يوماً","سنة — 365 يوماً"};int[] days={30,40,60,180,365};new AlertDialog.Builder(this).setTitle("مدة اشتراك الطالب").setItems(labels,(d,w)->decideStudent(uid,"Approved",days[w])).setNegativeButton("إلغاء",null).show();}
  void decideStudent(String uid,String decision,int days){Map<String,Object> data=new HashMap<>();data.put("status",decision);data.put("decidedAt",FieldValue.serverTimestamp());if(days>0){Timestamp start=Timestamp.now();data.put("subscriptionDays",days);data.put("activatedAt",start);data.put("expiresAt",new Timestamp(new Date(start.toDate().getTime()+days*86400000L)));}else{data.put("expiresAt",null);}db.collection("students").document(uid).update(data).addOnSuccessListener(v->{msg("تم تحديث حالة الطالب.");teacherStudents();}).addOnFailureListener(e->msg("تعذر تحديث الطالب: "+e.getLocalizedMessage()));}
  void teacherResults(){if(!teacher){msg("Not authorized");return;}page("Students Results");db.collection("results").orderBy("createdAt",Query.Direction.DESCENDING).limit(1000).get().addOnSuccessListener(s->{panel.removeAllViews();Map<String,Map<String,int[]>> students=new LinkedHashMap<>();Map<String,String> names=new HashMap<>();for(DocumentSnapshot d:s.getDocuments()){String uid=d.getString("studentUid");if(uid==null)continue;names.put(uid,d.getString("studentName"));Map<String,int[]> by=students.get(uid);if(by==null){by=new LinkedHashMap<>();students.put(uid,by);}String ch=d.getString("chapter");int[] a=by.get(ch);if(a==null){a=new int[3];by.put(ch,a);}a[0]+=num(d,"correct");a[1]+=num(d,"wrong");a[2]+=num(d,"total");}
      for(String uid:students.keySet()){card("STUDENT: "+names.get(uid),PURPLE);int c=0,w=0,t=0;for(Map.Entry<String,int[]> e:students.get(uid).entrySet()){int[] a=e.getValue();c+=a[0];w+=a[1];t+=a[2];card(e.getKey()+"\\nCorrect "+a[0]+" • Wrong "+a[1]+" • "+String.format(Locale.US,"%.1f%%",a[2]==0?0:100.0*a[0]/a[2]),NAVY);}card("TOTAL: "+c+" correct • "+w+" wrong • "+String.format(Locale.US,"%.1f%%",t==0?0:100.0*c/t),TEAL);}
    }).addOnFailureListener(e->msg("Could not load teacher results. Check Firestore rules."));}

  void chooseQuestionImportFile(){
    if(!teacher){msg("هذه الخاصية للأستاذ فقط.");return;}
    loadCustomChapters(()->openQuestionImportPicker());
  }
  void openQuestionImportPicker(){
    android.content.Intent intent=new android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT);
    intent.addCategory(android.content.Intent.CATEGORY_OPENABLE);intent.setType("application/json");
    startActivityForResult(intent,PICK_QUESTION_JSON);
  }
  void readQuestionImportFile(android.net.Uri uri){
    if(!teacher){msg("هذه الخاصية للأستاذ فقط.");return;}
    try{
      java.io.InputStream in=getContentResolver().openInputStream(uri);if(in==null){msg("تعذر قراءة الملف.");return;}
      java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] buf=new byte[8192];int n;
      while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>10*1024*1024){in.close();msg("ملف بنك الأسئلة أكبر من 10 MB.");return;}}in.close();
      JSONObject rootJson=new JSONObject(new String(out.toByteArray(),"UTF-8"));JSONArray arr=rootJson.optJSONArray("questions");
      if(arr==null||arr.length()==0){msg("صيغة الملف غير صحيحة. يجب أن يحتوي على questions.");return;}
      JSONArray valid=new JSONArray();int skipped=0;
      for(int i=0;i<arr.length();i++){
        JSONObject q=arr.optJSONObject(i);if(q==null){skipped++;continue;}
        String chapter=q.optString("chapter").trim(),stem=q.optString("question").trim(),answer=q.optString("answer").trim(),ex=q.optString("explanation","").trim();JSONArray options=q.optJSONArray("options");
        if(!Arrays.asList(activeChapters()).contains(chapter)||stem.isEmpty()||answer.isEmpty()||options==null||options.length()!=4){skipped++;continue;}
        HashSet<String> unique=new HashSet<>();boolean ok=true;boolean hasAnswer=false;for(int j=0;j<4;j++){String op=options.optString(j).trim();if(op.isEmpty()||!unique.add(op))ok=false;if(op.equals(answer))hasAnswer=true;}
        if(!ok||!hasAnswer){skipped++;continue;}
        JSONObject clean=new JSONObject();clean.put("chapter",chapter);clean.put("question",stem);clean.put("options",options);clean.put("answer",answer);clean.put("explanation",ex);valid.put(clean);
      }
      if(valid.length()==0){msg("لم أجد أسئلة صالحة. تأكد من اسم الفصل وأربعة اختيارات والإجابة الصحيحة.");return;}
      pendingImportQuestions=valid;
      new AlertDialog.Builder(this).setTitle("معاينة بنك الأسئلة").setMessage("الأسئلة الصالحة: "+valid.length()+"\nالأسئلة التي تم تجاهلها: "+skipped+"\n\nسيتم إضافة الأسئلة إلى القديمة ولن تُحذف الأسئلة الحالية. هل تريد النشر؟")
        .setNegativeButton("مراجعة لاحقاً",(d,w)->teacherPanel()).setPositiveButton("اعتماد ونشر",(d,w)->publishImportedQuestions()).show();
    }catch(Exception e){msg("تعذر قراءة ملف JSON: "+e.getLocalizedMessage());}
  }
  void publishImportedQuestions(){
    if(!teacher||pendingImportQuestions.length()==0){msg("لا توجد أسئلة جاهزة للنشر.");return;}
    FirebaseUser user=teacherAuth==null?null:teacherAuth.getCurrentUser();if(user==null){msg("انتهت جلسة الأستاذ. سجّل الدخول مجدداً.");return;}
    final int total=pendingImportQuestions.length();final int[] position={0};
    card("جارٍ نشر "+total+" سؤالاً إلى قاعدة البيانات...",MUTED);
    publishImportChunk(total,position);
  }
  void publishImportChunk(int total,int[] position){
    if(position[0]>=total){
      Map<String,Object> config=new HashMap<>();config.put("contentVersion",FieldValue.increment(1));config.put("updatedAt",FieldValue.serverTimestamp());config.put("lastImportCount",total);config.put("updatedBy",teacherAuth.getCurrentUser().getUid());
      db.collection("appConfig").document("content").set(config,SetOptions.merge()).addOnSuccessListener(v->{pendingImportQuestions=new JSONArray();msg("تم نشر "+total+" سؤالاً بنجاح. ستظهر للطلاب عند فتح الاختبار أو بنك الأسئلة، دون تحديث APK.");teacherPanel();}).addOnFailureListener(e->msg("تم رفع الأسئلة، لكن تعذر تحديث رقم إصدار المحتوى: "+e.getLocalizedMessage()));return;
    }
    WriteBatch batch=db.batch();int end=Math.min(position[0]+400,total);
    for(int i=position[0];i<end;i++)try{JSONObject q=pendingImportQuestions.getJSONObject(i);Map<String,Object> m=new HashMap<>();m.put("chapter",q.getString("chapter"));m.put("type",q.optString("type","MCQ"));m.put("question",q.getString("question"));ArrayList<String> opts=new ArrayList<>();JSONArray a=q.getJSONArray("options");for(int j=0;j<a.length();j++)opts.add(a.getString(j));m.put("options",opts);m.put("answer",q.getString("answer"));m.put("explanation",q.optString("explanation",""));m.put("createdBy",teacherAuth.getCurrentUser().getUid());m.put("createdAt",FieldValue.serverTimestamp());m.put("source","teacher-json-import");String stable=sha256(q.getString("chapter")+"|"+q.optString("type","MCQ")+"|"+q.getString("question")+"|"+opts.toString()+"|"+q.getString("answer"));batch.set(db.collection("questions").document("import_"+stable),m);}catch(Exception ignored){}
    final int next=end;batch.commit().addOnSuccessListener(v->{position[0]=next;publishImportChunk(total,position);}).addOnFailureListener(e->msg("توقف نشر الأسئلة عند "+position[0]+" من "+total+". السبب: "+e.getLocalizedMessage()));
  }
  String[] questionTypes(){return new String[]{"MCQ","Case Question","True & False","Written Question"};}
  void addQuestion(){
    if(!teacher||teacherAuth==null||teacherAuth.getCurrentUser()==null){msg("غير مصرح بالدخول");return;}
    loadCustomChapters(()->questionEditor(null,null));
  }
  void questionEditor(JSONObject existing,String documentId){
    boolean editing=existing!=null;
    page(editing?"تعديل السؤال":"إضافة سؤال جديد");
    if(editing)card("Question ID: "+documentId,TEAL);
    Spinner chapter=new Spinner(this);ArrayAdapter<String> ca=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,activeChapters());chapter.setAdapter(ca);panel.addView(chapter);
    String[] types=questionTypes();Spinner type=new Spinner(this);type.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,types));panel.addView(type);
    if(editing){chapter.setSelection(Math.max(0,Arrays.asList(activeChapters()).indexOf(existing.optString("chapter"))));int ti=Arrays.asList(types).indexOf(existing.optString("type","MCQ"));type.setSelection(Math.max(0,ti));}
    EditText stem=field("Question / Case / Statement");if(editing)stem.setText(existing.optString("question"));
    EditText[] opts=new EditText[4];EditText answer=field("Correct answer / Model answer");if(editing)answer.setText(existing.optString("answer"));
    EditText explanation=field("Explanation (optional)");if(editing)explanation.setText(existing.optString("explanation"));
    LinearLayout optionsHolder=new LinearLayout(this);optionsHolder.setOrientation(1);panel.addView(optionsHolder);
    Runnable renderOptions=()->{
      optionsHolder.removeAllViews();String selected=(String)type.getSelectedItem();JSONArray old=editing?existing.optJSONArray("options"):null;
      int count="MCQ".equals(selected)||"Case Question".equals(selected)?4:("True & False".equals(selected)?2:0);
      for(int i=0;i<count;i++){
        EditText option=new EditText(this);option.setSingleLine(false);option.setTextSize(15);option.setHint("True & False".equals(selected)?(i==0?"True":"False"):"Option "+letters[i]);option.setPadding(14,10,14,10);option.setBackground(solid(Color.WHITE,16));
        if(old!=null&&i<old.length())option.setText(old.optString(i));else if("True & False".equals(selected))option.setText(i==0?"True":"False");
        optionsHolder.addView(option,new LinearLayout.LayoutParams(-1,-2));opts[i]=option;
      }
    };
    type.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){renderOptions.run();}public void onNothingSelected(android.widget.AdapterView<?> p){}});
    renderOptions.run();
    button(editing?"حفظ التعديلات ونشرها":"إضافة السؤال ونشره",PURPLE,DEEP,()->{
      FirebaseUser user=teacherAuth==null?null:teacherAuth.getCurrentUser();if(!teacher||user==null){msg("انتهت جلسة المعلم. سجّل الدخول مجدداً.");return;}
      String ch=(String)chapter.getSelectedItem(),qt=(String)type.getSelectedItem(),text=stem.getText().toString().trim(),ans=answer.getText().toString().trim();
      if(ch==null||text.isEmpty()||ans.isEmpty()){msg("أكمل اسم الفصل والسؤال والإجابة.");return;}
      Map<String,Object> data=new HashMap<>();data.put("chapter",ch);data.put("type",qt);data.put("question",text);data.put("answer",ans);data.put("explanation",explanation.getText().toString().trim());data.put("updatedAt",FieldValue.serverTimestamp());data.put("updatedBy",user.getUid());
      ArrayList<String> values=new ArrayList<>();int count="MCQ".equals(qt)||"Case Question".equals(qt)?4:("True & False".equals(qt)?2:0);
      for(int i=0;i<count;i++){String value=opts[i]==null?"":opts[i].getText().toString().trim();if(value.isEmpty()){msg("أكمل جميع الاختيارات.");return;}values.add(value);}
      if(count>0&&(!new HashSet<>(values).contains(ans)||new HashSet<>(values).size()!=values.size())){msg("يجب أن تطابق الإجابة الصحيحة أحد الاختيارات، وأن تكون الاختيارات مختلفة.");return;}
      if(count>0)data.put("options",values);else data.put("options",new ArrayList<String>());
      if(!editing){data.put("createdAt",FieldValue.serverTimestamp());data.put("createdBy",user.getUid());db.collection("questions").add(data).addOnSuccessListener(ref->{bumpContentVersion("تمت إضافة السؤال ونشره للطلاب مباشرة.");}).addOnFailureListener(e->msg("تعذر إضافة السؤال: "+e.getLocalizedMessage()));}
      else if(existing.optBoolean("teacherAdded")){db.collection("questions").document(documentId).set(data,SetOptions.merge()).addOnSuccessListener(v->{bumpContentVersion("تم تعديل السؤال ونشر التعديل للطلاب مباشرة.");}).addOnFailureListener(e->msg("تعذر تعديل السؤال: "+e.getLocalizedMessage()));}
      else{db.collection("questionEdits").document(documentId).set(data,SetOptions.merge()).addOnSuccessListener(v->{bumpContentVersion("تم تعديل السؤال الأصلي ونشر التعديل للطلاب مباشرة.");}).addOnFailureListener(e->msg("تعذر حفظ التعديل: "+e.getLocalizedMessage()));}
    });
    if(editing)button("حذف السؤال",Color.rgb(170,35,55),DEEP,()->new AlertDialog.Builder(this).setTitle("تأكيد الحذف").setMessage("سيتم إخفاء هذا السؤال عن جميع الطلاب.").setNegativeButton("إلغاء",null).setPositiveButton("حذف",(d,w)->{
      if(existing.optBoolean("teacherAdded"))db.collection("questions").document(documentId).delete().addOnSuccessListener(v->bumpContentVersion("تم حذف السؤال من بنك الطلاب." )).addOnFailureListener(e->msg("تعذر الحذف: "+e.getLocalizedMessage()));
      else{Map<String,Object> marker=new HashMap<>();marker.put("deleted",true);marker.put("deletedAt",FieldValue.serverTimestamp());marker.put("deletedBy",teacherAuth.getCurrentUser().getUid());db.collection("questionDeletes").document(documentId).set(marker,SetOptions.merge()).addOnSuccessListener(v->bumpContentVersion("تم إخفاء السؤال من بنك الطلاب." )).addOnFailureListener(e->msg("تعذر الحذف: "+e.getLocalizedMessage()));}
    }).show());
    button("العودة إلى بنك الأسئلة",Color.GRAY,MUTED,()->teacherQuestionBank());
  }
  void bumpContentVersion(String message){Map<String,Object> config=new HashMap<>();config.put("contentVersion",FieldValue.increment(1));config.put("updatedAt",FieldValue.serverTimestamp());if(teacherAuth!=null&&teacherAuth.getCurrentUser()!=null)config.put("updatedBy",teacherAuth.getCurrentUser().getUid());db.collection("appConfig").document("content").set(config,SetOptions.merge()).addOnSuccessListener(v->{msg(message);teacherQuestionBank();}).addOnFailureListener(e->{msg(message+" لكن تعذر تحديث رقم إصدار المحتوى: "+e.getLocalizedMessage());teacherQuestionBank();});}
  void editQuestionPicker(){
    if(!teacher||teacherAuth==null||teacherAuth.getCurrentUser()==null){msg("غير مصرح بالدخول");return;}
    loadCustomChapters(()->renderEditQuestionPicker());
  }
  void renderEditQuestionPicker(){
    page("اختيار أسئلة للتعديل أو الحذف");
    Spinner chapter=new Spinner(this);chapter.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,activeChapters()));panel.addView(chapter);
    Spinner type=new Spinner(this);type.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,questionTypes()));panel.addView(type);
    button("عرض أسئلة هذا الفصل والنوع",TEAL,BLUE,()->loadQuestionPicker((String)chapter.getSelectedItem(),(String)type.getSelectedItem()));
    card("اختر الفصل ونوع السؤال لعرض قائمة مختصرة بدلاً من تحميل بنك الأسئلة كاملاً مرة واحدة.",MUTED);
    button("العودة إلى بنك الأسئلة",Color.GRAY,MUTED,()->teacherQuestionBank());
  }
  void loadQuestionPicker(String selectedChapter,String selectedType){
    if(!teacher||selectedChapter==null||selectedType==null)return;
    page("أسئلة "+selectedChapter+" — "+selectedType);card("الأسئلة الأصلية",DEEP);
    db.collection("questionDeletes").get(Source.SERVER).addOnSuccessListener(deleted->{
      HashSet<String> removed=new HashSet<>();for(DocumentSnapshot d:deleted.getDocuments())removed.add(d.getId());
      db.collection("questionEdits").get(Source.SERVER).addOnSuccessListener(edits->{
        HashMap<String,DocumentSnapshot> changes=new HashMap<>();for(DocumentSnapshot d:edits.getDocuments())changes.put(d.getId(),d);
        int shown=0;
        for(int i=0;i<bank.length();i++){
          JSONObject original=bank.optJSONObject(i);if(original==null)continue;String id=original.optString("id");if(id.isEmpty()||removed.contains(id))continue;
          try{JSONObject q=new JSONObject(original.toString());DocumentSnapshot edit=changes.get(id);if(edit!=null)applyEdit(q,edit);
            if(!selectedChapter.equals(q.optString("chapter"))||!selectedType.equals(q.optString("type","MCQ")))continue;
            shown++;button(q.optString("id")+"\n"+q.optString("question"),PURPLE,BLUE,()->questionEditor(q,id));
          }catch(Exception ignored){}
        }
        card("عدد الأسئلة الأصلية المعروضة: "+shown,NAVY);
        sectionTitle("الأسئلة التي أضافها المعلم");
        db.collection("questions").whereEqualTo("chapter",selectedChapter).get(Source.SERVER).addOnSuccessListener(snapshot->{
          int[] cloudCount={0};for(DocumentSnapshot doc:snapshot.getDocuments())try{
            String qType=doc.getString("type");if(qType==null)qType="MCQ";if(!selectedType.equals(qType))continue;
            JSONObject q=new JSONObject();q.put("id",doc.getId());q.put("teacherAdded",true);q.put("chapter",doc.getString("chapter"));q.put("type",qType);q.put("question",doc.getString("question"));q.put("answer",doc.getString("answer"));q.put("explanation",doc.getString("explanation"));List<String> values=(List<String>)doc.get("options");q.put("options",new JSONArray(values==null?new ArrayList<>():values));cloudCount[0]++;button("[مضاف] "+q.optString("question"),TEAL,BLUE,()->questionEditor(q,doc.getId()));
          }catch(Exception ignored){}
          card("عدد الأسئلة المضافة: "+cloudCount[0],TEAL);
          button("اختيار فصل أو نوع آخر",BLUE,TEAL,()->editQuestionPicker());
        }).addOnFailureListener(e->msg("تعذر تحميل الأسئلة المضافة: "+e.getLocalizedMessage()));
      }).addOnFailureListener(e->msg("تعذر تحميل تعديلات الأسئلة: "+e.getLocalizedMessage()));
    }).addOnFailureListener(e->msg("تعذر تحميل قائمة الأسئلة المحذوفة: "+e.getLocalizedMessage()));
  }
  void changePasswordForm(){if(!teacher){msg("Not authorized");return;}page("Change Teacher Password");EditText current=field("Current password");current.setInputType(129);EditText next=field("New password (at least 8 characters)");next.setInputType(129);EditText confirm=field("Confirm new password");confirm.setInputType(129);
    button("Update Password",PURPLE,DEEP,()->{String n=next.getText().toString();if(n.length()<8){next.setError("Use at least 8 characters");return;}if(!n.equals(confirm.getText().toString())){confirm.setError("Passwords do not match");return;}FirebaseUser user=teacherAuth.getCurrentUser();if(user==null||user.getEmail()==null){msg("يرجى تسجيل دخول الأستاذ من جديد.");return;}com.google.firebase.auth.AuthCredential credential=com.google.firebase.auth.EmailAuthProvider.getCredential(user.getEmail(),current.getText().toString());user.reauthenticate(credential).addOnSuccessListener(v->user.updatePassword(n).addOnSuccessListener(x->{msg("تم تغيير كلمة المرور بنجاح.");teacherPanel();}).addOnFailureListener(e->msg("تعذر تغيير كلمة المرور: "+e.getLocalizedMessage()))).addOnFailureListener(e->msg("كلمة المرور الحالية غير صحيحة: "+e.getLocalizedMessage()));});
    button("العودة",Color.GRAY,MUTED,()->teacherPanel());}
  void msg(String s){new AlertDialog.Builder(this).setMessage(s).setPositiveButton("OK",null).show();}
}
