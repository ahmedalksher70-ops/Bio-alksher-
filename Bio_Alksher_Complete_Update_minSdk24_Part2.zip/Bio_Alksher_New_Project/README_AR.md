# Bio Alksher — نسخة Spark المعتمدة

هذه حزمة مصدر Android لمشروع Bio Alksher، تستخدم مشروع Firebase الحالي نفسه للحفاظ على حسابات الطلاب والاشتراكات والبيانات:
- Firebase project ID: `biochemistry-easy-with`
- Android applicationId: `com.biochem.easy`
- خطة التشغيل المستهدفة: Firebase Spark.

## وظائف المحتوى
- استيراد بنك أسئلة من ملف JSON بعد أن يحوّل الأستاذ ملفات PDF إلى MCQ ويراجعها خارج التطبيق.
- إضافة الأسئلة وتعديلها وحذفها من لوحة الأستاذ.
- مزامنة الأسئلة والفصول الإضافية من Firestore دون APK جديد بعد تثبيت هذا الإصدار.
- إدارة ملفات المنهج PDF: إضافة ملف، استبداله، حذفه، وعرض الملفات المضافة للطلاب.
- حد رفع PDF مضبوط على 25 MiB في Android و`LectureFiles.gs`، ويجب اختبار ملف فعلي قريب من الحد على نشر Apps Script.

## الإشعارات
- زر مستقل لنشر رسالة داخل التطبيق عبر Firestore.
- زر مستقل لإرسال إشعار Push إلى الهاتف عبر `FCM.gs` وFCM HTTP v1 من Google Apps Script.
- يلزم دمج مسارات Apps Script ونطاقات OAuth واتباع `INSTALL_LECTURE_PDF_AR.md` قبل تفعيل الإرسال.

## إعداد المشروع
1. افتح Android project في Android Studio.
2. احتفظ بملف `app/google-services.json` وملف التطبيق `applicationId` كما هما.
3. راجع `firestore/firestore.rules` ثم انشر قواعد Firestore إلى المشروع الحالي بعد التأكد من UID الأستاذ.
4. اتبع `INSTALL_LECTURE_PDF_AR.md` لدمج `LectureFiles.gs` و`FCM.gs` في Apps Script الحالي ثم نشر Web App جديد.
5. ابنِ APK واختبره على جهاز أستاذ وجهاز طالب قبل التوزيع.

## تنبيه
هذه حزمة مصدر معدّلة وليست APK نهائياً. لم يتم بناء التطبيق أو نشر قواعد Firestore/Apps Script من هنا. لا تنشئ Firebase project جديداً ولا تحذف المشروع الحالي.
