package com.biochem.easy;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;
import android.view.WindowManager;
import java.io.*;

public class LecturePdfActivity extends Activity {
  private PdfRenderer renderer;
  private PdfRenderer.Page page;
  private int pageIndex=0;
  private ImageView image;
  private TextView counter;
  private String title="PDF", asset="";
  private SharedPreferences prefs;

  @Override public void onCreate(Bundle b){
    super.onCreate(b);
    getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,WindowManager.LayoutParams.FLAG_SECURE);
    title=getIntent().getStringExtra("title");
    asset=getIntent().getStringExtra("assetName");
    if(asset==null)asset="";
    prefs=getSharedPreferences("bio_pdf_pages",MODE_PRIVATE);
    pageIndex=Math.max(0,prefs.getInt(asset,0));

    LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(8,6,8,6);root.setBackgroundColor(Color.rgb(249,247,253));
    LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setOrientation(0);
    Button back=new Button(this);back.setText("رجوع");back.setAllCaps(false);header.addView(back,new LinearLayout.LayoutParams(-2,-2));
    TextView heading=new TextView(this);heading.setText(title==null?"ملف PDF":title);heading.setTextSize(18);heading.setTypeface(null,android.graphics.Typeface.BOLD);heading.setTextColor(Color.rgb(54,27,105));heading.setGravity(Gravity.CENTER);header.addView(heading,new LinearLayout.LayoutParams(0,-2,1));
    root.addView(header,new LinearLayout.LayoutParams(-1,-2));

    image=new ImageView(this);image.setAdjustViewBounds(true);image.setScaleType(ImageView.ScaleType.FIT_CENTER);image.setBackgroundColor(Color.WHITE);
    FrameLayout pageFrame=new FrameLayout(this);pageFrame.setBackgroundColor(Color.WHITE);pageFrame.addView(image,new FrameLayout.LayoutParams(-1,-1));
    View left=new View(this),right=new View(this);left.setBackgroundColor(Color.TRANSPARENT);right.setBackgroundColor(Color.TRANSPARENT);
    FrameLayout.LayoutParams leftParams=new FrameLayout.LayoutParams(-1,-1,Gravity.LEFT);leftParams.width=-1;leftParams.rightMargin=getResources().getDisplayMetrics().widthPixels/2;
    FrameLayout.LayoutParams rightParams=new FrameLayout.LayoutParams(-1,-1,Gravity.RIGHT);rightParams.width=-1;rightParams.leftMargin=getResources().getDisplayMetrics().widthPixels/2;
    pageFrame.addView(left,leftParams);pageFrame.addView(right,rightParams);
    root.addView(pageFrame,new LinearLayout.LayoutParams(-1,0,1));

    LinearLayout controls=new LinearLayout(this);controls.setGravity(Gravity.CENTER);controls.setOrientation(0);
    Button prev=new Button(this);prev.setText("◀ السابق");prev.setAllCaps(false);
    counter=new TextView(this);counter.setTextColor(Color.rgb(54,27,105));counter.setTextSize(15);counter.setPadding(14,8,14,8);
    Button next=new Button(this);next.setText("التالي ▶");next.setAllCaps(false);
    controls.addView(prev);controls.addView(counter);controls.addView(next);root.addView(controls,new LinearLayout.LayoutParams(-1,-2));
    setContentView(root);

    back.setOnClickListener(v->finish());
    prev.setOnClickListener(v->previousPage());next.setOnClickListener(v->nextPage());
    left.setOnClickListener(v->nextPage());right.setOnClickListener(v->previousPage());
    try{
      File f=new File(getCacheDir(),"lecture_view_"+asset.hashCode()+".pdf");
      try(InputStream in=getAssets().open("lectures/"+asset);OutputStream out=new FileOutputStream(f)){byte[] buf=new byte[16384];int n;while((n=in.read(buf))>0)out.write(buf,0,n);}
      ParcelFileDescriptor fd=ParcelFileDescriptor.open(f,ParcelFileDescriptor.MODE_READ_ONLY);renderer=new PdfRenderer(fd);
      if(pageIndex>=renderer.getPageCount())pageIndex=0;
      renderPage();
    }catch(Exception e){new android.app.AlertDialog.Builder(this).setMessage("تعذر فتح ملف PDF: "+e.getMessage()).setPositiveButton("حسناً",(d,w)->finish()).show();}
  }
  private void previousPage(){if(pageIndex>0){pageIndex--;renderPage();}}
  private void nextPage(){if(renderer!=null&&pageIndex<renderer.getPageCount()-1){pageIndex++;renderPage();}}
  private void renderPage(){
    if(renderer==null)return;
    if(page!=null){page.close();page=null;}
    page=renderer.openPage(pageIndex);
    int width=Math.max(900,getResources().getDisplayMetrics().widthPixels*2);
    int height=(int)((double)width*page.getHeight()/page.getWidth());
    Bitmap bitmap=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);bitmap.eraseColor(Color.WHITE);
    page.render(bitmap,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);image.setImageBitmap(bitmap);
    counter.setText((pageIndex+1)+" / "+renderer.getPageCount());
    prefs.edit().putInt(asset,pageIndex).apply();
  }
  @Override protected void onDestroy(){if(page!=null)page.close();if(renderer!=null)renderer.close();super.onDestroy();}
}
