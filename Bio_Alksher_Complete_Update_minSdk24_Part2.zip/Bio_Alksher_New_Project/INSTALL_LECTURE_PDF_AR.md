# تفعيل رفع ملفات المنهج PDF — Bio-alksher

تم تجهيز واجهة Android في MainActivity.java:
- زر "إضافة ملفات المنهج PDF" في لوحة الأستاذ.
- اختيار PDF من الهاتف.
- إدخال اسم الفصل.
- رفعه إلى Google Drive عبر Apps Script.
- عرض الملفات المضافة تلقائياً في قائمة PDF لدى الطلاب.
- الملفات القديمة الأربعة تبقى كما هي.

## خطوة ربط واحدة مطلوبة في Apps Script
لا يمكن لتطبيق Android تعديل مشروع Apps Script المنشور داخل حسابك تلقائياً. أضف ملفاً جديداً باسم `LectureFiles.gs` والصق فيه محتوى الملف المرفق في هذا المشروع.

ثم افتح `Code.gs` وابحث داخل `doPost(e)` عن السطر الذي يحلل JSON، عادةً:
`const data = JSON.parse(e.postData.contents || '{}');`

بعده مباشرة أضف:
```javascript
var lectureResponse = handleLectureFileAction_(data);
if (lectureResponse) return lectureResponse;
var fcmResponse = handleFcmAction_(data);
if (fcmResponse) return fcmResponse;
```
لا تستبدل `doPost` الحالي ولا تحذف وظائف تسجيل الطلاب.

## تأمين رفع الملفات بحساب الأستاذ
في Script Properties أضف:
- `FIREBASE_WEB_API_KEY` = قيمة `current_key` الموجودة في `app/google-services.json` (هذا مفتاح Firebase Web API العام، وليس Service Account secret).

تتحقق Apps Script من Firebase ID token وتتأكد أن البريد الموثق هو `ahmedalksher70@gmail.com` قبل السماح بالرفع.

## تجهيز Google Drive
1. في Apps Script افتح Project Settings ثم Script Properties.
2. أضف `LECTURES_FOLDER_ID` واجعل قيمته معرّف مجلد Drive الذي تريد وضع ملفات المنهج داخله. إذا لم تضفه فستُحفظ الملفات في My Drive الرئيسي.
3. في أول تشغيل سيطلب Google صلاحية الوصول إلى Drive وSheets؛ وافق من حساب مالك المشروع.
4. Deploy > Manage deployments > Edit (قلم) > New version > Deploy.
5. يجب أن يكون النشر Web app مضبوطاً على Execute as: Me. إعداد Who has access يجب أن يسمح بوصول تطبيقك إلى الرابط (غالباً Anyone). رفع الملفات محمي بالتحقق من Firebase ID token للمدرّس. قائمة ملفات المنهج متاحة للقراءة عبر الرابط.

## حدود وخصوصية
- التطبيق والخادم يرفضان ملفات أكبر من 25 MiB للملف الواحد.
- الرابط مضبوط Anyone with the link / Viewer لكي يستطيع الطلاب فتحه دون تسجيل دخول Google؛ أي شخص يحصل على الرابط يمكنه فتح الملف. لا ترفع ملفات خاصة أو محمية بحقوق تمنع المشاركة.
- سعة Drive المجانية المعتادة 15 GB مشتركة مع Gmail وGoogle Photos، وتظل خاضعة لمساحة حسابك.
- لا يمكنني نشر التعديلات داخل حسابك أو الموافقة على صلاحيات Google نيابة عنك.


## حذف واستبدال ملفات المنهج
- لوحة الأستاذ تعرض الملفات النشطة مع زر «حذف هذا الفصل» وزر «استبدال هذا الفصل بنسخة جديدة».
- الحذف يتطلب تأكيداً، ثم يعطّل سجل الملف وينقله إلى سلة مهملات Google Drive.
- الاستبدال يرفع الملف الجديد أولاً، وبعد نجاح إنشاء الملف الجديد يعطّل السجل القديم ويحاول نقل الملف القديم إلى سلة المهملات.
- لا ترفع ملفاً حساساً؛ المشاركة مضبوطة على «أي شخص لديه الرابط» حتى يستطيع الطلاب فتحه.

## حد الرفع
الحد المطبق في هذه النسخة هو 25 MiB للملف الواحد في التطبيق والخادم. يرسل التطبيق الملف بترميز Base64، ما يزيد حجم الطلب إلى نحو 33.3 MiB قبل احتساب بقية بيانات الطلب؛ لذلك يجب اختبار الرفع الفعلي على نشر Apps Script المستخدم. إذا رفض Apps Script الطلب بسبب حد حجم الطلب أو الذاكرة أو المهلة، فلن يكفي تغيير الرقم، وسنحتاج إلى نقل الرفع إلى أجزاء أو استخدام رفع مباشر/قابل للاستئناف إلى Google Drive. لا تعتبر الزيادة مؤكدة على الخادم قبل اختبار ملف PDF فعلي بحجم قريب من 25 MiB.


## تفعيل إشعارات الهاتف (زر مستقل عن رسائل داخل التطبيق)
1. أضف ملف `FCM.gs` إلى **نفس مشروع Apps Script** المستخدم لملفات المنهج.
2. تأكد أن `doPost(e)` يحتوي على سطري توجيه FCM الموجودين في مقطع الربط أعلاه؛ لا تضفهما مرتين.
3. افتح Project Settings وأظهر ملف `appsscript.json`، ثم ادمج معه نطاقات OAuth الموجودة في ملف المشروع.
4. من Google Cloud Console للمشروع `biochemistry-easy-with` فعّل Firebase Cloud Messaging API، وتأكد أن حساب مالك Apps Script لديه صلاحية إرسال رسائل FCM (Firebase Cloud Messaging API Admin أو صلاحية مكافئة). لا تضع Service Account key أو أي مفتاح سري داخل APK.
5. احفظ المشروع ثم Deploy > Manage deployments > Edit > New version > Deploy. وافق على صلاحيات Google عند الطلب.
6. يجب أن يكون الطلاب قد فتحوا التطبيق ووافقوا على إذن الإشعارات في Android 13+ حتى تصلهم إشعارات الهاتف.

**ملاحظة الخطة المجانية:** هذا المسار لا يستخدم Firebase Cloud Functions ولا يتطلب ترقية Firebase إلى Blaze؛ إرسال FCM يتم عبر Apps Script وOAuth الخاص بمالك السكربت، مع الالتزام بحصص Google Apps Script وFCM. اختبر الإرسال على هاتف طالب قبل التعميم.
